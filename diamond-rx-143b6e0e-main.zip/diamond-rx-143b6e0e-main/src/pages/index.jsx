import Layout from "./Layout.jsx";

import Home from "./Home";

import RoleSelection from "./RoleSelection";

import PatientDashboard from "./PatientDashboard";

import ProviderDashboard from "./ProviderDashboard";

import ExerciseLibrary from "./ExerciseLibrary";

import PatientManagement from "./PatientManagement";

import Exercises from "./Exercises";

import ProviderOnboarding from "./ProviderOnboarding";

import Settings from "./Settings";

import FindProviders from "./FindProviders";

import Complaints from "./Complaints";

import ICD10Library from "./ICD10Library";

import ExercisePrescriptions from "./ExercisePrescriptions";

import { BrowserRouter as Router, Route, Routes, useLocation } from 'react-router-dom';

const PAGES = {
    
    Home: Home,
    
    RoleSelection: RoleSelection,
    
    PatientDashboard: PatientDashboard,
    
    ProviderDashboard: ProviderDashboard,
    
    ExerciseLibrary: ExerciseLibrary,
    
    PatientManagement: PatientManagement,
    
    Exercises: Exercises,
    
    ProviderOnboarding: ProviderOnboarding,
    
    Settings: Settings,
    
    FindProviders: FindProviders,
    
    Complaints: Complaints,
    
    ICD10Library: ICD10Library,
    
    ExercisePrescriptions: ExercisePrescriptions,
    
}

function _getCurrentPage(url) {
    if (url.endsWith('/')) {
        url = url.slice(0, -1);
    }
    let urlLastPart = url.split('/').pop();
    if (urlLastPart.includes('?')) {
        urlLastPart = urlLastPart.split('?')[0];
    }

    const pageName = Object.keys(PAGES).find(page => page.toLowerCase() === urlLastPart.toLowerCase());
    return pageName || Object.keys(PAGES)[0];
}

// Create a wrapper component that uses useLocation inside the Router context
function PagesContent() {
    const location = useLocation();
    const currentPage = _getCurrentPage(location.pathname);
    
    return (
        <Layout currentPageName={currentPage}>
            <Routes>            
                
                    <Route path="/" element={<Home />} />
                
                
                <Route path="/Home" element={<Home />} />
                
                <Route path="/RoleSelection" element={<RoleSelection />} />
                
                <Route path="/PatientDashboard" element={<PatientDashboard />} />
                
                <Route path="/ProviderDashboard" element={<ProviderDashboard />} />
                
                <Route path="/ExerciseLibrary" element={<ExerciseLibrary />} />
                
                <Route path="/PatientManagement" element={<PatientManagement />} />
                
                <Route path="/Exercises" element={<Exercises />} />
                
                <Route path="/ProviderOnboarding" element={<ProviderOnboarding />} />
                
                <Route path="/Settings" element={<Settings />} />
                
                <Route path="/FindProviders" element={<FindProviders />} />
                
                <Route path="/Complaints" element={<Complaints />} />
                
                <Route path="/ICD10Library" element={<ICD10Library />} />
                
                <Route path="/ExercisePrescriptions" element={<ExercisePrescriptions />} />
                
            </Routes>
        </Layout>
    );
}

export default function Pages() {
    return (
        <Router>
            <PagesContent />
        </Router>
    );
}
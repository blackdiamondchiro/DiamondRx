
import React from "react";
import { User } from "@/api/entities";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { User as UserIcon, MapPin, Shield, Briefcase, HeartPulse } from "lucide-react";
import ProfileForm from "../components/settings/ProfileForm";
import AddressForm from "../components/settings/AddressForm";
import AccountSecurity from "../components/settings/AccountSecurity";
import ProviderProfileForm from "../components/settings/ProviderProfileForm";
import WorkLocationForm from "../components/settings/WorkLocationForm";
import ProviderLink from "../components/settings/ProviderLink";
import ServicesInsuranceForm from "../components/settings/ServicesInsuranceForm";

export default function SettingsPage({ user: initialUser, reloadLayoutUser }) {
  const [user, setUser] = React.useState(initialUser);
  const [loading, setLoading] = React.useState(true);

  const loadUser = React.useCallback(async () => {
    try {
      const userData = await User.me();
      setUser(userData);
    } catch (error) {
      console.error("Failed to load user data:", error);
    } finally {
      setLoading(false);
    }
  }, []);

  React.useEffect(() => {
    // When initialUser from layout changes, update local state
    if (initialUser) {
      setUser(initialUser);
      setLoading(false);
    } else {
      // Fallback if prop isn't passed for some reason
      loadUser();
    }
  }, [initialUser, loadUser]);

  const handleUpdate = () => {
    // This function is called by child forms on successful update.
    // It triggers a user data refresh in both this page and the parent Layout.
    if (reloadLayoutUser) {
      reloadLayoutUser();
    } else {
      // Fallback for cases where the reload function isn't passed
      loadUser();
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <p className="text-red-500">Could not load user profile. Please try again later.</p>
      </div>
    );
  }

  const isProvider = user.account_type === 'provider';

  return (
    <div className="min-h-screen bg-gray-50 p-4 lg:p-8">
      <div className="max-w-4xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Account Settings</h1>
          <p className="text-gray-600">Manage your profile information and account security</p>
        </div>

        <div className="space-y-8">
          {/* Profile Information */}
          <Card className="shadow-lg">
            <CardHeader>
              <CardTitle className="flex items-center gap-3">
                <UserIcon className="w-5 h-5 text-blue-600" />
                <span>{isProvider ? 'Personal Information' : 'Profile Information'}</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              {isProvider ? (
                <ProviderProfileForm user={user} onUpdate={handleUpdate} />
              ) : (
                <ProfileForm user={user} onUpdate={handleUpdate} />
              )}
            </CardContent>
          </Card>

          {isProvider ? (
            <>
              <Card className="shadow-lg">
                <CardHeader>
                  <CardTitle className="flex items-center gap-3">
                    <Briefcase className="w-5 h-5 text-green-600" />
                    <span>Work Location Information</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                   <WorkLocationForm user={user} onUpdate={handleUpdate} />
                </CardContent>
              </Card>

              <Card className="shadow-lg">
                <CardHeader>
                  <CardTitle className="flex items-center gap-3">
                    <HeartPulse className="w-5 h-5 text-indigo-600" />
                    <span>Services & Insurance</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                   <ServicesInsuranceForm user={user} onUpdate={handleUpdate} />
                </CardContent>
              </Card>
            </>
          ) : (
            <>
              {/* Address Information */}
              <Card className="shadow-lg">
                <CardHeader>
                  <CardTitle className="flex items-center gap-3">
                    <MapPin className="w-5 h-5 text-green-600" />
                    <span>Address Information</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <AddressForm user={user} onUpdate={handleUpdate} />
                </CardContent>
              </Card>

               {/* Provider Link */}
              <ProviderLink user={user} onUpdate={handleUpdate} />
            </>
          )}

           {/* Account Security */}
           <Card className="shadow-lg">
            <CardHeader>
              <CardTitle className="flex items-center gap-3">
                <Shield className="w-5 h-5 text-red-600" />
                <span>Account Security</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <AccountSecurity user={user} />
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}

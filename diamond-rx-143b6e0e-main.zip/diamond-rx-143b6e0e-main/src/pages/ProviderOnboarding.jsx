
import React from "react";
import { User } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { 
  Stethoscope, 
  ArrowRight, 
  ArrowLeft, 
  CheckCircle, 
  AlertTriangle,
  Info,
  Building,
  User as UserIcon
} from "lucide-react";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";

const SPECIALIZATIONS = [
  "Chiropractic", "Physical Therapy", "Orthopedic", "Sports Medicine", 
  "Massage Therapy", "Pain Management", "Occupational Therapy", "General Medicine"
];

export default function ProviderOnboardingPage() {
  const navigate = useNavigate();
  const [step, setStep] = React.useState(1);
  const [loading, setLoading] = React.useState(false);
  const [user, setUser] = React.useState(null);
  const [error, setError] = React.useState("");
  const [success, setSuccess] = React.useState("");
  const [formData, setFormData] = React.useState({
    // Personal Info
    full_name: "",
    specialization: "",
    credentials: "",
    license_number: "",
    // Practice Info
    practice_name: "",
    address: "",
    city: "",
    state: "",
    zip: "",
    phone: "",
    email: "", // This is practice email, not user's login email
    website: "",
    hours: ""
  });

  // Generic handler for input changes
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const checkUser = React.useCallback(async () => {
    try {
      const userData = await User.me();
      setUser(userData);
      
      // If user already has account type set, redirect them
      if (userData.account_type) {
        navigate(createPageUrl("ProviderDashboard"));
        return;
      }
      // Pre-fill full_name if available from user object
      if (userData.full_name) {
          setFormData(prev => ({ ...prev, full_name: userData.full_name }));
      }
    } catch (error) {
      console.error("Error checking user:", error);
      setError("Unable to verify your account. Please try again.");
    }
  }, [navigate]);

  React.useEffect(() => {
    checkUser();
  }, [checkUser]);

  // Updated steps array to reflect new onboarding flow
  const steps = [
    {
      title: "Personal Details",
      description: "Tell us about yourself and your qualifications",
      icon: <UserIcon className="w-6 h-6" />
    },
    {
      title: "Practice Details",
      description: "Information about your clinic or practice",
      icon: <Building className="w-6 h-6" />
    },
    {
      title: "Confirmation",
      description: "Review and create your provider account",
      icon: <CheckCircle className="w-6 h-6" />
    }
  ];

  const handleNext = () => {
    if (step < steps.length) {
      setStep(step + 1);
    }
  };

  const handlePrev = () => {
    if (step > 1) {
      setStep(step - 1);
    }
  };

  const canProceed = () => {
    switch (step) {
      case 1: // Personal Details
        return (
          formData.full_name !== "" &&
          formData.specialization !== "" &&
          formData.credentials !== "" &&
          formData.license_number !== ""
        );
      case 2: // Practice Details
        // Required fields for practice details: name, address, city, state, zip
        return (
          formData.practice_name !== "" &&
          formData.address !== "" &&
          formData.city !== "" &&
          formData.state !== "" &&
          formData.zip !== ""
        );
      case 3: // Confirmation
        return true; // Always true if previous steps are valid
      default:
        return false;
    }
  };

  const handleSubmit = async () => {
    if (!user) {
      setError("User not found. Please refresh and try again.");
      return;
    }

    setLoading(true);
    setError("");
    setSuccess("");

    try {
      // Set account type and all new provider data from formData
      await User.updateMyUserData({
        account_type: 'provider',
        full_name: formData.full_name,
        specialization: formData.specialization,
        credentials: formData.credentials,
        license_number: formData.license_number,
        practice_name: formData.practice_name,
        // Nested work_location object as per outline
        work_location: {
          address: formData.address,
          city: formData.city,
          state: formData.state,
          zip: formData.zip,
          phone: formData.phone || null,
          email: formData.email || null,
          website: formData.website || null,
          hours: formData.hours || null
        },
      });

      setSuccess("Onboarding complete! Redirecting to your dashboard...");

      setTimeout(() => {
        navigate(createPageUrl("ProviderDashboard"));
      }, 1500);

    } catch (error) {
      console.error("Error creating provider account:", error);
      setError("Unable to create provider account. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  if (!user) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-green-50 via-white to-blue-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-green-600 mx-auto"></div>
          <p className="mt-4 text-gray-600">Loading onboarding...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 via-white to-blue-50 p-4">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-8">
          <div className="flex justify-center mb-6">
            <div className="w-16 h-16 bg-gradient-to-r from-green-600 to-blue-600 rounded-2xl flex items-center justify-center shadow-lg">
              <Stethoscope className="w-8 h-8 text-white" />
            </div>
          </div>
          <h1 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            Provider Account Setup
          </h1>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Let's configure your healthcare provider account with the right settings for your practice
          </p>
        </div>

        {/* Progress Steps */}
        <div className="mb-8">
          <div className="flex justify-between items-center">
            {steps.map((s, index) => (
              <div key={index} className="flex flex-col items-center flex-1">
                <div className={`w-12 h-12 rounded-full border-2 flex items-center justify-center mb-2 ${
                  index + 1 === step 
                    ? 'border-green-600 bg-green-600 text-white'
                    : index + 1 < step
                    ? 'border-green-600 bg-green-600 text-white'
                    : 'border-gray-300 bg-gray-100 text-gray-400'
                }`}>
                  {index + 1 < step ? (
                    <CheckCircle className="w-6 h-6" />
                  ) : (
                    s.icon
                  )}
                </div>
                <div className="text-center">
                  <p className={`text-sm font-medium ${
                    index + 1 <= step ? 'text-gray-900' : 'text-gray-500'
                  }`}>
                    {s.title}
                  </p>
                  <p className="text-xs text-gray-500 hidden md:block">
                    {s.description}
                  </p>
                </div>
                {index < steps.length - 1 && (
                  <div className={`hidden md:block flex-1 h-0.5 mx-4 ${
                    index + 1 < step ? 'bg-green-600' : 'bg-gray-200'
                  }`} style={{ transform: 'translateY(-24px)' }} />
                )}
              </div>
            ))}
          </div>
        </div>

        {error && (
          <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-lg">
            <div className="flex items-center gap-3">
              <AlertTriangle className="w-5 h-5 text-red-600 flex-shrink-0" />
              <p className="text-red-700 font-medium">{error}</p>
            </div>
          </div>
        )}

        {success && (
          <div className="mb-6 p-4 bg-green-50 border border-green-200 rounded-lg">
            <div className="flex items-center gap-3">
              <CheckCircle className="w-5 h-5 text-green-600 flex-shrink-0" />
              <p className="text-green-700 font-medium">{success}</p>
            </div>
          </div>
        )}

        <Card className="shadow-xl">
          <CardHeader className="text-center pb-4">
            <div className="w-12 h-12 bg-green-100 rounded-xl flex items-center justify-center mx-auto mb-4">
              {steps[step - 1].icon}
            </div>
            <CardTitle className="text-2xl">{steps[step - 1].title}</CardTitle>
            <CardDescription className="text-lg">
              {steps[step - 1].description}
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* Step 1: Personal Details */}
            {step === 1 && (
              <div className="space-y-6">
                <div>
                  <Label htmlFor="full_name" className="text-base font-medium">Full Name *</Label>
                  <Input id="full_name" name="full_name" value={formData.full_name} onChange={handleChange} placeholder="Dr. Jane Doe" className="mt-2" />
                </div>
                <div>
                  <Label htmlFor="credentials" className="text-base font-medium">Credentials/Title *</Label>
                  <Input id="credentials" name="credentials" value={formData.credentials} onChange={handleChange} placeholder="DPT, MD, D.C." className="mt-2" />
                </div>
                <div>
                  <Label htmlFor="specialization" className="text-base font-medium">Primary Discipline / Specialization *</Label>
                  <Select name="specialization" value={formData.specialization} onValueChange={(value) => setFormData(prev => ({...prev, specialization: value}))}>
                    <SelectTrigger id="specialization" className="mt-2">
                      <SelectValue placeholder="Select a discipline" />
                    </SelectTrigger>
                    <SelectContent>
                      {SPECIALIZATIONS.map(spec => <SelectItem key={spec} value={spec}>{spec}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="license_number" className="text-base font-medium">Medical License Number *</Label>
                  <Input id="license_number" name="license_number" value={formData.license_number} onChange={handleChange} placeholder="Your license number" className="mt-2" />
                </div>
                <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                  <div className="flex items-start gap-3">
                    <Info className="w-5 h-5 text-blue-600 mt-0.5" />
                    <div>
                      <p className="text-blue-800 font-medium mb-1">Why we ask for this</p>
                      <p className="text-blue-700 text-sm">
                        This information helps us verify your professional standing and enables patients to find qualified providers.
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Step 2: Practice Details */}
            {step === 2 && (
              <div className="space-y-6">
                <div>
                  <Label htmlFor="practice_name" className="text-base font-medium">
                    Practice or Clinic Name *
                  </Label>
                  <Input
                    id="practice_name"
                    name="practice_name"
                    value={formData.practice_name}
                    onChange={handleChange}
                    placeholder="e.g., Smith Physical Therapy Clinic"
                    className="mt-2"
                  />
                </div>
                <div>
                  <Label htmlFor="address" className="text-base font-medium">
                    Practice Address *
                  </Label>
                  <Input
                    id="address"
                    name="address"
                    value={formData.address}
                    onChange={handleChange}
                    placeholder="123 Main St"
                    className="mt-2"
                  />
                </div>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div>
                    <Label htmlFor="city" className="text-base font-medium">City *</Label>
                    <Input id="city" name="city" value={formData.city} onChange={handleChange} placeholder="Anytown" className="mt-2" />
                  </div>
                  <div>
                    <Label htmlFor="state" className="text-base font-medium">State *</Label>
                    <Input id="state" name="state" value={formData.state} onChange={handleChange} placeholder="NY" className="mt-2" />
                  </div>
                  <div>
                    <Label htmlFor="zip" className="text-base font-medium">Zip Code *</Label>
                    <Input id="zip" name="zip" value={formData.zip} onChange={handleChange} placeholder="12345" className="mt-2" />
                  </div>
                </div>
                <div>
                  <Label htmlFor="phone" className="text-base font-medium">
                    Practice Phone (Optional)
                  </Label>
                  <Input
                    id="phone"
                    name="phone"
                    value={formData.phone}
                    onChange={handleChange}
                    placeholder="(555) 123-4567"
                    className="mt-2"
                  />
                </div>
                <div>
                  <Label htmlFor="email" className="text-base font-medium">
                    Practice Email (Optional)
                  </Label>
                  <Input
                    id="email"
                    name="email"
                    type="email"
                    value={formData.email}
                    onChange={handleChange}
                    placeholder="info@yourpractice.com"
                    className="mt-2"
                  />
                </div>
                <div>
                  <Label htmlFor="website" className="text-base font-medium">
                    Practice Website (Optional)
                  </Label>
                  <Input
                    id="website"
                    name="website"
                    type="url"
                    value={formData.website}
                    onChange={handleChange}
                    placeholder="https://www.yourpractice.com"
                    className="mt-2"
                  />
                </div>
                <div>
                  <Label htmlFor="hours" className="text-base font-medium">
                    Practice Hours (Optional)
                  </Label>
                  <Textarea
                    id="hours"
                    name="hours"
                    value={formData.hours}
                    onChange={handleChange}
                    placeholder="Mon-Fri: 9 AM - 5 PM"
                    className="mt-2"
                  />
                </div>
                <div className="p-4 bg-gray-50 border border-gray-200 rounded-lg">
                  <p className="text-gray-700 font-medium mb-1">Visibility of Practice Details</p>
                  <p className="text-gray-600 text-sm">
                    This information will be displayed on your public profile to help patients contact and locate your practice.
                  </p>
                </div>
              </div>
            )}

            {/* Step 3: Confirmation */}
            {step === 3 && (
              <div className="space-y-6">
                <div className="text-center">
                  <CheckCircle className="w-16 h-16 text-green-600 mx-auto mb-4" />
                  <h3 className="text-xl font-bold text-gray-900 mb-2">
                    Ready to Create Your Provider Account
                  </h3>
                  <p className="text-gray-600">
                    Please review your information below and confirm to create your account.
                  </p>
                </div>

                <div className="space-y-4 p-4 bg-gray-50 rounded-lg">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <p className="text-sm font-medium text-gray-700">Full Name</p>
                      <p className="text-gray-900">{formData.full_name || 'N/A'}</p>
                    </div>
                    <div>
                      <p className="text-sm font-medium text-gray-700">Credentials</p>
                      <p className="text-gray-900">{formData.credentials || 'N/A'}</p>
                    </div>
                    <div>
                      <p className="text-sm font-medium text-gray-700">Specialization</p>
                      <p className="text-gray-900">{formData.specialization || 'N/A'}</p>
                    </div>
                    <div>
                      <p className="text-sm font-medium text-gray-700">License Number</p>
                      <p className="text-gray-900">{formData.license_number || 'N/A'}</p>
                    </div>
                    <div>
                      <p className="text-sm font-medium text-gray-700">Practice Name</p>
                      <p className="text-gray-900">{formData.practice_name || 'N/A'}</p>
                    </div>
                    <div>
                      <p className="text-sm font-medium text-gray-700">Address</p>
                      <p className="text-gray-900">
                        {formData.address || 'N/A'}, {formData.city || 'N/A'}, {formData.state || 'N/A'} {formData.zip || 'N/A'}
                      </p>
                    </div>
                    {formData.phone && (
                      <div>
                        <p className="text-sm font-medium text-gray-700">Phone</p>
                        <p className="text-gray-900">{formData.phone}</p>
                      </div>
                    )}
                    {formData.email && (
                      <div>
                        <p className="text-sm font-medium text-gray-700">Email</p>
                        <p className="text-gray-900">{formData.email}</p>
                      </div>
                    )}
                    {formData.website && (
                      <div>
                        <p className="text-sm font-medium text-gray-700">Website</p>
                        <p className="text-gray-900">{formData.website}</p>
                      </div>
                    )}
                    {formData.hours && (
                      <div>
                        <p className="text-sm font-medium text-gray-700">Hours</p>
                        <p className="text-gray-900">{formData.hours}</p>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            )}

            {/* Navigation Buttons */}
            <div className="flex justify-between pt-6 border-t">
              <Button
                variant="outline"
                onClick={handlePrev}
                disabled={step === 1}
                className="flex items-center gap-2"
              >
                <ArrowLeft className="w-4 h-4" />
                Previous
              </Button>

              {step < steps.length ? (
                <Button
                  onClick={handleNext}
                  disabled={!canProceed()}
                  className="flex items-center gap-2 bg-green-600 hover:bg-green-700"
                >
                  Next
                  <ArrowRight className="w-4 h-4" />
                </Button>
              ) : (
                <Button
                  onClick={handleSubmit}
                  disabled={loading || !canProceed()}
                  className="flex items-center gap-2 bg-green-600 hover:bg-green-700"
                >
                  {loading ? 'Creating Account...' : 'Create Provider Account'}
                  <CheckCircle className="w-4 h-4" />
                </Button>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

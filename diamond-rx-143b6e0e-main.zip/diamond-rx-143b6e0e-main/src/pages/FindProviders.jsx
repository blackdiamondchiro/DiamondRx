
import React from "react";
import { User } from "@/api/entities";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue
} from "@/components/ui/select";
import { 
  Search, Stethoscope, MapPin, Building, LinkIcon, User as UserIconCheck, 
  Mail, Phone, Globe, ShieldCheck, ShieldX 
} from "lucide-react";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";

const SPECIALTIES = [
  "Chiropractic", "Physical Therapy", "Sports Medicine", "Orthopedics",
  "Massage Therapy", "Pain Management", "Occupational Therapy"
];

// Mock provider data as we cannot query all users
const MOCK_PROVIDERS = [
  {
    id: "provider1",
    full_name: "Dr. Emily Carter",
    credentials: "DPT",
    specialization: "Physical Therapy",
    practice_name: "HealWell Physical Therapy",
    work_location: {
      address: "123 Wellness Ave",
      city: "Healthville",
      state: "CA",
      zip: "90210",
      phone: "(555) 123-4567",
      email: "contact@healwellpt.com",
      website: "https://www.healwellpt.com",
      hours: "Mon-Fri: 9am - 5pm"
    },
    services: ["Manual Therapy", "Sports Injury Rehab", "Post-Surgical Rehab", "Dry Needling"],
    insurance_acceptance: "yes",
    accepted_insurance_providers: ["Blue Cross Blue Shield", "Aetna", "Cigna"]
  },
  {
    id: "provider2",
    full_name: "Dr. Benjamin Lee",
    credentials: "D.C.",
    specialization: "Chiropractic",
    practice_name: "Align Chiropractic",
    work_location: {
      address: "456 Spine St",
      city: "Adjuston",
      state: "TX",
      zip: "73301",
      phone: "(555) 234-5678",
      email: "info@alignchiro.com",
      website: "https://www.alignchiro.com",
      hours: "Mon, Wed, Fri: 8am - 6pm"
    },
    services: ["Spinal Adjustments", "Active Release Technique", "Spinal Decompression"],
    insurance_acceptance: "out_of_network",
    accepted_insurance_providers: []
  },
  {
    id: "provider3",
    full_name: "Dr. Olivia Garcia",
    credentials: "MD, ATC",
    specialization: "Sports Medicine",
    practice_name: "Peak Performance Sports Med",
    work_location: {
      address: "789 Athlete Rd",
      city: "Healthville",
      state: "CA",
      zip: "90211",
      phone: "(555) 345-6789",
      email: "scheduling@peakperformance.com",
      website: "https://www.peakperformance.com",
      hours: "Tue, Thu: 10am - 7pm"
    },
    services: ["Diagnostic Ultrasound", "PRP Injections", "Concussion Management"],
    insurance_acceptance: "no",
    accepted_insurance_providers: []
  }
];

export default function FindProvidersPage() {
  const navigate = useNavigate();
  const [providers, setProviders] = React.useState([]);
  const [filteredProviders, setFilteredProviders] = React.useState([]);
  const [loading, setLoading] = React.useState(true);
  const [filters, setFilters] = React.useState({
    search: "",
    specialty: "all",
    city: "all",
    insurance: "all"
  });
  const [currentUser, setCurrentUser] = React.useState(null);

  const loadProviders = React.useCallback(async () => {
    try {
      const user = await User.me();
      setCurrentUser(user);
    } catch(e) {
      // Not logged in, fine
    }
    // In a real app: const providerList = await User.filter({ account_type: 'provider' });
    setProviders(MOCK_PROVIDERS);
    setLoading(false);
  }, []);

  React.useEffect(() => {
    loadProviders();
  }, [loadProviders]);

  React.useEffect(() => {
    let filtered = providers;

    if (filters.search) {
      const searchTerm = filters.search.toLowerCase();
      filtered = filtered.filter(p =>
        p.full_name.toLowerCase().includes(searchTerm) ||
        p.practice_name.toLowerCase().includes(searchTerm) ||
        p.services?.some(s => s.toLowerCase().includes(searchTerm))
      );
    }

    if (filters.specialty !== "all") {
      filtered = filtered.filter(p => p.specialization === filters.specialty);
    }

    if (filters.city !== "all") {
      filtered = filtered.filter(p => p.work_location?.city === filters.city);
    }

    if (filters.insurance !== "all") {
      if (filters.insurance === "yes") {
        filtered = filtered.filter(p => p.insurance_acceptance === "yes");
      } else if (filters.insurance === "no") { // This now covers both 'no' and 'out_of_network'
        filtered = filtered.filter(p => p.insurance_acceptance === "no" || p.insurance_acceptance === "out_of_network");
      }
    }

    setFilteredProviders(filtered);
  }, [filters, providers]);

  const uniqueCities = [...new Set(providers.map(p => p.work_location?.city).filter(Boolean))];

  const handleLinkProvider = async (providerId) => {
    if (window.confirm("Are you sure you want to link to this provider?")) {
      try {
        await User.updateMyUserData({ provider_id: providerId });
        // Update currentUser state after successful linking
        setCurrentUser(prevUser => ({ ...prevUser, provider_id: providerId }));
        alert("Successfully linked to provider!");
        navigate(createPageUrl("PatientDashboard"));
      } catch (error) {
        console.error("Failed to link provider:", error);
        alert("An error occurred. Please try again.");
      }
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  const InsuranceBadge = ({ type }) => {
    if (type === 'yes') {
      return <Badge className="bg-blue-100 text-blue-800"><ShieldCheck className="w-3 h-3 mr-1" /> Accepts Insurance</Badge>;
    }
    if (type === 'out_of_network') {
      return <Badge variant="secondary">Out-of-Network</Badge>;
    }
    return <Badge className="bg-green-100 text-green-800"><ShieldX className="w-3 h-3 mr-1" /> Self-Pay Only</Badge>;
  };

  return (
    <div className="min-h-screen bg-gray-50 p-4 lg:p-8">
      <div className="max-w-7xl mx-auto">
        <div className="mb-8 text-center">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Find a Healthcare Provider</h1>
          <p className="text-gray-600">Connect with a professional to guide your recovery journey.</p>
        </div>

        <Card className="shadow-lg mb-8">
          <CardHeader>
            <CardTitle>Filter Providers</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 items-end">
              <div className="lg:col-span-2">
                <Label htmlFor="search">Search by Name, Practice, or Service</Label>
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                  <Input
                    id="search"
                    placeholder="e.g., Dr. Smith, HealWell, or 'Dry Needling'..."
                    value={filters.search}
                    onChange={(e) => setFilters(prev => ({ ...prev, search: e.target.value }))}
                    className="pl-10"
                  />
                </div>
              </div>

              <div>
                <Label htmlFor="specialty">Specialty</Label>
                <Select
                  value={filters.specialty}
                  onValueChange={(value) => setFilters(prev => ({ ...prev, specialty: value }))}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="All Specialties" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Specialties</SelectItem>
                    {SPECIALTIES.map(s => <SelectItem key={s} value={s}>{s}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="city">City</Label>
                <Select
                  value={filters.city}
                  onValueChange={(value) => setFilters(prev => ({ ...prev, city: value }))}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="All Cities" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Cities</SelectItem>
                    {uniqueCities.map(c => <SelectItem key={c} value={c}>{c}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              
              <div>
                <Label htmlFor="insurance">Insurance</Label>
                <Select
                  value={filters.insurance}
                  onValueChange={(value) => setFilters(prev => ({ ...prev, insurance: value }))}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Any Insurance" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Any</SelectItem>
                    <SelectItem value="yes">Accepts Insurance</SelectItem>
                    <SelectItem value="no">Self-Pay / Out-of-Network</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </CardContent>
        </Card>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {filteredProviders.map(provider => (
            <Card key={provider.id} className="shadow-lg hover:shadow-xl transition-shadow duration-300 flex flex-col">
              <CardHeader>
                <div className="flex justify-between items-start">
                    <div>
                        <CardTitle className="text-xl">
                          {provider.full_name}{provider.credentials ? `, ${provider.credentials}` : ''}
                        </CardTitle>
                        <p className="text-md font-semibold text-blue-600">{provider.specialization}</p>
                    </div>
                    <InsuranceBadge type={provider.insurance_acceptance} />
                </div>
              </CardHeader>
              <CardContent className="flex-grow space-y-4">
                
                <div className="p-4 bg-gray-50 rounded-lg space-y-2">
                    <div className="flex items-start gap-3 text-sm"><Building className="w-4 h-4 mt-0.5 text-gray-500" /><span>{provider.practice_name}</span></div>
                    <div className="flex items-start gap-3 text-sm"><MapPin className="w-4 h-4 mt-0.5 text-gray-500" /><span>{provider.work_location.address}, {provider.work_location.city}, {provider.work_location.state}</span></div>
                    <div className="flex items-start gap-3 text-sm"><Phone className="w-4 h-4 mt-0.5 text-gray-500" /><span>{provider.work_location.phone}</span></div>
                    {provider.work_location.website && (
                         <div className="flex items-start gap-3 text-sm"><Globe className="w-4 h-4 mt-0.5 text-gray-500" />
                            <a href={provider.work_location.website} target="_blank" rel="noopener noreferrer" className="text-blue-600 hover:underline">
                              Visit Website
                            </a>
                         </div>
                    )}
                </div>

                <div>
                    <h4 className="font-semibold mb-2">Services</h4>
                    <div className="flex flex-wrap gap-2">
                        {provider.services?.map(service => <Badge key={service} variant="secondary">{service}</Badge>)}
                        {(!provider.services || provider.services.length === 0) && <p className="text-sm text-gray-500">No services listed.</p>}
                    </div>
                </div>

                {provider.insurance_acceptance === 'yes' && provider.accepted_insurance_providers?.length > 0 && (
                     <div>
                        <h4 className="font-semibold mb-2">Accepted Insurance Includes</h4>
                         <div className="flex flex-wrap gap-2">
                            {provider.accepted_insurance_providers.map(ins => <Badge key={ins} className="bg-blue-100 text-blue-800">{ins}</Badge>)}
                        </div>
                    </div>
                )}
                
              </CardContent>
              <div className="p-6 pt-0 mt-auto">
                 {currentUser?.provider_id === provider.id ? (
                    <Button disabled className="w-full bg-green-600 hover:bg-green-700">
                      <UserIconCheck className="w-4 h-4 mr-2" />
                      Currently Linked
                    </Button>
                  ) : (
                    <Button onClick={() => handleLinkProvider(provider.id)} className="w-full bg-blue-600 hover:bg-blue-700">
                      <LinkIcon className="w-4 h-4 mr-2" />
                      Link to this Provider
                    </Button>
                  )}
              </div>
            </Card>
          ))}
          {filteredProviders.length === 0 && (
            <div className="col-span-full text-center py-12 bg-white rounded-lg shadow-md">
              <h3 className="text-xl font-semibold text-gray-700">No Providers Found</h3>
              <p className="text-gray-500 mt-2">Try adjusting your search filters to find a match.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

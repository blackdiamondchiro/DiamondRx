
import React from "react";
import { User } from "@/api/entities"; // Import User
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Alert,
  AlertDescription,
} from "@/components/ui/alert";
import {
  Users,
  Heart,
  AlertTriangle,
  TrendingUp,
  Activity,
  Plus,
  Calendar,
  Stethoscope,
  Phone,
  Mail,
  Bell
} from "lucide-react";
import { format, subDays } from "date-fns";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';

export default function ProviderDashboardPage() { // Remove user prop
  const [user, setUser] = React.useState(null); // Add user state
  const [patients, setPatients] = React.useState([]);
  const [exercises, setExercises] = React.useState([]);
  const [alerts, setAlerts] = React.useState([]); // Kept for backward compatibility
  const [highPainAlerts, setHighPainAlerts] = React.useState([]);
  const [stats, setStats] = React.useState({
    totalPatients: 0,
    totalExercises: 0,
    highPainAlerts: 0,
    avgPainLevel: 0
  });
  const [loading, setLoading] = React.useState(true);

  const loadDashboardData = React.useCallback(async () => { // Make async
    try {
      const userData = await User.me(); // Fetch user
      setUser(userData);

      if (userData.account_type !== 'provider') {
        setLoading(false);
        return;
      }

      // Mock exercises for demonstration
      const mockExercises = [
        {
          id: "1",
          name: "Neck Stretches",
          provider_id: userData.id,
          created_by: userData.email
        },
        {
          id: "2",
          name: "Lower Back Strengthening", 
          provider_id: userData.id,
          created_by: userData.email
        }
      ];
      
      setExercises(mockExercises);
      
      // Mock data for patients
      const mockPatients = [
        {
          id: "1",
          full_name: "John Doe",
          email: "john@example.com",
          account_type: "patient",
          provider_id: userData.id
        },
        {
          id: "2", 
          full_name: "Jane Smith",
          email: "jane@example.com",
          account_type: "patient",
          provider_id: userData.id
        }
      ];

      // Enhanced mock alerts with threshold-based logic
      const mockHighPainAlerts = [
        {
          id: 1,
          patient_id: "1",
          patient_name: "John Doe",
          patient_email: "john@example.com",
          pain_level: 8,
          body_area: "lower_back",
          threshold_exceeded: 6,
          timestamp: new Date().toISOString(),
          status: "new", // new, acknowledged, resolved
          notes: "Patient reported sudden sharp pain after lifting"
        },
        {
          id: 2,
          patient_id: "2", 
          patient_name: "Jane Smith",
          patient_email: "jane@example.com",
          pain_level: 7,
          body_area: "neck",
          threshold_exceeded: 6,
          timestamp: subDays(new Date(), 1).toISOString(),
          status: "acknowledged",
          notes: "Chronic pain worsening over past few days"
        },
        {
          id: 3,
          patient_id: "1",
          patient_name: "John Doe", 
          patient_email: "john@example.com",
          pain_level: 9,
          body_area: "left_knee",
          threshold_exceeded: 6,
          timestamp: subDays(new Date(), 2).toISOString(),
          status: "new",
          notes: "Severe pain following exercise routine"
        }
      ];

      setPatients(mockPatients);
      setAlerts(mockHighPainAlerts); // Keep for backward compatibility
      setHighPainAlerts(mockHighPainAlerts);
      
      setStats({
        totalPatients: mockPatients.length,
        totalExercises: mockExercises.length,
        highPainAlerts: mockHighPainAlerts.filter(alert => alert.status === 'new').length,
        avgPainLevel: 5.2
      });

    } catch (error) {
      console.error("Error loading dashboard data:", error);
    } finally {
      setLoading(false);
    }
  }, []); // Remove user from dependency array

  React.useEffect(() => {
    loadDashboardData();
  }, [loadDashboardData]);

  const handleAcknowledgeAlert = (alertId) => {
    setHighPainAlerts(prev => 
      prev.map(alert => 
        alert.id === alertId 
          ? { ...alert, status: 'acknowledged' }
          : alert
      )
    );
    
    // Update stats
    setStats(prev => ({
      ...prev,
      highPainAlerts: prev.highPainAlerts - 1
    }));
  };

  const getPainDistributionData = () => [
    { name: 'Low (0-3)', value: 35, color: '#10b981' },
    { name: 'Moderate (4-6)', value: 45, color: '#f59e0b' },
    { name: 'High (7-10)', value: 20, color: '#ef4444' }
  ];

  const getWeeklyActivityData = () => {
    return Array.from({ length: 7 }, (_, i) => {
      const date = subDays(new Date(), 6 - i);
      return {
        date: format(date, 'EEE'),
        patients: Math.floor(Math.random() * 15) + 5,
        exercises: Math.floor(Math.random() * 25) + 10
      };
    });
  };

  if (loading) {
    return <div className="min-h-screen bg-gray-50 flex items-center justify-center">
      <div className="text-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-green-600 mx-auto"></div>
        <p className="mt-4 text-gray-600">Loading provider dashboard...</p>
      </div>
    </div>;
  }

  if (!user || user.account_type !== 'provider') {
    return null;
  }

  const newAlerts = highPainAlerts.filter(alert => alert.status === 'new');

  return (
    <div className="min-h-screen bg-gray-50 p-4 lg:p-8">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">
            Welcome back, Dr. {user?.full_name?.split(' ')[1] || user?.full_name || 'Provider'}!
          </h1>
          <p className="text-gray-600">Your patient management dashboard</p>
        </div>

        {/* High Pain Alerts Banner */}
        {newAlerts.length > 0 && (
          <Alert className="mb-6 border-red-200 bg-red-50">
            <AlertTriangle className="h-5 w-5 text-red-600" />
            <AlertDescription>
              <div className="flex items-center justify-between">
                <div>
                  <p className="font-medium text-red-900">
                    {newAlerts.length} High Pain Alert{newAlerts.length > 1 ? 's' : ''} Require Attention
                  </p>
                  <p className="text-sm text-red-700 mt-1">
                    Patient{newAlerts.length > 1 ? 's' : ''} reported pain above your threshold (6/10)
                  </p>
                </div>
                <div className="flex gap-2">
                  <Button variant="outline" size="sm" className="border-red-300 text-red-700 hover:bg-red-100">
                    <Bell className="w-4 h-4 mr-1" />
                    View All Alerts
                  </Button>
                  <Link to={createPageUrl("PatientManagement")}>
                    <Button size="sm" className="bg-red-600 hover:bg-red-700">
                      Manage Patients
                    </Button>
                  </Link>
                </div>
              </div>
            </AlertDescription>
          </Alert>
        )}

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card className="shadow-lg">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Patients</CardTitle>
              <Users className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.totalPatients}</div>
              <p className="text-xs text-muted-foreground">
                Linked to your care
              </p>
            </CardContent>
          </Card>

          <Card className="shadow-lg">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Exercise Library</CardTitle>
              <Heart className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.totalExercises}</div>
              <p className="text-xs text-muted-foreground">
                Exercises created
              </p>
            </CardContent>
          </Card>

          <Card className="shadow-lg">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">High Pain Alerts</CardTitle>
              <AlertTriangle className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.highPainAlerts}</div>
              <p className="text-xs text-muted-foreground">
                Require attention
              </p>
            </CardContent>
          </Card>

          <Card className="shadow-lg">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Avg Patient Pain</CardTitle>
              <Activity className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.avgPainLevel.toFixed(1)}/10</div>
              <p className="text-xs text-muted-foreground">
                Across all patients
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Main Content Grid */}
        <div className="grid lg:grid-cols-3 gap-8">
          {/* Weekly Activity Chart */}
          <div className="lg:col-span-2">
            <Card className="shadow-lg">
              <CardHeader>
                <CardTitle>Weekly Activity</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-64">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={getWeeklyActivityData()}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="date" />
                      <YAxis />
                      <Tooltip />
                      <Bar dataKey="patients" fill="#10b981" name="Patient Check-ins" />
                      <Bar dataKey="exercises" fill="#3b82f6" name="Exercise Completions" />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>

            {/* Quick Actions */}
            <Card className="shadow-lg mt-6">
              <CardHeader>
                <CardTitle>Quick Actions</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <Link to={createPageUrl("ExerciseLibrary")}>
                    <Button className="w-full h-16 bg-green-600 hover:bg-green-700">
                      <div className="text-center">
                        <Plus className="w-6 h-6 mx-auto mb-1" />
                        <span className="font-medium">Add Exercise</span>
                      </div>
                    </Button>
                  </Link>
                  <Link to={createPageUrl("PatientManagement")}>
                    <Button variant="outline" className="w-full h-16">
                      <div className="text-center">
                        <Users className="w-6 h-6 mx-auto mb-1" />
                        <span className="font-medium">Manage Patients</span>
                      </div>
                    </Button>
                  </Link>
                  <Link to={createPageUrl("Settings")}>
                    <Button variant="outline" className="w-full h-16">
                      <div className="text-center">
                        <Stethoscope className="w-6 h-6 mx-auto mb-1" />
                        <span className="font-medium">Settings</span>
                      </div>
                    </Button>
                  </Link>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Sidebar Content */}
          <div className="space-y-6">
            {/* Pain Distribution */}
            <Card className="shadow-lg">
              <CardHeader>
                <CardTitle>Patient Pain Distribution</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-48">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={getPainDistributionData()}
                        cx="50%"
                        cy="50%"
                        innerRadius={30}
                        outerRadius={60}
                        dataKey="value"
                        label={({ name, value }) => `${value}%`}
                      >
                        {getPainDistributionData().map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.color} />
                        ))}
                      </Pie>
                      <Tooltip />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
                <div className="mt-4 space-y-2">
                  {getPainDistributionData().map((entry, index) => (
                    <div key={index} className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <div className="w-3 h-3 rounded-full" style={{ backgroundColor: entry.color }}></div>
                        <span className="text-sm">{entry.name}</span>
                      </div>
                      <span className="text-sm font-medium">{entry.value}%</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* High Pain Alerts */}
            <Card className="shadow-lg">
              <CardHeader>
                <CardTitle>High Pain Alerts</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {newAlerts.slice(0, 3).map((alert) => (
                    <div key={alert.id} className="p-4 bg-red-50 border border-red-200 rounded-lg">
                      <div className="flex justify-between items-start mb-2">
                        <span className="font-medium">{alert.patient_name}</span>
                        <Badge variant="destructive">
                          {alert.pain_level}/10
                        </Badge>
                      </div>
                      <p className="text-sm text-gray-600 capitalize mb-1">
                        {alert.body_area.replace('_', ' ')} pain
                      </p>
                      <p className="text-xs text-gray-500 mb-2">
                        Threshold: {alert.threshold_exceeded}/10 • {format(new Date(alert.timestamp), 'MMM d, h:mm a')}
                      </p>
                      {alert.notes && (
                        <p className="text-xs text-red-700 bg-red-100 p-2 rounded mb-3">
                          "{alert.notes}"
                        </p>
                      )}
                      <div className="flex gap-2">
                        <Button 
                          size="sm" 
                          variant="outline"
                          className="border-red-300 text-red-700 hover:bg-red-100"
                          onClick={() => window.location.href = `tel:${alert.patient_email}`}
                        >
                          <Phone className="w-3 h-3 mr-1" />
                          Call
                        </Button>
                        <Button 
                          size="sm" 
                          variant="outline"
                          className="border-red-300 text-red-700 hover:bg-red-100"
                          onClick={() => window.location.href = `mailto:${alert.patient_email}?subject=High Pain Alert - ${alert.body_area.replace('_', ' ')} pain&body=Hi ${alert.patient_name.split(' ')[0]}, I noticed you reported high pain levels (${alert.pain_level}/10) in your ${alert.body_area.replace('_', ' ')}. Please let me know how you're feeling and if you'd like to schedule an appointment.`}
                        >
                          <Mail className="w-3 h-3 mr-1" />
                          Email
                        </Button>
                        <Button 
                          size="sm" 
                          onClick={() => handleAcknowledgeAlert(alert.id)}
                        >
                          Acknowledge
                        </Button>
                      </div>
                    </div>
                  ))}
                  {newAlerts.length === 0 && (
                    <div className="text-center py-8">
                      <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-3">
                        <Activity className="w-6 h-6 text-green-600" />
                      </div>
                      <p className="text-green-700 font-medium">All Clear!</p>
                      <p className="text-sm text-green-600">No high pain alerts at this time</p>
                    </div>
                  )}
                  {highPainAlerts.length > 3 && (
                    <Button variant="outline" className="w-full" size="sm">
                      View All {highPainAlerts.length} Alerts
                    </Button>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}

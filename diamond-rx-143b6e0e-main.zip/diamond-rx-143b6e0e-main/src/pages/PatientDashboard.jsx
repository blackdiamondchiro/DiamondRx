
import React from "react";
import { User } from "@/api/entities";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  Activity, 
  TrendingUp, 
  Heart, 
  Calendar,
  Plus,
  AlertTriangle,
  CheckCircle
} from "lucide-react";
import { format, subDays } from "date-fns";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from 'recharts';
import NewComplaintModal from "../components/pain/NewComplaintModal";
import DebugPanel from "../components/debug/DebugPanel";

export default function PatientDashboardPage() {
  const [user, setUser] = React.useState(null);
  const [painEntries, setPainEntries] = React.useState([]);
  const [exerciseCompletions, setExerciseCompletions] = React.useState([]);
  const [complaints, setComplaints] = React.useState([]);
  const [stats, setStats] = React.useState({
    avgPainLevel: 0,
    exercisesCompleted: 0,
    streakDays: 0
  });
  const [loading, setLoading] = React.useState(true);
  const [isModalOpen, setIsModalOpen] = React.useState(false);

  const calculateStreak = (completions) => {
    if (!completions || completions.length === 0) return 0;
    
    const sortedCompletions = [...completions].sort((a, b) => 
      new Date(b.created_date).getTime() - new Date(a.created_date).getTime()
    );
    
    const today = format(new Date(), 'yyyy-MM-dd');
    const yesterday = format(subDays(new Date(), 1), 'yyyy-MM-dd');
    
    const uniqueDates = [...new Set(sortedCompletions.map(c => 
      c.created_date?.split('T')[0]
    ))].sort((a, b) => new Date(b).getTime() - new Date(a).getTime());
    
    if (uniqueDates.length === 0) return 0;
    
    const hasActivityToday = uniqueDates.includes(today);
    const hasActivityYesterday = uniqueDates.includes(yesterday);
    
    if (!hasActivityToday && !hasActivityYesterday) return 0;
    
    let streak = 0;
    const startDate = hasActivityToday ? today : yesterday;
    const startIndex = uniqueDates.indexOf(startDate);
    
    if (startIndex !== -1) {
      streak = 1;
      for (let i = startIndex + 1; i < uniqueDates.length; i++) {
        const currentDate = new Date(uniqueDates[i-1]);
        const prevDate = new Date(uniqueDates[i]);
        const diffDays = Math.abs((currentDate - prevDate) / (1000 * 60 * 60 * 24));
        
        if (diffDays === 1) {
          streak++;
        } else {
          break;
        }
      }
    }
    
    return streak;
  };

  const loadDashboardData = React.useCallback(async () => {
    try {
      const userData = await User.me();
      setUser(userData);

      if (!userData || userData.account_type !== 'patient') {
        setLoading(false);
        return;
      }
      
      // Mock complaints data
      const mockComplaints = [
        {
          id: "1",
          patient_id: userData.id,
          body_area: "lower_back",
          status: "Active",
          created_date: subDays(new Date(), 10).toISOString()
        },
        {
          id: "2", 
          patient_id: userData.id,
          body_area: "neck",
          status: "Active",
          created_date: subDays(new Date(), 7).toISOString()
        },
        {
          id: "3",
          patient_id: userData.id,
          body_area: "right_knee", 
          status: "Active",
          created_date: subDays(new Date(), 5).toISOString()
        }
      ];

      // Mock pain entries with complaint_id references
      const mockPainEntries = [
        // Lower back entries
        {
          id: "1",
          complaint_id: "1",
          patient_id: userData.id,
          body_area: "lower_back",
          pain_level: 6,
          pain_quality: ["aching", "dull"],
          onset: "gradual",
          duration: "hours",
          frequency: "intermittent",
          notes: "Worse in the morning",
          triggers: "Sitting too long",
          created_date: new Date().toISOString(),
          created_by: userData.email
        },
        {
          id: "4",
          complaint_id: "1",
          patient_id: userData.id,
          body_area: "lower_back",
          pain_level: 7,
          pain_quality: ["aching"],
          created_date: subDays(new Date(), 1).toISOString(),
          created_by: userData.email
        },
        {
          id: "5",
          complaint_id: "1",
          patient_id: userData.id,
          body_area: "lower_back",
          pain_level: 5,
          pain_quality: ["dull"],
          created_date: subDays(new Date(), 2).toISOString(),
          created_by: userData.email
        },
        {
          id: "6",
          complaint_id: "1",
          patient_id: userData.id,
          body_area: "lower_back",
          pain_level: 8,
          pain_quality: ["sharp"],
          created_date: subDays(new Date(), 3).toISOString(),
          created_by: userData.email
        },
        // Neck entries
        {
          id: "2",
          complaint_id: "2",
          patient_id: userData.id,
          body_area: "neck",
          pain_level: 4,
          pain_quality: ["stiff", "aching"],
          onset: "sudden",
          duration: "minutes",
          frequency: "occasional",
          notes: "After sleeping wrong",
          triggers: "Poor pillow position",
          created_date: subDays(new Date(), 1).toISOString(),
          created_by: userData.email
        },
        {
          id: "7",
          complaint_id: "2",
          patient_id: userData.id,
          body_area: "neck",
          pain_level: 5,
          pain_quality: ["stiff"],
          created_date: subDays(new Date(), 2).toISOString(),
          created_by: userData.email
        },
        {
          id: "8",
          complaint_id: "2",
          patient_id: userData.id,
          body_area: "neck",
          pain_level: 3,
          pain_quality: ["aching"],
          created_date: subDays(new Date(), 4).toISOString(),
          created_by: userData.email
        },
        // Knee entries  
        {
          id: "3",
          complaint_id: "3",
          patient_id: userData.id,
          body_area: "right_knee",
          pain_level: 7,
          pain_quality: ["sharp", "shooting"],
          onset: "sudden",
          duration: "hours",
          frequency: "constant",
          notes: "Pain when walking",
          triggers: "Movement, weight bearing",
          created_date: subDays(new Date(), 2).toISOString(),
          created_by: userData.email
        },
        {
          id: "9",
          complaint_id: "3",
          patient_id: userData.id,
          body_area: "right_knee",
          pain_level: 6,
          pain_quality: ["sharp"],
          created_date: subDays(new Date(), 3).toISOString(),
          created_by: userData.email
        }
      ];

      // Mock exercise completions
      const mockExerciseCompletions = [
        {
          id: "1",
          patient_id: userData.id,
          exercise_id: "1",
          exercise_name: "Neck Stretches",
          helpful_rating: 4,
          pain_before: 6,
          pain_after: 3,
          notes: "Felt much better after",
          created_date: new Date().toISOString(),
          created_by: userData.email
        },
        {
          id: "2",
          patient_id: userData.id,
          exercise_id: "2",
          exercise_name: "Lower Back Strengthening",
          helpful_rating: 5,
          pain_before: 7,
          pain_after: 4,
          notes: "Great exercise, will continue",
          created_date: subDays(new Date(), 1).toISOString(),
          created_by: userData.email
        },
        {
          id: "3",
          patient_id: userData.id,
          exercise_id: "3",
          exercise_name: "Shoulder Blade Squeezes",
          helpful_rating: 3,
          pain_before: 5,
          pain_after: 4,
          notes: "Slight improvement",
          created_date: subDays(new Date(), 2).toISOString(),
          created_by: userData.email
        }
      ];

      setComplaints(mockComplaints);
      setPainEntries(mockPainEntries);
      setExerciseCompletions(mockExerciseCompletions);
        
      const avgPain = mockPainEntries.length > 0 ? 
          mockPainEntries.reduce((sum, entry) => sum + entry.pain_level, 0) / mockPainEntries.length : 0;

      setStats({
          avgPainLevel: avgPain,
          exercisesCompleted: mockExerciseCompletions.length,
          streakDays: calculateStreak(mockExerciseCompletions)
      });
    
    } catch (error) {
      console.error("Error loading dashboard data:", error);
    } finally {
      setLoading(false);
    }
  }, []);

  React.useEffect(() => {
    loadDashboardData();
  }, [loadDashboardData]);

  const getPainTrendData = () => {
    const last7Days = Array.from({ length: 7 }, (_, i) => {
      const date = subDays(new Date(), 6 - i);
      const dateStr = date.toISOString().split('T')[0];
      
      const dayData = {
        date: format(date, 'MMM d')
      };
      
      // For each active complaint, get pain data for this day
      complaints.forEach(complaint => {
        const dayEntries = painEntries.filter(entry => 
          entry.complaint_id === complaint.id && 
          entry.created_date?.split('T')[0] === dateStr
        );
        
        // Calculate average pain for this complaint on this day
        const avgPain = dayEntries.length > 0 
          ? dayEntries.reduce((sum, entry) => sum + entry.pain_level, 0) / dayEntries.length
          : null; // Use null so recharts doesn't connect lines across missing data
        
        // Use body area as the key, but only if there's data
        if (avgPain !== null) {
          dayData[complaint.body_area] = avgPain;
        }
      });
      
      return dayData;
    });
    
    return last7Days;
  };

  const getComplaintColors = () => {
    const colors = ['#3b82f6', '#ef4444', '#10b981', '#f59e0b', '#8b5cf6', '#06b6d4'];
    const complaintColors = {};
    complaints.forEach((complaint, index) => {
      complaintColors[complaint.body_area] = colors[index % colors.length];
    });
    return complaintColors;
  };

  const getLatestPainEntry = () => {
    if (painEntries.length === 0) return null;
    return [...painEntries].sort((a, b) => new Date(b.created_date).getTime() - new Date(a.created_date).getTime())[0];
  };

  const latestPainEntry = getLatestPainEntry();
  const needsAttention = latestPainEntry?.pain_level >= 7;

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
          <p className="mt-4 text-gray-600">Loading dashboard...</p>
        </div>
      </div>
    );
  }
  
  if (!user || user.account_type !== 'patient') {
    return null;
  }

  return (
    <div className="min-h-screen bg-gray-50 p-4 lg:p-8">
      <div className="max-w-7xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">
            Welcome back, {user?.full_name?.split(' ')[0] || 'there'}!
          </h1>
          <p className="text-gray-600">Here's your pain management overview</p>
        </div>

        {!user.provider_id && (
          <div className="mb-6 p-4 bg-blue-50 border border-blue-200 rounded-lg">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <AlertTriangle className="w-5 h-5 text-blue-600" />
                <div>
                  <p className="font-medium text-blue-900">Connect with a Provider</p>
                  <p className="text-sm text-blue-700">
                    Link your account to a healthcare provider to get personalized exercises and guidance.
                  </p>
                </div>
              </div> {/* Closing div for the flex items-center gap-3 */}
              <Link to={createPageUrl("FindProviders")}>
                <Button variant="outline" size="sm" className="bg-white">
                  Find a Provider
                </Button>
              </Link>
            </div>
          </div>
        )}

        {needsAttention && (
          <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-lg">
            <div className="flex items-center gap-3">
              <AlertTriangle className="w-5 h-5 text-red-600" />
              <div>
                <p className="font-medium text-red-900">High Pain Level Detected</p>
                <p className="text-sm text-red-700">
                  Your latest pain entry shows severe pain. Consider contacting your healthcare provider.
                </p>
              </div>
            </div>
          </div>
        )}

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card className="shadow-lg">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Average Pain Level</CardTitle>
              <Activity className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {stats.avgPainLevel.toFixed(1)}/10
              </div>
              <p className="text-xs text-muted-foreground">
                Based on recent entries
              </p>
            </CardContent>
          </Card>

          <Card className="shadow-lg">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Exercises Completed</CardTitle>
              <Heart className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.exercisesCompleted}</div>
              <p className="text-xs text-muted-foreground">
                This month
              </p>
            </CardContent>
          </Card>

          <Card className="shadow-lg">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Current Streak</CardTitle>
              <TrendingUp className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.streakDays} days</div>
              <p className="text-xs text-muted-foreground">
                Keep it up!
              </p>
            </CardContent>
          </Card>

          <Card className="shadow-lg">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Last Entry</CardTitle>
              <Calendar className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {latestPainEntry
                  ? format(new Date(latestPainEntry.created_date), 'MMM d')
                  : 'None'
                }
              </div>
              <p className="text-xs text-muted-foreground">
                Pain tracking
              </p>
            </CardContent>
          </Card>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2">
            <Card className="shadow-lg">
              <CardHeader>
                <CardTitle>Pain Trend by Complaint - Last 7 Days</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-64">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={getPainTrendData()}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="date" />
                      <YAxis domain={[0, 10]} />
                      <Tooltip 
                        formatter={(value, name) => [
                          `${value?.toFixed(1)}/10`, 
                          name.replace('_', ' ').replace(/\b\w/g, l => l.toUpperCase())
                        ]}
                        labelFormatter={(label) => `Date: ${label}`}
                      />
                      <Legend 
                        formatter={(value) => value.replace('_', ' ').replace(/\b\w/g, l => l.toUpperCase())}
                      />
                      {complaints.map((complaint) => (
                        <Line
                          key={complaint.body_area}
                          type="monotone"
                          dataKey={complaint.body_area}
                          stroke={getComplaintColors()[complaint.body_area]}
                          strokeWidth={3}
                          connectNulls={false}
                          dot={{ fill: getComplaintColors()[complaint.body_area], strokeWidth: 2, r: 5 }}
                          name={complaint.body_area}
                        />
                      ))}
                    </LineChart>
                  </ResponsiveContainer>
                </div>
                {complaints.length === 0 && (
                  <div className="flex items-center justify-center h-64 text-gray-500">
                    <div className="text-center">
                      <Activity className="w-12 h-12 mx-auto mb-3 text-gray-300" />
                      <p>No active complaints to track</p>
                      <p className="text-sm">Create a complaint to see pain trends</p>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          <div className="space-y-6">
            <Card className="shadow-lg">
              <CardHeader>
                <CardTitle>Quick Actions</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <Button className="w-full h-16 bg-blue-600 hover:bg-blue-700" onClick={() => setIsModalOpen(true)}>
                    <div className="text-center">
                      <Plus className="w-6 h-6 mx-auto mb-1" />
                      <span className="font-medium">Track Pain</span>
                    </div>
                  </Button>
                  <Link to={createPageUrl("Exercises")}>
                    <Button variant="outline" className="w-full h-16">
                      <div className="text-center">
                        <Heart className="w-6 h-6 mx-auto mb-1" />
                        <span className="font-medium">View Exercises</span>
                      </div>
                    </Button>
                  </Link>
                </div>
              </CardContent>
            </Card>

            <Card className="shadow-lg">
              <CardHeader>
                <CardTitle>Recent Activity</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {painEntries.length === 0 && exerciseCompletions.length === 0 && (
                    <div className="text-center py-8">
                      <Heart className="w-12 h-12 text-gray-300 mx-auto mb-4" />
                      <p className="text-gray-500 mb-4">
                        No activity yet. Start by tracking your pain!
                      </p>
                      <Button className="bg-blue-600 hover:bg-blue-700" onClick={() => setIsModalOpen(true)}>
                        <Plus className="w-4 h-4 mr-2" />
                        Track Your First Pain Entry
                      </Button>
                    </div>
                  )}
                  {painEntries.length > 0 && (
                    <>
                      <h3 className="text-lg font-medium text-gray-900">Recent Pain Entries</h3>
                      <ul className="space-y-2">
                        {[...painEntries]
                        .sort((a,b) => new Date(b.created_date).getTime() - new Date(a.created_date).getTime())
                        .slice(0, 5)
                        .map((entry, index) => (
                          <li key={index} className="flex items-center justify-between text-sm text-gray-700">
                            <span className="flex items-center gap-2">
                              <Activity className="w-4 h-4 text-blue-500" />
                              Pain Level: <Badge variant={entry.pain_level >= 7 ? "destructive" : entry.pain_level >= 4 ? "secondary" : "default"}>{entry.pain_level}/10</Badge>
                            </span>
                            <span className="text-xs text-gray-500">
                              {format(new Date(entry.created_date), 'MMM d, p')}
                            </span>
                          </li>
                        ))}
                      </ul>
                    </>
                  )}

                  {exerciseCompletions.length > 0 && (
                    <>
                      <h3 className="text-lg font-medium text-gray-900 mt-6">Recent Exercise Completions</h3>
                      <ul className="space-y-2">
                        {[...exerciseCompletions]
                        .sort((a,b) => new Date(b.created_date).getTime() - new Date(a.created_date).getTime())
                        .slice(0, 5)
                        .map((completion, index) => (
                          <li key={index} className="flex items-center justify-between text-sm text-gray-700">
                            <span className="flex items-center gap-2">
                              <CheckCircle className="w-4 h-4 text-green-500" />
                              Completed: <span className="font-medium">{completion.exercise_name || 'Unknown Exercise'}</span>
                            </span>
                            <span className="text-xs text-gray-500">
                              {format(new Date(completion.created_date), 'MMM d, p')}
                            </span>
                          </li>
                        ))}
                      </ul>
                    </>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
      {user && (
        <>
          <NewComplaintModal
            isOpen={isModalOpen}
            onClose={() => setIsModalOpen(false)}
            onSuccess={loadDashboardData}
            user={user}
          />
          <DebugPanel user={user} />
        </>
      )}
    </div>
  );
}



import React from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { User } from "@/api/entities";
import {
  Heart,
  Activity,
  Users,
  Settings,
  Menu,
  X,
  ChevronDown,
  LogOut,
  ListChecks,
  Home,
  BookOpen,
  BookMarked
} from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

export default function Layout({ children, currentPageName }) {
  const location = useLocation();
  const navigate = useNavigate();
  const [user, setUser] = React.useState(null);
  const [mobileMenuOpen, setMobileMenuOpen] = React.useState(false);
  const [loading, setLoading] = React.useState(true);
  const [authChecked, setAuthChecked] = React.useState(false);

  const loadUserAndRoute = React.useCallback(async () => {
    try {
      const userData = await User.me();
      setUser(userData);
      setAuthChecked(true);

      if (userData.account_type) {
        const publicOnlyPages = ['Home', 'RoleSelection', 'ProviderOnboarding'];
        if (publicOnlyPages.includes(currentPageName)) {
          const targetDashboard = userData.account_type === 'patient' ? "PatientDashboard" : "ProviderDashboard";
          navigate(createPageUrl(targetDashboard), { replace: true });
          return;
        }

        const patientPages = ["PatientDashboard", "Complaints", "ComplaintDetail", "Exercises", "FindProviders", "Settings"];
        const providerPages = ["ProviderDashboard", "PatientManagement", "ExerciseLibrary", "ProviderOnboarding", "Settings", "ICD10Library", "ExercisePrescriptions"];

        if (userData.account_type === 'patient' && !patientPages.includes(currentPageName)) {
          navigate(createPageUrl("PatientDashboard"), { replace: true });
          return;
        }

        if (userData.account_type === 'provider' && !providerPages.includes(currentPageName)) {
          navigate(createPageUrl("ProviderDashboard"), { replace: true });
          return;
        }
      } else {
        if (currentPageName !== 'RoleSelection' && currentPageName !== 'ProviderOnboarding') {
          navigate(createPageUrl("RoleSelection"), { replace: true });
          return;
        }
      }
    } catch (error) {
      setUser(null);
      setAuthChecked(true);
      const protectedPages = [
        "PatientDashboard", "ProviderDashboard", "Complaints", "ComplaintDetail", "Exercises", "MyComplaints",
        "PatientManagement", "ExerciseLibrary", "RoleSelection", "ProviderOnboarding", "Settings", "FindProviders", "ICD10Library", "ExercisePrescriptions"
      ];
      if (protectedPages.includes(currentPageName)) {
        navigate(createPageUrl("Home"), { replace: true });
        return;
      }
    } finally {
      setLoading(false);
    }
  }, [currentPageName, navigate]);

  React.useEffect(() => {
    loadUserAndRoute();
  }, [loadUserAndRoute, location.pathname]);

  const handleLogout = async () => {
    await User.logout();
    // Force a full page reload to clear all state and re-evaluate authentication.
    // This is more reliable than using navigate() for logout.
    window.location.href = createPageUrl("Home");
  };

  const patientNavItems = [
    {
      title: "Home",
      url: createPageUrl("PatientDashboard"),
      icon: Home,
      mobileTitle: "Dashboard"
    },
    {
      title: "Complaints",
      url: createPageUrl("Complaints"),
      icon: ListChecks,
      mobileTitle: "Complaints"
    },
    {
      title: "Exercises",
      url: createPageUrl("Exercises"),
      icon: Heart,
      mobileTitle: "Exercises"
    },
  ];

  const providerNavItems = [
    {
      title: "Home",
      url: createPageUrl("ProviderDashboard"),
      icon: Home,
      mobileTitle: "Dashboard"
    },
    {
      title: "Patient List",
      url: createPageUrl("PatientManagement"),
      icon: Users,
      mobileTitle: "Patients"
    },
    {
      title: "Exercise Library",
      url: createPageUrl("ExerciseLibrary"),
      icon: BookOpen,
      mobileTitle: "Exercises"
    },
    {
      title: "Prescriptions",
      url: createPageUrl("ExercisePrescriptions"),
      icon: Heart,
      mobileTitle: "Prescriptions"
    },
    {
      title: "ICD-10 Codes",
      url: createPageUrl("ICD10Library"),
      icon: BookMarked,
      mobileTitle: "ICD-10"
    },
  ];

  const navItems = user?.account_type === 'provider' ? providerNavItems : patientNavItems;

  if (loading || !authChecked) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
          <p className="mt-4 text-gray-600">Loading...</p>
        </div>
      </div>
    );
  }

  if (!user) {
    const publicPages = ['Home', 'RoleSelection', 'ProviderOnboarding'];
    if (publicPages.includes(currentPageName)) {
      return <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">{children}</div>;
    }
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Global Navigation Toolbar */}
      <nav className="fixed top-0 left-0 right-0 bg-white border-b border-gray-200 shadow-sm z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            {/* Logo/Brand */}
            <Link
              to={createPageUrl(user.account_type === 'patient' ? "PatientDashboard" : "ProviderDashboard")}
              className="flex items-center gap-3"
            >
              <div className="w-8 h-8 bg-gradient-to-r from-blue-600 to-indigo-600 rounded-lg flex items-center justify-center">
                <Heart className="w-5 h-5 text-white" />
              </div>
              <span className="text-lg font-bold text-gray-900 hidden sm:block">MoveWell Pro</span>
            </Link>

            {/* Desktop Navigation */}
            <div className="hidden md:flex items-center space-x-1">
              {navItems.map((item) => (
                <Link
                  key={item.title}
                  to={item.url}
                  className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                    location.pathname === item.url
                      ? 'bg-blue-50 text-blue-700 shadow-sm'
                      : 'text-gray-600 hover:bg-gray-50 hover:text-gray-900'
                  }`}
                >
                  <item.icon className="w-4 h-4" />
                  <span>{item.title}</span>
                </Link>
              ))}
            </div>

            {/* Mobile Navigation Button */}
            <div className="flex items-center gap-3">
              {/* User Profile Dropdown - Desktop */}
              <div className="hidden md:block">
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" size="sm" className="flex items-center gap-2">
                      <div className="w-6 h-6 bg-gray-200 rounded-full flex items-center justify-center">
                        <span className="text-xs font-medium text-gray-600">
                          {user.full_name ? user.full_name.charAt(0) : user.email.charAt(0)}
                        </span>
                      </div>
                      <ChevronDown className="w-4 h-4" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end" className="w-56">
                    <div className="px-2 py-1.5 text-sm text-gray-900 border-b border-gray-100">
                      <p className="font-medium truncate">{user.full_name || user.email}</p>
                      <p className="text-xs text-gray-500 capitalize">{user.account_type}</p>
                    </div>
                    <DropdownMenuItem asChild>
                      <Link to={createPageUrl("Settings")} className="cursor-pointer">
                        <Settings className="w-4 h-4 mr-2" />
                        Settings
                      </Link>
                    </DropdownMenuItem>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem
                      onClick={handleLogout}
                      className="text-red-600 focus:bg-red-50 focus:text-red-700 cursor-pointer"
                    >
                      <LogOut className="w-4 h-4 mr-2" />
                      Sign Out
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </div>

              {/* Mobile Menu Toggle */}
              <Button
                variant="ghost"
                size="icon"
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                className="md:hidden"
              >
                {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
              </Button>
            </div>
          </div>

          {/* Mobile Navigation Menu */}
          {mobileMenuOpen && (
            <div className="md:hidden border-t border-gray-200 bg-white">
              <div className="px-2 py-3 space-y-1">
                {navItems.map((item) => (
                  <Link
                    key={item.title}
                    to={item.url}
                    onClick={() => setMobileMenuOpen(false)}
                    className={`flex items-center gap-3 px-3 py-2 rounded-lg text-sm font-medium transition-colors ${
                      location.pathname === item.url
                        ? 'bg-blue-50 text-blue-700'
                        : 'text-gray-600 hover:bg-gray-50'
                    }`}
                  >
                    <item.icon className="w-5 h-5" />
                    <span>{item.mobileTitle || item.title}</span>
                  </Link>
                ))}

                {/* Mobile User Profile Section */}
                <div className="pt-3 border-t border-gray-100">
                  <div className="px-3 py-2 text-xs text-gray-500">
                    <p className="font-medium text-gray-900">{user.full_name || user.email}</p>
                    <p className="capitalize">{user.account_type} Account</p>
                  </div>
                  <Link
                    to={createPageUrl("Settings")}
                    onClick={() => setMobileMenuOpen(false)}
                    className="flex items-center gap-3 px-3 py-2 rounded-lg text-sm font-medium text-gray-600 hover:bg-gray-50"
                  >
                    <Settings className="w-5 h-5" />
                    <span>Settings</span>
                  </Link>
                  <button
                    onClick={() => {
                      setMobileMenuOpen(false);
                      handleLogout();
                    }}
                    className="w-full flex items-center gap-3 px-3 py-2 rounded-lg text-sm font-medium text-red-600 hover:bg-red-50"
                  >
                    <LogOut className="w-5 h-5" />
                    <span>Sign Out</span>
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      </nav>

      {/* Main Content with top padding to account for fixed toolbar */}
      <main className="pt-16">
        {children}
      </main>
    </div>
  );
}


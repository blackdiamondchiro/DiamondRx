
import React from "react";
import { User } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Heart, Stethoscope, Users, Activity, AlertTriangle, CheckCircle } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";

export default function RoleSelectionPage() {
  const navigate = useNavigate();
  const [loading, setLoading] = React.useState(false);
  const [user, setUser] = React.useState(null);
  const [error, setError] = React.useState("");
  const [success, setSuccess] = React.useState("");
  const [checkingExistingRole, setCheckingExistingRole] = React.useState(true);

  const checkExistingUser = React.useCallback(async () => {
    try {
      const userData = await User.me();
      setUser(userData);
      
      // If user already has an account type, redirect to their dashboard
      if (userData.account_type) {
        if (userData.account_type === 'patient') {
          navigate(createPageUrl("PatientDashboard"));
        } else {
          navigate(createPageUrl("ProviderDashboard"));
        }
        return;
      }
    } catch (error) {
      console.error("Error checking user:", error);
      setError("Unable to verify your account. Please try again.");
    } finally {
      setCheckingExistingRole(false);
    }
  }, [navigate]);

  React.useEffect(() => {
    checkExistingUser();
  }, [checkExistingUser]);

  const selectPatientRole = async () => {
    if (!user) {
      setError("User not found. Please refresh and try again.");
      return;
    }

    setLoading(true);
    setError("");
    setSuccess("");
    
    try {
      // Simply set the account type for patient - keep existing full_name if available
      const updateData = { account_type: 'patient' };
      
      // If user doesn't have a full name yet, we could prompt for it, but for now
      // we'll let them set it in their settings after account creation
      await User.updateMyUserData(updateData);
      
      setSuccess(`Account successfully configured as patient. Redirecting to your dashboard...`);
      
      // Navigate to patient dashboard after short delay
      setTimeout(() => {
        navigate(createPageUrl("PatientDashboard"));
      }, 1500);
      
    } catch (error) {
      console.error("Error setting account type:", error);
      setError("Unable to set account type. Please try again.");
      setLoading(false);
    }
  };

  const selectProviderRole = () => {
    // Redirect to provider onboarding instead of directly setting account type
    navigate(createPageUrl("ProviderOnboarding"));
  };

  if (checkingExistingRole) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-indigo-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
          <p className="mt-4 text-gray-600">Verifying your account...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-indigo-50 flex items-center justify-center p-4">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-12">
          <div className="flex justify-center mb-6">
            <div className="w-16 h-16 bg-gradient-to-r from-blue-600 to-indigo-600 rounded-2xl flex items-center justify-center shadow-lg">
              <Heart className="w-8 h-8 text-white" />
            </div>
          </div>
          <h1 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            Welcome to PainTracker Pro
          </h1>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Choose your account type to get started with personalized pain management
          </p>
          {user && (
            <div className="mt-4 p-3 bg-blue-50 border border-blue-200 rounded-lg max-w-md mx-auto">
              <p className="text-sm text-blue-800">
                <strong>Email:</strong> {user.email}
              </p>
              <p className="text-xs text-blue-600 mt-1">
                This email will be associated with your selected account type
              </p>
            </div>
          )}
        </div>

        {error && (
          <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-lg max-w-2xl mx-auto">
            <div className="flex items-center gap-3">
              <AlertTriangle className="w-5 h-5 text-red-600 flex-shrink-0" />
              <p className="text-red-700 font-medium">{error}</p>
            </div>
          </div>
        )}

        {success && (
          <div className="mb-6 p-4 bg-green-50 border border-green-200 rounded-lg max-w-2xl mx-auto">
            <div className="flex items-center gap-3">
              <CheckCircle className="w-5 h-5 text-green-600 flex-shrink-0" />
              <p className="text-green-700 font-medium">{success}</p>
            </div>
          </div>
        )}

        <div className="grid md:grid-cols-2 gap-8">
          <Card className="border-2 border-transparent hover:border-blue-200 transition-all duration-300 cursor-pointer transform hover:scale-105 shadow-lg">
            <CardHeader className="text-center pb-6">
              <div className="w-16 h-16 bg-blue-100 rounded-2xl flex items-center justify-center mx-auto mb-4">
                <Activity className="w-8 h-8 text-blue-600" />
              </div>
              <CardTitle className="text-2xl font-bold text-gray-900">I'm a Patient</CardTitle>
              <CardDescription className="text-gray-600 text-base">
                Track your pain, get exercise recommendations, and connect with healthcare providers
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-3 mb-6">
                <div className="flex items-center gap-3">
                  <div className="w-2 h-2 bg-blue-600 rounded-full"></div>
                  <span className="text-gray-700">Interactive body map pain tracking</span>
                </div>
                <div className="flex items-center gap-3">
                  <div className="w-2 h-2 bg-blue-600 rounded-full"></div>
                  <span className="text-gray-700">Personalized exercise recommendations</span>
                </div>
                <div className="flex items-center gap-3">
                  <div className="w-2 h-2 bg-blue-600 rounded-full"></div>
                  <span className="text-gray-700">Progress tracking and analytics</span>
                </div>
                <div className="flex items-center gap-3">
                  <div className="w-2 h-2 bg-blue-600 rounded-full"></div>
                  <span className="text-gray-700">Direct provider communication</span>
                </div>
              </div>
              <Button 
                onClick={selectPatientRole} 
                disabled={loading}
                className="w-full bg-blue-600 hover:bg-blue-700 text-white py-3 text-lg font-medium rounded-xl"
              >
                {loading ? 'Setting up...' : 'Continue as Patient'}
              </Button>
            </CardContent>
          </Card>

          <Card className="border-2 border-transparent hover:border-green-200 transition-all duration-300 cursor-pointer transform hover:scale-105 shadow-lg">
            <CardHeader className="text-center pb-6">
              <div className="w-16 h-16 bg-green-100 rounded-2xl flex items-center justify-center mx-auto mb-4">
                <Stethoscope className="w-8 h-8 text-green-600" />
              </div>
              <CardTitle className="text-2xl font-bold text-gray-900">I'm a Healthcare Provider</CardTitle>
              <CardDescription className="text-gray-600 text-base">
                Manage patients, create exercise libraries, and monitor pain levels
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-3 mb-6">
                <div className="flex items-center gap-3">
                  <div className="w-2 h-2 bg-green-600 rounded-full"></div>
                  <span className="text-gray-700">Patient management dashboard</span>
                </div>
                <div className="flex items-center gap-3">
                  <div className="w-2 h-2 bg-green-600 rounded-full"></div>
                  <span className="text-gray-700">Custom exercise library creation</span>
                </div>
                <div className="flex items-center gap-3">
                  <div className="w-2 h-2 bg-green-600 rounded-full"></div>
                  <span className="text-gray-700">Real-time pain level alerts</span>
                </div>
                <div className="flex items-center gap-3">
                  <div className="w-2 h-2 bg-green-600 rounded-full"></div>
                  <span className="text-gray-700">Comprehensive patient analytics</span>
                </div>
              </div>
              <Button 
                onClick={selectProviderRole} 
                disabled={loading}
                className="w-full bg-green-600 hover:bg-green-700 text-white py-3 text-lg font-medium rounded-xl"
              >
                Continue as Provider
              </Button>
            </CardContent>
          </Card>
        </div>

        <div className="text-center mt-8">
          <div className="p-4 bg-amber-50 border border-amber-200 rounded-lg max-w-2xl mx-auto">
            <p className="text-sm text-amber-800 font-medium">
              Important: Your account type will be associated with your email address
            </p>
            <p className="text-xs text-amber-700 mt-1">
              Each email can only be used for one account type (Patient or Provider)
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}

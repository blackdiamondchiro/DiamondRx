
import React, { useState, useEffect, useCallback } from "react";
import { Exercise } from "@/api/entities";
import { User } from "@/api/entities";
import { ExerciseCompletion } from "@/api/entities";
import { Complaint } from "@/api/entities";
import { ExerciseAssigned } from "@/api/entities";
import { SYSTEM_EXERCISE_LIBRARY } from "../components/data/SystemExercises";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue
} from "@/components/ui/select";
import { Heart, Search, Play, Clock, RotateCcw, CheckCircle, Star, Hash, Calendar, ArrowLeft } from "lucide-react";
import ExerciseDetailModal from "../components/patient/ExerciseDetailModal";
import { useLocation, useNavigate, Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import _ from 'lodash';

export default function ExercisesPage() {
  const [user, setUser] = useState(null);
  const [allExercises, setAllExercises] = useState([]);
  const [filteredExercises, setFilteredExercises] = useState([]);
  const [completions, setCompletions] = useState([]);
  const [selectedExercise, setSelectedExercise] = useState(null);
  const [loading, setLoading] = useState(true);
  const [filters, setFilters] = useState({
    body_area: "all",
    difficulty: "all",
    search: ""
  });
  const [complaintInfo, setComplaintInfo] = useState(null);
  
  const location = useLocation();
  const navigate = useNavigate();

  const loadData = useCallback(async () => {
    setLoading(true);
    try {
      const userData = await User.me();
      if (userData.account_type !== 'patient') {
        setLoading(false);
        return;
      }
      setUser(userData);

      // Fetch all possible exercises (system + provider)
      let providerExercises = [];
      if (userData.provider_id) {
        try {
          providerExercises = await Exercise.filter({ provider_id: userData.provider_id });
        } catch (e) {
          console.warn("Could not fetch provider exercises.", e);
        }
      }
      const combinedExercises = _.uniqBy([...SYSTEM_EXERCISE_LIBRARY, ...providerExercises], 'name');
      
      // Check for complaint filter from URL
      const params = new URLSearchParams(location.search);
      const complaintId = params.get('complaint_id');

      let exercisesToShow;

      if (complaintId) {
        const [complaint, assigned] = await Promise.all([
            Complaint.get(complaintId),
            ExerciseAssigned.filter({ complaint_id: complaintId })
        ]);
        setComplaintInfo({
          ...complaint,
          isPrescribed: assigned.some(a => a.source === 'provider')
        });
        const assignedIds = assigned.map(a => a.exercise_id);
        // Find the full exercise objects from the combined library
        exercisesToShow = combinedExercises.filter(ex => assignedIds.includes(ex.id) || assignedIds.includes(ex.name)); // Also check by name for robustness
      } else {
        // If no complaint ID, show all exercises from the library
        exercisesToShow = combinedExercises;
        setComplaintInfo(null);
      }
      
      setAllExercises(exercisesToShow);
      setFilteredExercises(exercisesToShow);
      
      // Fetch user's completions
      const userCompletions = await ExerciseCompletion.filter({ patient_id: userData.id });
      setCompletions(userCompletions);

    } catch (error) {
      console.error("Error loading data:", error);
    } finally {
      setLoading(false);
    }
  }, [location.search]);

  const filterExercises = useCallback(() => {
    // If viewing for a specific complaint, don't apply client-side filters
    if (complaintInfo) return;

    let filtered = allExercises;

    if (filters.body_area !== "all") {
      const targetArea = filters.body_area; // e.g., "shoulder", "hip"
      filtered = filtered.filter(ex => {
        if (!ex.body_areas) return false;
        // Check if any of the exercise's body areas match the selected filter area,
        // accounting for 'left_' or 'right_' prefixes that might still exist in the exercise data.
        return ex.body_areas.some(exerciseArea => {
          return exerciseArea === targetArea ||
                 exerciseArea === `left_${targetArea}` ||
                 exerciseArea === `right_${targetArea}`;
        });
      });
    }
    if (filters.difficulty !== "all") {
      filtered = filtered.filter(ex => ex.difficulty === filters.difficulty);
    }
    if (filters.search) {
      filtered = filtered.filter(ex =>
        ex.name?.toLowerCase().includes(filters.search.toLowerCase()) ||
        ex.description?.toLowerCase().includes(filters.search.toLowerCase())
      );
    }
    setFilteredExercises(filtered);
  }, [allExercises, filters, complaintInfo]);

  useEffect(() => {
    loadData();
  }, [loadData]);

  useEffect(() => {
    if (!complaintInfo) { // Only apply filters if not in complaint-specific view
        filterExercises();
    }
  }, [filters, allExercises, complaintInfo, filterExercises]);

  const handleCompleteExercise = async (exerciseId, completionData) => {
    try {
      const newCompletion = await ExerciseCompletion.create({
        patient_id: user.id,
        exercise_id: exerciseId,
        complaint_id: complaintInfo?.id || null, // Associate completion with complaint if applicable
        ...completionData
      });
      setCompletions(prev => [newCompletion, ...prev]);
      alert("Exercise completion recorded successfully!");
    } catch (error) {
      console.error("Error recording exercise completion:", error);
      alert("Error recording exercise completion. Please try again.");
    }
  };

  const getExerciseCompletions = (exerciseId) => {
    return completions.filter(c => c.exercise_id === exerciseId);
  };

  const bodyAreas = [
    "head", "neck", "shoulder", "arm", "chest", "upper_back", 
    "lower_back", "abdomen", "hip", "thigh", "knee", 
    "calf", "foot"
  ];

  const difficultyColors = {
    beginner: "bg-green-100 text-green-800 border-green-200",
    intermediate: "bg-yellow-100 text-yellow-800 border-yellow-200",
    advanced: "bg-red-100 text-red-800 border-red-200"
  };

  if (loading) {
    return <div className="min-h-screen bg-gray-50 flex items-center justify-center">
      <div className="text-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
        <p className="mt-4 text-gray-600">Loading exercises...</p>
      </div>
    </div>;
  }

  if (!user || user.account_type !== 'patient') {
    return null;
  }

  return (
    <div className="min-h-screen bg-gray-50 p-4 lg:p-8">
      <div className="max-w-7xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">
            {complaintInfo ? (complaintInfo.isPrescribed ? "Prescribed Exercises" : "Suggested Exercises") : "Exercise Library"}
          </h1>
          <p className="text-gray-600">
            {complaintInfo 
                ? (complaintInfo.isPrescribed 
                    ? `Exercises prescribed by your provider for your ${complaintInfo.body_area.replace(/_/g, ' ')}.`
                    : `Suggested exercises to help with your ${complaintInfo.body_area.replace(/_/g, ' ')}.`)
                : "Browse and complete exercises for your recovery and wellness"
            }
          </p>
        </div>

        {complaintInfo ? (
          <Card className={`mb-8 shadow-lg ${complaintInfo.isPrescribed ? 'bg-green-50 border-green-200' : 'bg-blue-50 border-blue-200'}`}>
            <CardContent className="p-4 flex items-center justify-between">
              <div>
                <h2 className={`font-bold ${complaintInfo.isPrescribed ? 'text-green-900' : 'text-blue-900'} capitalize`}>
                  {complaintInfo.isPrescribed ? 'Provider Prescribed' : 'System Suggested'} Exercises for: {complaintInfo.body_area.replace(/_/g, ' ')} Complaint
                </h2>
                <p className={`text-sm ${complaintInfo.isPrescribed ? 'text-green-700' : 'text-blue-700'}`}>
                  {complaintInfo.isPrescribed 
                    ? 'These exercises were specifically prescribed by your healthcare provider.'
                    : 'These exercises were automatically suggested based on your complaint.'
                  }
                </p>
              </div>
              <Link to={createPageUrl("Exercises")}>
                  <Button variant="outline" className="bg-white">
                      <ArrowLeft className="w-4 h-4 mr-2" />
                      View All Exercises
                  </Button>
              </Link>
            </CardContent>
          </Card>
        ) : (
          <Card className="shadow-lg mb-8">
            <CardHeader>
              <CardTitle>Find Exercises</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <div>
                  <Label htmlFor="search">Search</Label>
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                    <Input
                      id="search"
                      placeholder="Search exercises..."
                      value={filters.search}
                      onChange={(e) => setFilters(prev => ({ ...prev, search: e.target.value }))}
                      className="pl-10"
                    />
                  </div>
                </div>
                <div>
                  <Label htmlFor="body_area">Body Area</Label>
                  <Select
                    value={filters.body_area}
                    onValueChange={(value) => setFilters(prev => ({ ...prev, body_area: value }))}
                  >
                    <SelectTrigger><SelectValue placeholder="All areas" /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Areas</SelectItem>
                      {bodyAreas.map((area) => (
                        <SelectItem key={area} value={area} className="capitalize">
                          {area.replace(/_/g, ' ')}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="difficulty">Difficulty</Label>
                  <Select
                    value={filters.difficulty}
                    onValueChange={(value) => setFilters(prev => ({ ...prev, difficulty: value }))}
                  >
                    <SelectTrigger><SelectValue placeholder="All levels" /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Levels</SelectItem>
                      <SelectItem value="beginner">Beginner</SelectItem>
                      <SelectItem value="intermediate">Intermediate</SelectItem>
                      <SelectItem value="advanced">Advanced</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="flex items-end">
                  <Button
                    variant="outline"
                    className="w-full"
                    onClick={() => setFilters({ body_area: "all", difficulty: "all", search: "" })}
                  >
                    Clear Filters
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {filteredExercises.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredExercises.map((exercise) => {
              const exerciseCompletions = getExerciseCompletions(exercise.id);
              const sortedCompletions = [...exerciseCompletions].sort((a, b) => new Date(b.created_date) - new Date(a.created_date));
              const lastCompletion = sortedCompletions[0];

              return (
                <Card key={exercise.id} className="shadow-lg hover:shadow-xl transition-shadow duration-300 flex flex-col">
                  <CardHeader className="pb-3">
                    <div className="flex justify-between items-start">
                      <CardTitle className="text-lg font-bold text-gray-900 line-clamp-2">
                        {exercise.name}
                      </CardTitle>
                      {exerciseCompletions.length > 0 && (
                        <Badge className="bg-green-100 text-green-800 border-green-200">
                          <CheckCircle className="w-3 h-3 mr-1" />
                          Done
                        </Badge>
                      )}
                    </div>
                    <div className="flex gap-2 mt-2">
                      <Badge className={difficultyColors[exercise.difficulty]} variant="outline">
                        {exercise.difficulty}
                      </Badge>
                      {exercise.video_url && (
                        <Badge variant="outline" className="bg-purple-100 text-purple-800 border-purple-200">
                          <Play className="w-3 h-3 mr-1" />
                          Video
                        </Badge>
                      )}
                    </div>
                  </CardHeader>

                  <CardContent className="pt-0 flex-grow flex flex-col">
                    {exercise.description && (
                      <p className="text-gray-600 text-sm mb-4 line-clamp-3 flex-grow">
                        {exercise.description}
                      </p>
                    )}
                    <div className="space-y-4">
                      <div className="mb-4">
                        <p className="text-xs font-medium text-gray-500 mb-2">Target Areas:</p>
                        <div className="flex flex-wrap gap-1">
                          {exercise.body_areas?.slice(0, 3).map((area, index) => (
                            <Badge key={index} variant="secondary" className="text-xs capitalize">
                              {/* Display areas, replacing underscores for readability.
                                 This handles both simplified areas (e.g., 'shoulder') and
                                 legacy 'left_shoulder'/'right_shoulder' if they exist in data. */}
                              {area.replace(/_/g, ' ')}
                            </Badge>
                          ))}
                          {exercise.body_areas?.length > 3 && (
                            <Badge variant="secondary" className="text-xs">
                              +{exercise.body_areas.length - 3} more
                            </Badge>
                          )}
                        </div>
                      </div>

                      {lastCompletion && (
                        <div className="p-2 bg-green-50 border border-green-200 rounded-lg">
                          <div className="flex items-center justify-between">
                            <span className="text-sm text-green-800">Last completed</span>
                            {lastCompletion.helpful_rating && (
                              <div className="flex items-center gap-1">
                                <Star className="w-3 h-3 text-yellow-500" />
                                <span className="text-xs text-green-700">{lastCompletion.helpful_rating}/5</span>
                              </div>
                            )}
                          </div>
                        </div>
                      )}
                    </div>
                    <Button
                      className="w-full bg-blue-600 hover:bg-blue-700 mt-auto"
                      onClick={() => setSelectedExercise(exercise)}
                    >
                      View Exercise
                    </Button>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        ) : (
          <Card className="shadow-lg">
            <CardContent className="text-center py-12">
              <Heart className="w-16 h-16 text-gray-300 mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-gray-900 mb-2">
                No Exercises Found
              </h3>
              <p className="text-gray-600">
                {complaintInfo
                  ? 'No exercises were assigned for this specific complaint.'
                  : 'Try adjusting your search or filter criteria.'
                }
              </p>
            </CardContent>
          </Card>
        )}

        <ExerciseDetailModal
          exercise={selectedExercise}
          isOpen={!!selectedExercise}
          onClose={() => setSelectedExercise(null)}
          onComplete={handleCompleteExercise}
          completions={selectedExercise ? getExerciseCompletions(selectedExercise.id) : []}
        />
      </div>
    </div>
  );
}

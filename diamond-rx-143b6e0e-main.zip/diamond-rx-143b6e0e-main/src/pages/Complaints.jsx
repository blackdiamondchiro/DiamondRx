
import React, { useState, useEffect, useCallback } from "react";
import { Complaint } from "@/api/entities";
import { User } from "@/api/entities";
import { ExerciseAssigned } from "@/api/entities";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Plus, Edit, FileText, Activity, Calendar, Heart } from "lucide-react";
import { format, formatDistanceToNow } from "date-fns";
import NewComplaintModal from "../components/pain/NewComplaintModal";
import UpdateComplaintModal from "../components/pain/UpdateComplaintModal";
import ComplaintHistoryModal from "../components/pain/ComplaintHistoryModal";
import { useToast } from "@/components/ui/use-toast";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import _ from 'lodash';

export default function ComplaintsPage() {
  const [user, setUser] = useState(null);
  const [complaints, setComplaints] = useState([]);
  const [assignedExercises, setAssignedExercises] = useState({});
  const [loading, setLoading] = useState(true);
  const [isNewComplaintModalOpen, setIsNewComplaintModalOpen] = useState(false);
  const [isUpdateComplaintModalOpen, setIsUpdateComplaintModalOpen] = useState(false);
  const [isHistoryModalOpen, setIsHistoryModalOpen] = useState(false);
  const [selectedComplaint, setSelectedComplaint] = useState(null);
  const { toast } = useToast();

  const loadComplaints = useCallback(async () => {
    setLoading(true);
    try {
      let currentUser = user;
      if (!currentUser) {
        currentUser = await User.me();
        setUser(currentUser);
      }

      if (currentUser && currentUser.account_type === 'patient') {
        const [userComplaints, allAssigned] = await Promise.all([
          Complaint.filter({ patient_id: currentUser.id }, '-updated_date'),
          ExerciseAssigned.list()
        ]);
        
        const groupedAssignments = _.groupBy(allAssigned, 'complaint_id');
        setAssignedExercises(groupedAssignments);
        setComplaints(userComplaints);
      }
    } catch (error) {
      console.error("Failed to load complaints:", error);
      toast({
        title: "Error",
        description: "Failed to load complaints. Please try again.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  }, [user, toast]);

  useEffect(() => {
    loadComplaints();
  }, [loadComplaints]);

  const handleSuccess = (message) => {
    toast({
      title: "Success!",
      description: message,
      variant: "success",
    });
    loadComplaints();
  };

  const handleUpdateComplaint = (complaint) => {
    setSelectedComplaint(complaint);
    setIsUpdateComplaintModalOpen(true);
  };

  const handleViewHistory = (complaint) => {
    setSelectedComplaint(complaint);
    setIsHistoryModalOpen(true);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
          <p className="mt-4 text-gray-600">Loading complaints...</p>
        </div>
      </div>
    );
  }

  if (!user || user.account_type !== 'patient') {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <p className="text-red-600 text-lg">Not authorized to view this page</p>
        </div>
      </div>
    );
  }

  const activeComplaints = complaints.filter(c => c.status === 'Active');
  const resolvedComplaints = complaints.filter(c => c.status === 'Resolved');

  return (
    <div className="min-h-screen bg-gray-50 p-4 lg:p-8">
      <div className="max-w-4xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Pain Complaints</h1>
          <p className="text-gray-600">
            Track your pain complaints and monitor your progress over time.
          </p>
        </div>

        {/* Action Cards */}
        <div className="grid md:grid-cols-2 gap-6 mb-8">
          <Card 
            className="cursor-pointer hover:shadow-lg transition-shadow border-2 border-transparent hover:border-blue-200"
            onClick={() => setIsNewComplaintModalOpen(true)}
          >
            <CardContent className="p-6">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                  <Plus className="w-6 h-6 text-blue-600" />
                </div>
                <div>
                  <h3 className="text-lg font-semibold text-gray-900">New Complaint</h3>
                  <p className="text-sm text-gray-600">Report pain in a new body area</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className={`cursor-pointer hover:shadow-lg transition-shadow border-2 border-transparent ${
            activeComplaints.length > 0 ? 'hover:border-green-200' : 'opacity-50 cursor-not-allowed'
          }`}>
            <CardContent 
              className="p-6" 
              onClick={() => {
                if (activeComplaints.length === 1) {
                  // If only one complaint, open it directly
                  handleUpdateComplaint(activeComplaints[0]);
                } else if (activeComplaints.length > 1) {
                  // If multiple, open the selection modal
                  setIsUpdateComplaintModalOpen(true);
                }
              }}
              disabled={activeComplaints.length === 0}
            >
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                  <Edit className="w-6 h-6 text-green-600" />
                </div>
                <div>
                  <h3 className="text-lg font-semibold text-gray-900">Update Existing Complaint</h3>
                  <p className="text-sm text-gray-600">
                    {activeComplaints.length > 0 
                      ? `Log progress for ${activeComplaints.length} active complaint${activeComplaints.length > 1 ? 's' : ''}`
                      : 'No active complaints to update'
                    }
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Active Complaints */}
        {activeComplaints.length > 0 && (
          <div className="mb-8">
            <h2 className="text-xl font-semibold mb-4">Active Complaints</h2>
            <div className="grid gap-4">
              {activeComplaints.map(complaint => {
                const assignmentsForComplaint = assignedExercises[complaint.id] || [];
                const hasExercises = assignmentsForComplaint.length > 0;
                const isPrescribed = assignmentsForComplaint.some(a => a.source === 'provider');

                return (
                  <Card key={complaint.id} className="hover:shadow-md transition-shadow">
                    <CardContent className="p-6">
                      <div className="flex justify-between items-start mb-4">
                        <div>
                          <h3 className="font-semibold capitalize text-lg text-blue-700">
                            {complaint.body_area.replace(/_/g, ' ')}
                          </h3>
                          <div className="flex items-center gap-4 text-sm text-gray-500 mt-1">
                            <div className="flex items-center gap-1">
                              <Calendar className="w-4 h-4" />
                              Started: {format(new Date(complaint.created_date), 'MMM d, yyyy')}
                            </div>
                            <div className="flex items-center gap-1">
                              <Activity className="w-4 h-4" />
                              Updated: {formatDistanceToNow(new Date(complaint.updated_date || complaint.created_date), { addSuffix: true })}
                            </div>
                          </div>
                        </div>
                        <Badge variant="destructive">Active</Badge>
                      </div>
                      
                      <div className="flex gap-3 flex-wrap">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleUpdateComplaint(complaint)}
                        >
                          Log Update
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleViewHistory(complaint)}
                        >
                          <FileText className="w-4 h-4 mr-1" />
                          View History
                        </Button>
                        {hasExercises && (
                          <Link to={createPageUrl(`Exercises?complaint_id=${complaint.id}`)}>
                            <Button
                              variant={isPrescribed ? "default" : "outline"}
                              size="sm"
                              className={isPrescribed
                                ? "bg-green-600 hover:bg-green-700 text-white"
                                : "bg-blue-50 text-blue-700 border-blue-200 hover:bg-blue-100"
                              }
                            >
                                <Heart className="w-4 h-4 mr-1" />
                                {isPrescribed ? 'View Prescribed Exercises' : 'View Suggested Exercises'}
                            </Button>
                          </Link>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                )
              })}
            </div>
          </div>
        )}

        {/* Resolved Complaints */}
        {resolvedComplaints.length > 0 && (
          <div className="mb-8">
            <h2 className="text-xl font-semibold mb-4">Resolved Complaints</h2>
            <div className="grid gap-4">
              {resolvedComplaints.map(complaint => (
                <Card 
                  key={complaint.id} 
                  className="hover:shadow-md transition-shadow cursor-pointer"
                  onClick={() => handleViewHistory(complaint)}
                >
                  <CardContent 
                    className="p-4 flex justify-between items-center"
                  >
                    <div>
                      <h3 className="font-semibold capitalize text-gray-700">
                        {complaint.body_area.replace(/_/g, ' ')}
                      </h3>
                      <p className="text-sm text-gray-500">
                        Resolved: {format(new Date(complaint.updated_date), 'MMM d, yyyy')}
                      </p>
                    </div>
                    <Badge variant="default" className="bg-green-600">Resolved</Badge>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        )}

        {/* Empty State */}
        {complaints.length === 0 && !loading && (
          <Card className="shadow-lg">
            <CardContent className="text-center py-12">
              <FileText className="w-16 h-16 text-gray-300 mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-gray-900 mb-2">
                No complaints recorded yet
              </h3>
              <p className="text-gray-600 mb-6">
                Start by creating your first complaint to track your pain and progress.
              </p>
              <Button onClick={() => setIsNewComplaintModalOpen(true)}>
                <Plus className="w-4 h-4 mr-2" />
                Create First Complaint
              </Button>
            </CardContent>
          </Card>
        )}
      </div>
      
      {user && (
        <>
          <NewComplaintModal 
            isOpen={isNewComplaintModalOpen}
            onClose={() => setIsNewComplaintModalOpen(false)}
            onSuccess={() => handleSuccess("Your new complaint has been saved.")}
            user={user}
          />
          <UpdateComplaintModal
            isOpen={isUpdateComplaintModalOpen}
            onClose={() => {
              setIsUpdateComplaintModalOpen(false);
              setSelectedComplaint(null);
            }}
            onSuccess={() => handleSuccess("Your complaint has been updated.")}
            user={user}
            complaints={activeComplaints}
            initialComplaint={selectedComplaint}
          />
          <ComplaintHistoryModal
            isOpen={isHistoryModalOpen}
            onClose={() => {
              setIsHistoryModalOpen(false);
              setSelectedComplaint(null);
            }}
            user={user}
            complaint={selectedComplaint}
          />
        </>
      )}
    </div>
  );
}

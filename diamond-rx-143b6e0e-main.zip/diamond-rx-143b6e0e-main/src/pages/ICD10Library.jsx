import React, { useState, useEffect } from "react";
import { ICD10Code } from "@/api/entities";
import { User } from "@/api/entities";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { BookMarked, Search, Plus, AlertTriangle, CheckCircle } from "lucide-react";
import _ from 'lodash';

export default function ICD10LibraryPage() {
  const [user, setUser] = useState(null);
  const [codes, setCodes] = useState([]);
  const [filteredCodes, setFilteredCodes] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [categoryFilter, setCategoryFilter] = useState("all");
  const [showForm, setShowForm] = useState(false);
  const [loading, setLoading] = useState(true);
  const [formData, setFormData] = useState({
    code: "",
    description: "",
    category: ""
  });
  const [formLoading, setFormLoading] = useState(false);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");

  useEffect(() => {
    loadData();
  }, []);

  useEffect(() => {
    const lowercasedFilter = searchTerm.toLowerCase();
    let filtered = codes;

    // Filter by search term
    if (searchTerm) {
      filtered = filtered.filter(item => {
        return (
          item.code.toLowerCase().includes(lowercasedFilter) ||
          item.description.toLowerCase().includes(lowercasedFilter)
        );
      });
    }

    // Filter by category
    if (categoryFilter !== "all") {
      filtered = filtered.filter(item => item.category === categoryFilter);
    }

    setFilteredCodes(filtered);
  }, [searchTerm, categoryFilter, codes]);

  const loadData = async () => {
    try {
      const userData = await User.me();
      if (userData.account_type !== 'provider') {
        setLoading(false);
        return;
      }
      setUser(userData);

      const allCodes = await ICD10Code.list();
      setCodes(allCodes);
    } catch (error) {
      console.error("Error loading ICD-10 codes:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!formData.code || !formData.description) {
      setError("Code and description are required.");
      return;
    }

    setFormLoading(true);
    setError("");
    setSuccess("");

    try {
      // Check if code already exists
      const existingCode = codes.find(c => c.code.toLowerCase() === formData.code.toLowerCase());
      if (existingCode) {
        setError("This ICD-10 code already exists in the library.");
        setFormLoading(false);
        return;
      }

      await ICD10Code.create({
        code: formData.code.toUpperCase(),
        description: formData.description,
        category: formData.category || "Other"
      });

      setSuccess("ICD-10 code added successfully!");
      setFormData({ code: "", description: "", category: "" });
      setShowForm(false);
      await loadData();
    } catch (err) {
      setError("Failed to add ICD-10 code. Please try again.");
      console.error(err);
    } finally {
      setFormLoading(false);
    }
  };

  const getUniqueCategories = () => {
    return _.uniq(codes.map(code => code.category).filter(Boolean)).sort();
  };

  const groupedCodes = _.groupBy(filteredCodes, 'category');

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-green-600 mx-auto"></div>
          <p className="mt-4 text-gray-600">Loading ICD-10 Library...</p>
        </div>
      </div>
    );
  }

  if (!user || user.account_type !== 'provider') {
    return null;
  }

  return (
    <div className="min-h-screen bg-gray-50 p-4 lg:p-8">
      <div className="max-w-6xl mx-auto">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 gap-4">
          <div>
            <h1 className="text-3xl font-bold text-gray-900 mb-2">ICD-10 Code Library</h1>
            <p className="text-gray-600">Browse and manage diagnostic codes for your practice</p>
          </div>
          <Dialog open={showForm} onOpenChange={setShowForm}>
            <DialogTrigger asChild>
              <Button className="bg-green-600 hover:bg-green-700">
                <Plus className="w-4 h-4 mr-2" />
                Add ICD-10 Code
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl">
              <DialogHeader>
                <DialogTitle>Add New ICD-10 Code</DialogTitle>
              </DialogHeader>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <Label htmlFor="code">ICD-10 Code *</Label>
                  <Input
                    id="code"
                    value={formData.code}
                    onChange={(e) => setFormData(prev => ({ ...prev, code: e.target.value }))}
                    placeholder="e.g., M54.5"
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="description">Description *</Label>
                  <Textarea
                    id="description"
                    value={formData.description}
                    onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
                    placeholder="e.g., Low back pain"
                    required
                    className="h-20"
                  />
                </div>
                <div>
                  <Label htmlFor="category">Category</Label>
                  <Select
                    value={formData.category}
                    onValueChange={(value) => setFormData(prev => ({ ...prev, category: value }))}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select or type category" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Dorsopathies">Dorsopathies</SelectItem>
                      <SelectItem value="Joint Disorders">Joint Disorders</SelectItem>
                      <SelectItem value="Soft Tissue Disorders">Soft Tissue Disorders</SelectItem>
                      <SelectItem value="Nervous System Disorders">Nervous System Disorders</SelectItem>
                      <SelectItem value="Arthropathies">Arthropathies</SelectItem>
                      <SelectItem value="Systemic Connective Tissue Disorders">Systemic Connective Tissue Disorders</SelectItem>
                      <SelectItem value="Other">Other</SelectItem>
                    </SelectContent>
                  </Select>
                  <Input
                    className="mt-2"
                    placeholder="Or type custom category"
                    value={formData.category}
                    onChange={(e) => setFormData(prev => ({ ...prev, category: e.target.value }))}
                  />
                </div>

                {error && (
                  <div className="p-3 bg-red-50 border border-red-200 rounded-lg flex items-center gap-2">
                    <AlertTriangle className="w-5 h-5 text-red-600" />
                    <p className="text-red-700 text-sm">{error}</p>
                  </div>
                )}

                {success && (
                  <div className="p-3 bg-green-50 border border-green-200 rounded-lg flex items-center gap-2">
                    <CheckCircle className="w-5 h-5 text-green-600" />
                    <p className="text-green-700 text-sm">{success}</p>
                  </div>
                )}

                <div className="flex justify-end gap-3 pt-4">
                  <Button type="button" variant="outline" onClick={() => setShowForm(false)}>
                    Cancel
                  </Button>
                  <Button type="submit" disabled={formLoading} className="bg-green-600 hover:bg-green-700">
                    {formLoading ? 'Adding...' : 'Add Code'}
                  </Button>
                </div>
              </form>
            </DialogContent>
          </Dialog>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <Card className="shadow-lg">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Codes</CardTitle>
              <BookMarked className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{codes.length}</div>
              <p className="text-xs text-muted-foreground">In your library</p>
            </CardContent>
          </Card>

          <Card className="shadow-lg">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Categories</CardTitle>
              <BookMarked className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{getUniqueCategories().length}</div>
              <p className="text-xs text-muted-foreground">Different categories</p>
            </CardContent>
          </Card>

          <Card className="shadow-lg">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Most Common</CardTitle>
              <BookMarked className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-lg font-bold">
                {getUniqueCategories().length > 0 ? getUniqueCategories()[0] : 'None'}
              </div>
              <p className="text-xs text-muted-foreground">Category</p>
            </CardContent>
          </Card>
        </div>

        {/* Search and Filters */}
        <Card className="shadow-lg mb-8">
          <CardContent className="p-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="md:col-span-2">
                <Label htmlFor="search">Search Codes</Label>
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                  <Input
                    id="search"
                    placeholder="Search by code or description..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10"
                  />
                </div>
              </div>
              <div>
                <Label htmlFor="category">Filter by Category</Label>
                <Select value={categoryFilter} onValueChange={setCategoryFilter}>
                  <SelectTrigger>
                    <SelectValue placeholder="All categories" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Categories</SelectItem>
                    {getUniqueCategories().map((category) => (
                      <SelectItem key={category} value={category}>
                        {category}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Results */}
        {Object.keys(groupedCodes).length > 0 ? (
          <div className="space-y-8">
            {Object.entries(groupedCodes).map(([category, codesInCategory]) => (
              <div key={category}>
                <div className="flex items-center justify-between mb-4">
                  <h2 className="text-xl font-semibold text-gray-800">{category}</h2>
                  <Badge variant="outline">{codesInCategory.length} codes</Badge>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {codesInCategory.map(code => (
                    <Card key={code.id} className="hover:shadow-md transition-shadow">
                      <CardContent className="p-4">
                        <div className="flex items-start justify-between mb-2">
                          <Badge variant="outline" className="font-mono text-blue-700 bg-blue-50 border-blue-200">
                            {code.code}
                          </Badge>
                          <Badge variant="secondary" className="text-xs">
                            {code.category}
                          </Badge>
                        </div>
                        <p className="text-gray-700 text-sm leading-relaxed">
                          {code.description}
                        </p>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </div>
            ))}
          </div>
        ) : (
          <Card className="shadow-lg">
            <CardContent className="text-center py-12">
              <BookMarked className="w-16 h-16 text-gray-300 mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-gray-900 mb-2">
                {codes.length === 0 ? 'No ICD-10 codes in library' : 'No codes found'}
              </h3>
              <p className="text-gray-600 mb-6">
                {codes.length === 0
                  ? 'Add your first diagnostic code to get started'
                  : 'Your search did not match any codes in the library'
                }
              </p>
              {codes.length === 0 && (
                <Button onClick={() => setShowForm(true)} className="bg-green-600 hover:bg-green-700">
                  <Plus className="w-4 h-4 mr-2" />
                  Add First Code
                </Button>
              )}
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
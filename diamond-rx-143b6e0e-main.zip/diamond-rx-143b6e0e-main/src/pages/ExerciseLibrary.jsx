
import React from "react";
import { Exercise } from "@/api/entities";
import { User } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import { Heart, Plus, Edit, Trash2, Copy, BookOpen, User as UserIcon, BookMarked } from "lucide-react";
import ExerciseForm from "../components/provider/ExerciseForm";
import ExerciseCard from "../components/provider/ExerciseCard";
import LibraryExerciseCard from "../components/provider/LibraryExerciseCard";
import { SYSTEM_EXERCISE_LIBRARY } from "../components/data/SystemExercises";
import { ICD10Code } from "@/api/entities";

export default function ExerciseLibraryPage() {
  const [user, setUser] = React.useState(null);
  const [myExercises, setMyExercises] = React.useState([]);
  const [libraryExercises, setLibraryExercises] = React.useState([]);
  const [filteredMyExercises, setFilteredMyExercises] = React.useState([]);
  const [filteredLibraryExercises, setFilteredLibraryExercises] = React.useState([]);
  const [icd10Library, setIcd10Library] = React.useState([]);
  const [showForm, setShowForm] = React.useState(false);
  const [editingExercise, setEditingExercise] = React.useState(null);
  const [loading, setLoading] = React.useState(true);
  const [activeTab, setActiveTab] = React.useState("my-exercises");
  const [filters, setFilters] = React.useState({
    body_area: "all",
    difficulty: "all",
    search: "",
    icd10_code: "all"
  });

  const filterExercises = React.useCallback(() => {
    const applyFilters = (exercises) => {
      let filtered = exercises;

      if (filters.body_area !== "all") {
        filtered = filtered.filter(ex => {
          if (!ex.body_areas || ex.body_areas.length === 0) {
            return false;
          }
          const selectedArea = filters.body_area;
          // Check if the exact simplified area is present
          if (ex.body_areas.includes(selectedArea)) {
            return true;
          }
          // If the selected area is one of the simplified "sided" areas, check for its left/right variants
          // This ensures backward compatibility with exercises stored with left/right specific body areas.
          const sidedAreas = ["shoulder", "arm", "hip", "thigh", "knee", "calf", "foot"];
          if (sidedAreas.includes(selectedArea)) {
            return ex.body_areas.some(exArea =>
              exArea === `left_${selectedArea}` || exArea === `right_${selectedArea}`
            );
          }
          return false;
        });
      }

      if (filters.difficulty !== "all") {
        filtered = filtered.filter(ex => ex.difficulty === filters.difficulty);
      }
      
      if (filters.icd10_code !== "all") {
        filtered = filtered.filter(ex => ex.icd10_codes?.includes(filters.icd10_code));
      }

      if (filters.search) {
        filtered = filtered.filter(ex =>
          ex.name?.toLowerCase().includes(filters.search.toLowerCase()) ||
          ex.description?.toLowerCase().includes(filters.search.toLowerCase())
        );
      }

      return filtered;
    };

    setFilteredMyExercises(applyFilters(myExercises));
    setFilteredLibraryExercises(applyFilters(libraryExercises));
  }, [myExercises, libraryExercises, filters]);

  React.useEffect(() => {
    loadExercises();
  }, []);

  React.useEffect(() => {
    filterExercises();
  }, [filterExercises]);

  const loadExercises = async () => {
    try {
      const userData = await User.me();
      if (userData.account_type !== 'provider') {
        setUser(userData);
        return;
      }
      setUser(userData);

      // Load provider's own exercises
      const userExercises = await Exercise.filter({ created_by: userData.email });
      setMyExercises(userExercises);
      
      const codes = await ICD10Code.list();
      setIcd10Library(codes);

      // Use embedded library exercises instead of trying to fetch from database
      setLibraryExercises(SYSTEM_EXERCISE_LIBRARY);

    } catch (error) {
      console.error("Error loading exercises:", error);
      setMyExercises([]);
      // Still set library exercises even if there's an error with user exercises
      setLibraryExercises(SYSTEM_EXERCISE_LIBRARY);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (exerciseData) => {
    try {
      if (editingExercise) {
        await Exercise.update(editingExercise.id, exerciseData);
      } else {
        await Exercise.create({
          ...exerciseData,
          provider_id: user.id
        });
      }
      setShowForm(false);
      setEditingExercise(null);
      await loadExercises();
    } catch (error) {
      console.error("Error saving exercise:", error);
      alert("Error saving exercise. Please try again.");
    }
  };

  const handleEdit = (exercise) => {
    setEditingExercise(exercise);
    setShowForm(true);
  };

  const handleDelete = async (exerciseId) => {
    if (window.confirm("Are you sure you want to delete this exercise?")) {
      try {
        await Exercise.delete(exerciseId);
        await loadExercises();
      } catch (error) {
        console.error("Error deleting exercise:", error);
        alert("Error deleting exercise. Please try again.");
      }
    }
  };

  const handleCopyFromLibrary = async (libraryExercise) => {
    try {
      const { id, created_by, created_date, updated_date, ...exerciseData } = libraryExercise;
      await Exercise.create({
        ...exerciseData,
        provider_id: user.id
      });
      await loadExercises();
      alert("Exercise copied to your library successfully!");
    } catch (error) {
      console.error("Error copying exercise:", error);
      alert("Error copying exercise. Please try again.");
    }
  };

  const bodyAreas = [
    "head", "neck", "shoulder", "arm", "chest", "upper_back",
    "lower_back", "abdomen", "hip", "thigh", "knee",
    "calf", "foot"
  ];

  if (loading) {
    return <div className="min-h-screen bg-gray-50 flex items-center justify-center">
      <div className="text-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-green-600 mx-auto"></div>
        <p className="mt-4 text-gray-600">Loading exercise library...</p>
      </div>
    </div>;
  }

  if (!user || user.account_type !== 'provider') {
    // The Layout component will handle redirection. Return null to prevent rendering.
    return null;
  }

  return (
    <div className="min-h-screen bg-gray-50 p-4 lg:p-8">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 gap-4">
          <div>
            <h1 className="text-3xl font-bold text-gray-900 mb-2">Exercise Library</h1>
            <p className="text-gray-600">Create and manage exercises for your patients</p>
          </div>
          <Dialog open={showForm} onOpenChange={setShowForm}>
            <DialogTrigger asChild>
              <Button className="bg-green-600 hover:bg-green-700">
                <Plus className="w-4 h-4 mr-2" />
                Add New Exercise
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>
                  {editingExercise ? 'Edit Exercise' : 'Create New Exercise'}
                </DialogTitle>
              </DialogHeader>
              <ExerciseForm
                exercise={editingExercise}
                onSubmit={handleSubmit}
                onCancel={() => {
                  setShowForm(false);
                  setEditingExercise(null);
                }}
              />
            </DialogContent>
          </Dialog>
        </div>

        {/* Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="mb-6">
          <TabsList className="grid w-full grid-cols-2 max-w-md">
            <TabsTrigger value="my-exercises" className="flex items-center gap-2">
              <UserIcon className="w-4 h-4" />
              My Exercises ({myExercises.length})
            </TabsTrigger>
            <TabsTrigger value="library" className="flex items-center gap-2">
              <BookOpen className="w-4 h-4" />
              Exercise Library ({libraryExercises.length})
            </TabsTrigger>
          </TabsList>

          {/* Filters */}
          <Card className="shadow-lg mb-8 mt-6">
            <CardHeader>
              <CardTitle>Filter Exercises</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <div>
                  <Label htmlFor="search">Search</Label>
                  <Input
                    id="search"
                    placeholder="Search exercises..."
                    value={filters.search}
                    onChange={(e) => setFilters(prev => ({ ...prev, search: e.target.value }))}
                  />
                </div>

                <div>
                  <Label htmlFor="body_area">Body Area</Label>
                  <Select
                    value={filters.body_area}
                    onValueChange={(value) => setFilters(prev => ({ ...prev, body_area: value }))}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="All areas" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Areas</SelectItem>
                      {bodyAreas.map((area) => (
                        <SelectItem key={area} value={area}>
                          {area.replace('_', ' ').replace(/\b\w/g, l => l.toUpperCase())}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="difficulty">Difficulty</Label>
                  <Select
                    value={filters.difficulty}
                    onValueChange={(value) => setFilters(prev => ({ ...prev, difficulty: value }))}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="All levels" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Levels</SelectItem>
                      <SelectItem value="beginner">Beginner</SelectItem>
                      <SelectItem value="intermediate">Intermediate</SelectItem>
                      <SelectItem value="advanced">Advanced</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div>
                  <Label htmlFor="icd10_code">ICD-10 Code</Label>
                  <Select
                    value={filters.icd10_code}
                    onValueChange={(value) => setFilters(prev => ({ ...prev, icd10_code: value }))}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="All codes" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Codes</SelectItem>
                      {icd10Library.map((code) => (
                        <SelectItem key={code.id} value={code.code}>
                          {code.code} - {code.description}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="flex items-end col-span-full md:col-span-1">
                  <Button
                    variant="outline"
                    className="w-full"
                    onClick={() => setFilters({ body_area: "all", difficulty: "all", search: "", icd10_code: "all" })}
                  >
                    Clear Filters
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>

          <TabsContent value="my-exercises">
            {filteredMyExercises.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {filteredMyExercises.map((exercise) => (
                  <ExerciseCard
                    key={exercise.id}
                    exercise={exercise}
                    onEdit={handleEdit}
                    onDelete={handleDelete}
                  />
                ))}
              </div>
            ) : (
              <Card className="shadow-lg">
                <CardContent className="text-center py-12">
                  <Heart className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                  <h3 className="text-xl font-semibold text-gray-900 mb-2">
                    {myExercises.length === 0 ? 'No exercises yet' : 'No exercises match your filters'}
                  </h3>
                  <p className="text-gray-600 mb-6">
                    {myExercises.length === 0
                      ? 'Create your own exercises or copy from the library'
                      : 'Try adjusting your search or filter criteria'
                    }
                  </p>
                  {myExercises.length === 0 && (
                    <div className="flex gap-4 justify-center">
                      <Button onClick={() => setShowForm(true)} className="bg-green-600 hover:bg-green-700">
                        <Plus className="w-4 h-4 mr-2" />
                        Create Exercise
                      </Button>
                      <Button onClick={() => setActiveTab("library")} variant="outline">
                        <BookOpen className="w-4 h-4 mr-2" />
                        Browse Library
                      </Button>
                    </div>
                  )}
                </CardContent>
              </Card>
            )}
          </TabsContent>

          <TabsContent value="library">
            {filteredLibraryExercises.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {filteredLibraryExercises.map((exercise) => (
                  <LibraryExerciseCard
                    key={exercise.id}
                    exercise={exercise}
                    onCopy={handleCopyFromLibrary}
                    isAlreadyAdded={myExercises.some(myEx => myEx.name === exercise.name)}
                  />
                ))}
              </div>
            ) : (
              <Card className="shadow-lg">
                <CardContent className="text-center py-12">
                  <BookOpen className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                  <h3 className="text-xl font-semibold text-gray-900 mb-2">
                    {libraryExercises.length === 0 ? 'No library exercises available' : 'No exercises match your filters'}
                  </h3>
                  <p className="text-gray-600">
                    {libraryExercises.length === 0
                      ? 'The exercise library is not available at the moment.'
                      : 'Try adjusting your search or filter criteria'
                    }
                  </p>
                </CardContent>
              </Card>
            )}
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}

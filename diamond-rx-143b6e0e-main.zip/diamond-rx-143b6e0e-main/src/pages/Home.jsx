import React from "react";
import { User } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Heart, Users, Activity, Shield, CheckCircle, ArrowRight } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";

export default function HomePage() {
  const navigate = useNavigate();
  const [loginInProgress, setLoginInProgress] = React.useState(false);

  // The logic to check for an existing user and redirect has been moved to the Layout component
  // to centralize authentication handling and prevent race conditions.

  const handleLogin = async () => {
    setLoginInProgress(true);
    try {
      await User.loginWithRedirect(window.location.origin + createPageUrl("RoleSelection"));
    } catch (error) {
      console.error("Login error:", error);
      setLoginInProgress(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-indigo-50">
      {/* Hero Section */}
      <div className="relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-blue-600/5 to-indigo-600/5" />
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
          <div className="text-center">
            <div className="flex justify-center mb-6">
              <div className="w-16 h-16 bg-gradient-to-r from-blue-600 to-indigo-600 rounded-2xl flex items-center justify-center shadow-lg">
                <Heart className="w-8 h-8 text-white" />
              </div>
            </div>
            <h1 className="text-4xl md:text-6xl font-bold text-gray-900 mb-6">
              Pain<span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-600 to-indigo-600">Tracker</span> Pro
            </h1>
            <p className="text-xl text-gray-600 mb-8 max-w-2xl mx-auto leading-relaxed">
              Revolutionize pain management with intelligent tracking, personalized exercises, 
              and seamless patient-provider collaboration.
            </p>
            <Button 
              onClick={handleLogin}
              disabled={loginInProgress}
              className="bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white px-8 py-4 text-lg font-medium rounded-xl shadow-lg transition-all duration-300 transform hover:scale-105"
            >
              {loginInProgress ? 'Signing In...' : 'Get Started Today'}
              <ArrowRight className="w-5 h-5 ml-2" />
            </Button>
          </div>
        </div>
      </div>

      {/* Features Section */}
      <div className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Complete Pain Management Solution
            </h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              Built for both patients and healthcare providers to work together effectively
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            <Card className="border-0 shadow-lg hover:shadow-xl transition-shadow duration-300">
              <CardHeader className="text-center pb-4">
                <div className="w-12 h-12 bg-blue-100 rounded-xl flex items-center justify-center mx-auto mb-4">
                  <Activity className="w-6 h-6 text-blue-600" />
                </div>
                <CardTitle className="text-xl font-bold text-gray-900">Smart Pain Tracking</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600 leading-relaxed">
                  Interactive body map, detailed pain assessment, and chronological tracking 
                  for comprehensive pain management.
                </p>
              </CardContent>
            </Card>

            <Card className="border-0 shadow-lg hover:shadow-xl transition-shadow duration-300">
              <CardHeader className="text-center pb-4">
                <div className="w-12 h-12 bg-green-100 rounded-xl flex items-center justify-center mx-auto mb-4">
                  <Users className="w-6 h-6 text-green-600" />
                </div>
                <CardTitle className="text-xl font-bold text-gray-900">Provider Connection</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600 leading-relaxed">
                  Seamless linking between patients and healthcare providers with 
                  real-time alerts and progress monitoring.
                </p>
              </CardContent>
            </Card>

            <Card className="border-0 shadow-lg hover:shadow-xl transition-shadow duration-300">
              <CardHeader className="text-center pb-4">
                <div className="w-12 h-12 bg-purple-100 rounded-xl flex items-center justify-center mx-auto mb-4">
                  <Heart className="w-6 h-6 text-purple-600" />
                </div>
                <CardTitle className="text-xl font-bold text-gray-900">Exercise Library</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600 leading-relaxed">
                  Personalized exercise recommendations with video demonstrations 
                  and progress tracking for optimal recovery.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>

      {/* Benefits Section */}
      <div className="py-20 bg-gradient-to-r from-gray-50 to-blue-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-6">
                Why Choose PainTracker Pro?
              </h2>
              <div className="space-y-4">
                {[
                  "Evidence-based pain assessment tools",
                  "Personalized exercise recommendations",
                  "Real-time provider notifications",
                  "Comprehensive progress analytics",
                  "Secure, HIPAA-compliant platform",
                  "Mobile-first responsive design"
                ].map((benefit, index) => (
                  <div key={index} className="flex items-center gap-3">
                    <div className="w-6 h-6 bg-green-100 rounded-full flex items-center justify-center">
                      <CheckCircle className="w-4 h-4 text-green-600" />
                    </div>
                    <span className="text-gray-700 font-medium">{benefit}</span>
                  </div>
                ))}
              </div>
            </div>
            <div className="relative">
              <div className="bg-white rounded-2xl shadow-2xl p-8 transform rotate-3 hover:rotate-0 transition-transform duration-300">
                <div className="flex items-center gap-4 mb-6">
                  <div className="w-12 h-12 bg-gradient-to-r from-blue-600 to-indigo-600 rounded-xl flex items-center justify-center">
                    <Shield className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <h3 className="font-bold text-gray-900">Secure & Professional</h3>
                    <p className="text-sm text-gray-600">Healthcare-grade security</p>
                  </div>
                </div>
                <div className="space-y-3">
                  <div className="h-3 bg-gray-100 rounded-full">
                    <div className="h-3 bg-gradient-to-r from-blue-600 to-indigo-600 rounded-full w-4/5"></div>
                  </div>
                  <div className="h-3 bg-gray-100 rounded-full">
                    <div className="h-3 bg-gradient-to-r from-green-500 to-emerald-500 rounded-full w-3/5"></div>
                  </div>
                  <div className="h-3 bg-gray-100 rounded-full">
                    <div className="h-3 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full w-4/6"></div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* CTA Section */}
      <div className="py-20 bg-gradient-to-r from-blue-600 to-indigo-600">
        <div className="max-w-4xl mx-auto text-center px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl md::text-4xl font-bold text-white mb-6">
            Ready to Transform Pain Management?
          </h2>
          <p className="text-xl text-blue-100 mb-8 max-w-2xl mx-auto">
            Join thousands of patients and providers already using PainTracker Pro 
            for better health outcomes.
          </p>
          <Button 
            onClick={handleLogin}
            disabled={loginInProgress}
            className="bg-white text-blue-600 hover:bg-gray-100 px-8 py-4 text-lg font-medium rounded-xl shadow-lg transition-all duration-300 transform hover:scale-105"
          >
            {loginInProgress ? 'Signing In...' : 'Start Free Today'}
            <ArrowRight className="w-5 h-5 ml-2" />
          </Button>
        </div>
      </div>
    </div>
  );
}
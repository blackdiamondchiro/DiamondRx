
import React from "react";
import { User } from "@/api/entities";
import { PainEntry } from "@/api/entities";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { 
  Users, 
  Search, 
  AlertTriangle, 
  TrendingUp, 
  Calendar,
  Phone,
  Mail,
  Activity,
  BookOpen, // New import
  Heart,    // New import
  BookMarked // New import
} from "lucide-react";
import { format, subDays } from "date-fns";
import PatientCard from "../components/provider/PatientCard";
import { Link } from "react-router-dom"; // New import
import { createPageUrl } from "@/utils"; // New import

export default function PatientManagementPage() {
  const [user, setUser] = React.useState(null);
  const [patients, setPatients] = React.useState([]);
  const [filteredPatients, setFilteredPatients] = React.useState([]);
  const [searchTerm, setSearchTerm] = React.useState("");
  const [selectedPatient, setSelectedPatient] = React.useState(null);
  const [loading, setLoading] = React.useState(true);

  const filterPatients = React.useCallback(() => {
    const filtered = patients.filter(patient =>
      patient.full_name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      patient.email?.toLowerCase().includes(searchTerm.toLowerCase())
    );
    setFilteredPatients(filtered);
  }, [patients, searchTerm]); // dependencies for useCallback

  React.useEffect(() => {
    loadPatients();
  }, []);

  React.useEffect(() => {
    filterPatients();
  }, [filterPatients]); // now depends on the memoized function

  const loadPatients = async () => {
    try {
      const userData = await User.me();
      
      // If user is not a provider, set user data and return early
      if (userData.account_type !== 'provider') {
        setUser(userData);
        return; 
      }
      
      setUser(userData);

      // Using mock patient data for demonstration due to security restrictions
      // on fetching other user accounts.
      const mockPatients = [
        {
          id: "1",
          full_name: "John Doe",
          email: "john@example.com",
          phone: "(555) 123-4567",
          account_type: "patient",
          created_date: subDays(new Date(), 30).toISOString(),
          last_pain_entry: {
            pain_level: 7,
            body_area: "lower_back",
            created_date: subDays(new Date(), 1).toISOString()
          },
          avg_pain: 5.8,
          total_entries: 24
        },
        {
          id: "2",
          full_name: "Jane Smith",
          email: "jane@example.com",
          phone: "(555) 987-6543",
          account_type: "patient",
          created_date: subDays(new Date(), 45).toISOString(),
          last_pain_entry: {
            pain_level: 3,
            body_area: "neck",
            created_date: subDays(new Date(), 2).toISOString()
          },
          avg_pain: 4.2,
          total_entries: 18
        },
        {
          id: "3",
          full_name: "Mike Johnson",
          email: "mike@example.com",
          phone: "(555) 456-7890",
          account_type: "patient",
          created_date: subDays(new Date(), 15).toISOString(),
          last_pain_entry: {
            pain_level: 8,
            body_area: "right_knee",
            created_date: new Date().toISOString()
          },
          avg_pain: 6.5,
          total_entries: 12
        }
      ];

      setPatients(mockPatients);
    } catch (error) {
      console.error("Error loading patients:", error);
    } finally {
      setLoading(false);
    }
  };

  const getPatientRiskLevel = (patient) => {
    if (patient.last_pain_entry?.pain_level >= 7) return "high";
    if (patient.avg_pain >= 5) return "medium";
    return "low";
  };

  const getRiskColor = (risk) => {
    switch (risk) {
      case "high": return "text-red-600 bg-red-50 border-red-200";
      case "medium": return "text-yellow-600 bg-yellow-50 border-yellow-200";
      default: return "text-green-600 bg-green-50 border-green-200";
    }
  };

  const highRiskPatients = patients.filter(p => getPatientRiskLevel(p) === "high").length;

  if (loading) {
    return <div className="min-h-screen bg-gray-50 flex items-center justify-center">
      <div className="text-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-green-600 mx-auto"></div>
        <p className="mt-4 text-gray-600">Loading patients...</p>
      </div>
    </div>;
  }
  
  if (!user || user.account_type !== 'provider') {
    // The Layout component will handle redirection. Return null to prevent rendering.
    return null;
  }

  return (
    <div className="min-h-screen bg-gray-50 p-4 lg:p-8">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Patient Management</h1>
          <p className="text-gray-600">Monitor and manage your patient's pain levels and progress</p>
        </div>

        {/* Quick Actions */}
        <Card className="shadow-sm mb-6 bg-gray-50">
            <CardHeader className="pb-4">
                <CardTitle className="text-base">Quick Actions</CardTitle>
            </CardHeader>
            <CardContent className="pt-0">
                <div className="flex flex-wrap gap-3">
                    <Link to={createPageUrl("ExerciseLibrary")}>
                        <Button size="sm" variant="outline" className="bg-white">
                            <BookOpen className="w-4 h-4 mr-2" />
                            Exercise Library
                        </Button>
                    </Link>
                    <Link to={createPageUrl("ExercisePrescriptions")}>
                        <Button size="sm" variant="outline" className="bg-white">
                            <Heart className="w-4 h-4 mr-2" />
                            Prescriptions
                        </Button>
                    </Link>
                    <Link to={createPageUrl("ICD10Library")}>
                        <Button size="sm" variant="outline" className="bg-white">
                            <BookMarked className="w-4 h-4 mr-2" />
                            ICD-10 Library
                        </Button>
                    </Link>
                </div>
            </CardContent>
        </Card>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card className="shadow-lg">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Patients</CardTitle>
              <Users className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{patients.length}</div>
              <p className="text-xs text-muted-foreground">
                Linked to your care
              </p>
            </CardContent>
          </Card>

          <Card className="shadow-lg">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">High Risk</CardTitle>
              <AlertTriangle className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-red-600">{highRiskPatients}</div>
              <p className="text-xs text-muted-foreground">
                Need immediate attention
              </p>
            </CardContent>
          </Card>

          <Card className="shadow-lg">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Avg Pain Level</CardTitle>
              <TrendingUp className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {patients.length > 0 
                  ? (patients.reduce((sum, p) => sum + (p.avg_pain || 0), 0) / patients.length).toFixed(1)
                  : '0'
                }/10
              </div>
              <p className="text-xs text-muted-foreground">
                Across all patients
              </p>
            </CardContent>
          </Card>

          <Card className="shadow-lg">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Active Today</CardTitle>
              <Calendar className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {patients.filter(p => 
                  p.last_pain_entry?.created_date?.startsWith(new Date().toISOString().split('T')[0])
                ).length}
              </div>
              <p className="text-xs text-muted-foreground">
                Reported pain today
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Search and Filters */}
        <Card className="shadow-lg mb-8">
          <CardContent className="p-6">
            <div className="flex flex-col md:flex-row gap-4">
              <div className="flex-1 relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                <Input
                  placeholder="Search patients by name or email..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
              <Button variant="outline">
                Export Patient Data
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Patient List */}
        {filteredPatients.length > 0 ? (
          <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
            {filteredPatients.map((patient) => (
              <PatientCard
                key={patient.id}
                patient={patient}
                onSelect={setSelectedPatient}
              />
            ))}
          </div>
        ) : (
          <Card className="shadow-lg">
            <CardContent className="text-center py-12">
              <Users className="w-16 h-16 text-gray-300 mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-gray-900 mb-2">
                {patients.length === 0 ? 'No patients linked yet' : 'No patients found'}
              </h3>
              <p className="text-gray-600 mb-6">
                {patients.length === 0 
                  ? 'Patients can link to your account using your provider ID'
                  : 'Try adjusting your search terms'
                }
              </p>
              {patients.length === 0 && (
                <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 max-w-md mx-auto">
                  <p className="text-sm text-blue-800">
                    <strong>Your Provider ID:</strong> {user?.id}
                  </p>
                  <p className="text-xs text-blue-600 mt-1">
                    Share this ID with patients so they can link to your account
                  </p>
                </div>
              )}
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}

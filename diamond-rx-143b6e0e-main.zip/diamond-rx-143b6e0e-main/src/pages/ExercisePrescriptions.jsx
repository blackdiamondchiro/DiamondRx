import React, { useState, useEffect } from "react";
import { User } from "@/api/entities";
import { ExercisePrescription } from "@/api/entities";
import { Exercise } from "@/api/entities";
import { ICD10Code } from "@/api/entities";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Plus, FileText, Users, Calendar, BookMarked } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import CreatePrescriptionForm from "../components/provider/CreatePrescriptionForm";
import PrescriptionCard from "../components/provider/PrescriptionCard";

export default function ExercisePrescriptionsPage() {
  const [user, setUser] = useState(null);
  const [prescriptions, setPrescriptions] = useState([]);
  const [filteredPrescriptions, setFilteredPrescriptions] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [showForm, setShowForm] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadData();
  }, []);

  useEffect(() => {
    const filtered = prescriptions.filter(prescription =>
      prescription.title?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      prescription.patient_name?.toLowerCase().includes(searchTerm.toLowerCase())
    );
    setFilteredPrescriptions(filtered);
  }, [prescriptions, searchTerm]);

  const loadData = async () => {
    try {
      const userData = await User.me();
      if (userData.account_type !== 'provider') {
        setLoading(false);
        return;
      }
      setUser(userData);

      // Load prescriptions created by this provider
      const providerPrescriptions = await ExercisePrescription.filter({ provider_id: userData.id });
      
      // Mock patient names since we can't easily fetch user details for each patient
      const prescriptionsWithPatientNames = providerPrescriptions.map(prescription => ({
        ...prescription,
        patient_name: `Patient ${prescription.patient_id.slice(-4)}`
      }));
      
      setPrescriptions(prescriptionsWithPatientNames);
    } catch (error) {
      console.error("Error loading prescriptions:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleCreatePrescription = async (prescriptionData) => {
    try {
      await ExercisePrescription.create({
        ...prescriptionData,
        provider_id: user.id
      });
      setShowForm(false);
      await loadData();
    } catch (error) {
      console.error("Error creating prescription:", error);
      alert("Error creating prescription. Please try again.");
    }
  };

  const handleUpdateStatus = async (prescriptionId, newStatus) => {
    try {
      await ExercisePrescription.update(prescriptionId, { status: newStatus });
      await loadData();
    } catch (error) {
      console.error("Error updating prescription:", error);
      alert("Error updating prescription. Please try again.");
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-green-600 mx-auto"></div>
          <p className="mt-4 text-gray-600">Loading prescriptions...</p>
        </div>
      </div>
    );
  }

  if (!user || user.account_type !== 'provider') {
    return null;
  }

  return (
    <div className="min-h-screen bg-gray-50 p-4 lg:p-8">
      <div className="max-w-7xl mx-auto">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 gap-4">
          <div>
            <h1 className="text-3xl font-bold text-gray-900 mb-2">Exercise Prescriptions</h1>
            <p className="text-gray-600">Create and manage exercise prescriptions for your patients</p>
          </div>
          <Dialog open={showForm} onOpenChange={setShowForm}>
            <DialogTrigger asChild>
              <Button className="bg-green-600 hover:bg-green-700">
                <Plus className="w-4 h-4 mr-2" />
                Create Prescription
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-6xl max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>Create Exercise Prescription</DialogTitle>
              </DialogHeader>
              <CreatePrescriptionForm
                onSubmit={handleCreatePrescription}
                onCancel={() => setShowForm(false)}
              />
            </DialogContent>
          </Dialog>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card className="shadow-lg">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Prescriptions</CardTitle>
              <FileText className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{prescriptions.length}</div>
              <p className="text-xs text-muted-foreground">Created by you</p>
            </CardContent>
          </Card>

          <Card className="shadow-lg">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Active Programs</CardTitle>
              <Calendar className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {prescriptions.filter(p => p.status === 'active').length}
              </div>
              <p className="text-xs text-muted-foreground">Currently running</p>
            </CardContent>
          </Card>

          <Card className="shadow-lg">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Unique Patients</CardTitle>
              <Users className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {new Set(prescriptions.map(p => p.patient_id)).size}
              </div>
              <p className="text-xs text-muted-foreground">With prescriptions</p>
            </CardContent>
          </Card>

          <Card className="shadow-lg">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Completed Programs</CardTitle>
              <BookMarked className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {prescriptions.filter(p => p.status === 'completed').length}
              </div>
              <p className="text-xs text-muted-foreground">Successfully finished</p>
            </CardContent>
          </Card>
        </div>

        {/* Search */}
        <Card className="shadow-lg mb-8">
          <CardContent className="p-6">
            <div className="relative">
              <Input
                placeholder="Search prescriptions by title or patient..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-4"
              />
            </div>
          </CardContent>
        </Card>

        {/* Prescriptions List */}
        {filteredPrescriptions.length > 0 ? (
          <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
            {filteredPrescriptions.map((prescription) => (
              <PrescriptionCard
                key={prescription.id}
                prescription={prescription}
                onUpdateStatus={handleUpdateStatus}
              />
            ))}
          </div>
        ) : (
          <Card className="shadow-lg">
            <CardContent className="text-center py-12">
              <FileText className="w-16 h-16 text-gray-300 mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-gray-900 mb-2">
                {prescriptions.length === 0 ? 'No prescriptions created' : 'No prescriptions found'}
              </h3>
              <p className="text-gray-600 mb-6">
                {prescriptions.length === 0
                  ? 'Create your first exercise prescription for a patient'
                  : 'Try adjusting your search terms'
                }
              </p>
              {prescriptions.length === 0 && (
                <Button onClick={() => setShowForm(true)} className="bg-green-600 hover:bg-green-700">
                  <Plus className="w-4 h-4 mr-2" />
                  Create First Prescription
                </Button>
              )}
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
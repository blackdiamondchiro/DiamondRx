import React from 'react';

export default function BodyMap({ selectedArea, onAreaSelect, disabled = false }) {
  const imageUrl = "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/dc8394424_Body.png";

  const bodyAreas = [
    { id: 'head', top: '6%', left: '74%', width: '3%', height: '3%' },
    { id: 'neck', top: '13%', left: '74%', width: '2.5%', height: '2.5%' },
    { id: 'chest', top: '21%', left: '74%', width: '3%', height: '3%' },
    { id: 'abdomen', top: '33%', left: '74%', width: '3%', height: '3%' },
    { id: 'left_shoulder', top: '18%', left: '83%', width: '2.5%', height: '2.5%' },
    { id: 'right_shoulder', top: '18%', left: '65%', width: '2.5%', height: '2.5%' },
    { id: 'left_arm', top: '31%', left: '87%', width: '2.5%', height: '2.5%' },
    { id: 'right_arm', top: '31%', left: '61%', width: '2.5%', height: '2.5%' },
    { id: 'left_hip', top: '43%', left: '78%', width: '2.5%', height: '2.5%' },
    { id: 'right_hip', top: '43%', left: '70%', width: '2.5%', height: '2.5%' },
    { id: 'left_thigh', top: '55%', left: '79%', width: '2.5%', height: '2.5%' },
    { id: 'right_thigh', top: '55%', left: '69%', width: '2.5%', height: '2.5%' },
    { id: 'left_knee', top: '66%', left: '79%', width: '2.5%', height: '2.5%' },
    { id: 'right_knee', top: '66%', left: '69%', width: '2.5%', height: '2.5%' },
    { id: 'left_calf', top: '77%', left: '79%', width: '2.5%', height: '2.5%' },
    { id: 'right_calf', top: '77%', left: '69%', width: '2.5%', height: '2.5%' },
    { id: 'left_foot', top: '88%', left: '79%', width: '2.5%', height: '2.5%' },
    { id: 'right_foot', top: '88%', left: '69%', width: '2.5%', height: '2.5%' },
    // BACK VIEW
    { id: 'upper_back', top: '23%', left: '24%', width: '3%', height: '3%' },
    { id: 'lower_back', top: '38%', left: '24%', width: '3%', height: '3%' },
    { id: 'head_back', top: '6%', left: '24%', width: '3%', height: '3%' },
    { id: 'neck_back', top: '13%', left: '24%', width: '2.5%', height: '2.5%' },
    { id: 'left_shoulder_back', top: '18%', left: '33%', width: '2.5%', height: '2.5%' },
    { id: 'right_shoulder_back', top: '18%', left: '15%', width: '2.5%', height: '2.5%' },
    { id: 'left_arm_back', top: '31%', left: '37%', width: '2.5%', height: '2.5%' },
    { id: 'right_arm_back', top: '31%', left: '11%', width: '2.5%', height: '2.5%' },
    { id: 'left_hip_back', top: '43%', left: '29%', width: '2.5%', height: '2.5%' },
    { id: 'right_hip_back', top: '43%', left: '19%', width: '2.5%', height: '2.5%' },
    { id: 'left_thigh_back', top: '55%', left: '30%', width: '2.5%', height: '2.5%' },
    { id: 'right_thigh_back', top: '55%', left: '18%', width: '2.5%', height: '2.5%' },
    { id: 'left_knee_back', top: '66%', left: '30%', width: '2.5%', height: '2.5%' },
    { id: 'right_knee_back', top: '66%', left: '18%', width: '2.5%', height: '2.5%' },
    { id: 'left_calf_back', top: '77%', left: '30%', width: '2.5%', height: '2.5%' },
    { id: 'right_calf_back', top: '77%', left: '18%', width: '2.5%', height: '2.5%' },
    { id: 'left_foot_back', top: '88%', left: '30%', width: '2.5%', height: '2.5%' },
    { id: 'right_foot_back', top: '88%', left: '18%', width: '2.5%', height: '2.5%' },
  ];

  // Helper to get the base body area name (e.g., "head" from "head_back")
  const getBaseAreaName = (id) => {
    return id.replace(/_back$/, '');
  };

  const handleSelect = (spotId) => {
    if (!disabled) {
      const baseArea = getBaseAreaName(spotId);
      onAreaSelect(baseArea);
    }
  };

  const isSelected = (spotId) => {
    const baseArea = getBaseAreaName(spotId);
    return selectedArea === baseArea;
  };

  return (
    <div className="w-full max-w-lg mx-auto">
      <div className="relative">
        <img src={imageUrl} alt="Body map for pain selection" className="w-full h-auto" />
        
        {bodyAreas.map(area => {
          const isActive = isSelected(area.id);
          return (
            <div
              key={area.id}
              onClick={() => handleSelect(area.id)}
              className={`absolute rounded-full transition-all duration-200 flex items-center justify-center ${
                disabled ? 'cursor-not-allowed' : 'cursor-pointer hover:scale-110'
              } ${
                isActive
                  ? 'bg-red-600 border-2 border-red-800 scale-125'
                  : 'bg-red-400/60 border-2 border-red-500 hover:bg-red-500/80'
              }`}
              style={{
                top: area.top,
                left: area.left,
                width: area.width,
                height: area.height,
              }}
              title={getBaseAreaName(area.id).replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase())}
            >
              {isActive && (
                <div className="w-2 h-2 bg-white rounded-full"></div>
              )}
            </div>
          );
        })}

        {/* Labels for selected area */}
        {selectedArea && (
          <div className="absolute top-2 left-2 bg-black/75 text-white px-2 py-1 rounded text-sm">
            {selectedArea.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase())}
          </div>
        )}
      </div>
      
      {/* Legend */}
      <div className="mt-4 text-center">
        <p className="text-sm text-gray-600">
          Click on any red dot to select that body area
        </p>
        {selectedArea && (
          <p className="text-sm font-medium text-blue-600 mt-1">
            Selected: {selectedArea.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase())}
          </p>
        )}
      </div>
    </div>
  );
}
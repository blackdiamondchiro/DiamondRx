import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { 
  Activity, 
  AlertTriangle, 
  ShieldCheck, 
  Heart, 
  Clock, 
  RotateCcw,
  Hash,
  Calendar,
  Play,
  Phone,
  Mail
} from "lucide-react";

const difficultyColors = {
  beginner: "bg-green-100 text-green-800 border-green-200",
  intermediate: "bg-yellow-100 text-yellow-800 border-yellow-200", 
  advanced: "bg-red-100 text-red-800 border-red-200"
};

export default function ExerciseRecommendations({ 
  painLevel, 
  bodyArea, 
  provider, 
  exercises, 
  onExerciseSelect 
}) {
  const painThreshold = provider?.pain_threshold || 5;
  const isHighPain = painLevel > painThreshold;
  const hasProvider = !!provider;

  // Filter exercises based on pain level and appropriateness
  const getAppropriateExercises = () => {
    if (!exercises || exercises.length === 0) return [];

    let filtered = exercises.filter(exercise => 
      exercise.body_areas?.includes(bodyArea)
    );

    if (isHighPain) {
      // For high pain, only show beginner/gentle exercises
      filtered = filtered.filter(exercise => 
        exercise.difficulty === 'beginner' || 
        exercise.notes?.toLowerCase().includes('gentle')
      );
    }

    return filtered.slice(0, 6); // Limit to 6 exercises
  };

  const appropriateExercises = getAppropriateExercises();

  const getThresholdMessage = () => {
    if (!hasProvider) {
      return {
        type: "info",
        title: "No Provider Linked",
        message: "You can access all exercises, but we recommend linking with a healthcare provider for personalized care.",
        icon: <Heart className="w-5 h-5" />
      };
    }

    if (isHighPain) {
      return {
        type: "warning",
        title: "High Pain Level Detected",
        message: `Your pain level (${painLevel}/10) exceeds your provider's threshold (${painThreshold}/10). Please contact your healthcare provider. The exercises below are gentle options only and should not replace professional care.`,
        icon: <AlertTriangle className="w-5 h-5" />
      };
    }

    return {
      type: "safe",
      title: "Safe for Self-Management",
      message: `Your pain level (${painLevel}/10) is within your provider's safe threshold (≤${painThreshold}/10). You can safely perform these recommended exercises at home.`,
      icon: <ShieldCheck className="w-5 h-5" />
    };
  };

  const thresholdInfo = getThresholdMessage();

  return (
    <div className="space-y-6">
      {/* Threshold Status Alert */}
      <Alert className={`border-2 ${
        thresholdInfo.type === 'warning' 
          ? 'border-red-200 bg-red-50' 
          : thresholdInfo.type === 'safe'
          ? 'border-green-200 bg-green-50'
          : 'border-blue-200 bg-blue-50'
      }`}>
        <div className="flex items-start gap-3">
          <div className={`mt-1 ${
            thresholdInfo.type === 'warning' 
              ? 'text-red-600' 
              : thresholdInfo.type === 'safe'
              ? 'text-green-600'
              : 'text-blue-600'
          }`}>
            {thresholdInfo.icon}
          </div>
          <div>
            <h3 className={`font-semibold ${
              thresholdInfo.type === 'warning' 
                ? 'text-red-900' 
                : thresholdInfo.type === 'safe'
                ? 'text-green-900'
                : 'text-blue-900'
            }`}>
              {thresholdInfo.title}
            </h3>
            <AlertDescription className={
              thresholdInfo.type === 'warning' 
                ? 'text-red-800' 
                : thresholdInfo.type === 'safe'
                ? 'text-green-800'
                : 'text-blue-800'
            }>
              {thresholdInfo.message}
            </AlertDescription>
          </div>
        </div>
      </Alert>

      {/* Contact Provider Button for High Pain */}
      {isHighPain && hasProvider && (
        <Card className="border-red-200 bg-red-50">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-semibold text-red-900 mb-1">Contact Your Provider</h3>
                <p className="text-sm text-red-700">
                  {provider.full_name}{provider.credentials ? `, ${provider.credentials}` : ''}
                </p>
              </div>
              <div className="flex gap-2">
                {provider.work_location?.phone && (
                  <Button 
                    size="sm" 
                    variant="outline"
                    className="border-red-300 text-red-700 hover:bg-red-100"
                    onClick={() => window.location.href = `tel:${provider.work_location.phone}`}
                  >
                    <Phone className="w-4 h-4 mr-1" />
                    Call
                  </Button>
                )}
                {provider.work_location?.email && (
                  <Button 
                    size="sm" 
                    variant="outline"
                    className="border-red-300 text-red-700 hover:bg-red-100"
                    onClick={() => window.location.href = `mailto:${provider.work_location.email}`}
                  >
                    <Mail className="w-4 h-4 mr-1" />
                    Email
                  </Button>
                )}
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Exercise Recommendations */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Activity className="w-5 h-5" />
            {isHighPain ? 'Gentle Exercises for Your Area' : 'Recommended Exercises'}
            <Badge variant="secondary" className="ml-2">
              {appropriateExercises.length} available
            </Badge>
          </CardTitle>
          {isHighPain && (
            <p className="text-sm text-red-600">
              ⚠️ These are gentle, supplemental exercises only. They are not a replacement for professional medical care.
            </p>
          )}
        </CardHeader>
        <CardContent>
          {appropriateExercises.length > 0 ? (
            <div className="grid gap-4 md:grid-cols-2">
              {appropriateExercises.map((exercise) => (
                <Card key={exercise.id} className="hover:shadow-md transition-shadow">
                  <CardContent className="p-4">
                    <div className="flex justify-between items-start mb-3">
                      <h4 className="font-semibold text-gray-900 line-clamp-2">
                        {exercise.name}
                      </h4>
                      <Badge 
                        className={`${difficultyColors[exercise.difficulty]} text-xs`} 
                        variant="outline"
                      >
                        {exercise.difficulty}
                      </Badge>
                    </div>
                    
                    {exercise.description && (
                      <p className="text-sm text-gray-600 mb-3 line-clamp-2">
                        {exercise.description}
                      </p>
                    )}

                    <div className="grid grid-cols-2 gap-2 text-xs text-gray-500 mb-3">
                      {exercise.duration_minutes && (
                        <div className="flex items-center gap-1">
                          <Clock className="w-3 h-3" />
                          <span>{exercise.duration_minutes}min</span>
                        </div>
                      )}
                      {exercise.repetitions && (
                        <div className="flex items-center gap-1">
                          <RotateCcw className="w-3 h-3" />
                          <span>{exercise.repetitions}x</span>
                        </div>
                      )}
                      {exercise.sets && (
                        <div className="flex items-center gap-1">
                          <Hash className="w-3 h-3" />
                          <span>{exercise.sets} sets</span>
                        </div>
                      )}
                      {exercise.days_per_week && (
                        <div className="flex items-center gap-1">
                          <Calendar className="w-3 h-3" />
                          <span>{exercise.days_per_week}x/week</span>
                        </div>
                      )}
                    </div>

                    {isHighPain && (
                      <div className="mb-3 p-2 bg-yellow-50 border border-yellow-200 rounded text-xs text-yellow-800">
                        <strong>Gentle approach:</strong> Stop if pain increases
                      </div>
                    )}

                    <Button 
                      size="sm" 
                      variant="outline" 
                      className="w-full"
                      onClick={() => onExerciseSelect(exercise)}
                    >
                      <Play className="w-3 h-3 mr-1" />
                      View Exercise
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : (
            <div className="text-center py-8">
              <Activity className="w-12 h-12 text-gray-300 mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-gray-900 mb-2">
                No Exercises Available
              </h3>
              <p className="text-gray-600">
                {isHighPain 
                  ? "No gentle exercises are currently available for this area. Please contact your healthcare provider."
                  : "No exercises found for the selected body area. Try selecting a different area or contact your provider."
                }
              </p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Provider Info */}
      {hasProvider && (
        <Card className="bg-gray-50">
          <CardContent className="pt-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Your Healthcare Provider</p>
                <p className="font-medium text-gray-900">
                  {provider.full_name}{provider.credentials ? `, ${provider.credentials}` : ''}
                </p>
                {provider.specialization && (
                  <p className="text-sm text-gray-600">{provider.specialization}</p>
                )}
              </div>
              <Badge variant="outline" className="text-xs">
                Pain Threshold: {painThreshold}/10
              </Badge>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
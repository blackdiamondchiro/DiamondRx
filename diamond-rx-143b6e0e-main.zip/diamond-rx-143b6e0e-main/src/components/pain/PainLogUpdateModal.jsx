import React, { useState, useEffect } from "react";
import { Complaint } from "@/api/entities";
import { PainLog } from "@/api/entities";
import { AuditLog } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Save, AlertTriangle } from "lucide-react";
import PainScale from "../PainScale";

const initialFormData = {
  pain_level: 1,
  description: "",
  frequency: "",
  triggers: ""
};

export default function PainLogUpdateModal({ isOpen, onClose, onSuccess, user, complaint }) {
  const [formData, setFormData] = useState(initialFormData);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    if (isOpen) {
      setError("");
      setFormData(initialFormData);
    }
  }, [isOpen]);

  const logAudit = async (action, resource, payload, success, errorMessage = null) => {
    try {
      await AuditLog.create({
        user_id: user.id,
        action,
        resource,
        payload_summary: payload,
        success,
        error_message: errorMessage
      });
    } catch (err) {
      console.error("Failed to log audit:", err);
    }
  };

  const handleSubmit = async () => {
    // Validation
    if (!user || user.account_type !== 'patient') {
      setError("This feature is for patient accounts only.");
      return;
    }
    if (!complaint) {
      setError("No complaint selected.");
      return;
    }
    if (!formData.description.trim()) {
      setError("Please provide a description of your pain.");
      return;
    }

    // Verify complaint ownership
    if (complaint.patient_id !== user.id) {
      setError("Not authorized to update this complaint.");
      return;
    }

    setError("");
    setLoading(true);

    try {
      // Create pain log entry
      await PainLog.create({
        complaint_id: complaint.id,
        pain_level: formData.pain_level,
        description: formData.description,
        frequency: formData.frequency,
        triggers: formData.triggers
      });
      await logAudit("create", "pain_log", `Pain update: level ${formData.pain_level} for ${complaint.body_area}`, true);

      // Update complaint timestamp
      await Complaint.update(complaint.id, { updated_date: new Date().toISOString() });
      await logAudit("update", "complaint", `Updated complaint timestamp for ${complaint.body_area}`, true);

      alert("Pain log saved successfully!");
      onSuccess();
      onClose();

    } catch (err) {
      console.error("Error saving pain log:", err);
      const errorMessage = err.message || "Failed to save pain log";
      setError(errorMessage);
      await logAudit("create", "pain_log", `Failed to save pain log for ${complaint.body_area}`, false, errorMessage);
    } finally {
      setLoading(false);
    }
  };

  if (!complaint) {
    return null;
  }

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle>Log Pain Update</DialogTitle>
          <p className="text-sm text-gray-600">
            Update for: <strong>{complaint.body_area.replace('_', ' ').toUpperCase()}</strong>
          </p>
        </DialogHeader>

        <div className="space-y-6 pt-4">
          <div>
            <Label className="text-base font-medium mb-4 block">Current Pain Level (1-10)</Label>
            <PainScale
              value={formData.pain_level}
              onChange={(level) => setFormData(prev => ({ ...prev, pain_level: level }))}
            />
          </div>

          <div>
            <Label htmlFor="description">Pain Description *</Label>
            <Textarea
              id="description"
              placeholder="How is your pain today? Any changes since last time?"
              value={formData.description}
              onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
              required
            />
          </div>

          <div className="grid md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="frequency">Frequency</Label>
              <Select value={formData.frequency} onValueChange={(value) => setFormData(prev => ({ ...prev, frequency: value }))}>
                <SelectTrigger>
                  <SelectValue placeholder="How often?" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="constant">Constant</SelectItem>
                  <SelectItem value="intermittent">Intermittent</SelectItem>
                  <SelectItem value="occasional">Occasional</SelectItem>
                  <SelectItem value="rare">Rare</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="triggers">Triggers</Label>
              <Textarea
                id="triggers"
                placeholder="What makes it worse or better?"
                value={formData.triggers}
                onChange={(e) => setFormData(prev => ({ ...prev, triggers: e.target.value }))}
              />
            </div>
          </div>

          {error && (
            <div className="flex items-center gap-2 text-red-600 bg-red-50 p-3 rounded-lg">
              <AlertTriangle className="w-5 h-5" />
              <p>{error}</p>
            </div>
          )}
        </div>

        <DialogFooter className="pt-6">
          <Button variant="outline" onClick={onClose} disabled={loading}>
            Cancel
          </Button>
          <Button onClick={handleSubmit} disabled={loading}>
            <Save className="w-4 h-4 mr-2" />
            {loading ? 'Saving...' : 'Save Update'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
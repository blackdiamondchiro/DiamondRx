
import React, { useState, useEffect } from "react";
import { Complaint } from "@/api/entities";
import { PainLog } from "@/api/entities";
import { ExerciseAssigned } from "@/api/entities";
import { Exercise } from "@/api/entities";
import { AuditLog } from "@/api/entities";
import { SYSTEM_EXERCISE_LIBRARY } from "../data/SystemExercises";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Save, AlertTriangle, Calendar, Users } from "lucide-react";
import BodyMap from "../BodyMap";
import ExerciseSuggestions from "./ExerciseSuggestions";
import { useToast } from "@/components/ui/use-toast";
import _ from 'lodash';
import { Link } from 'react-router-dom';
import { createPageUrl } from "@/utils";

const initialFormData = {
  body_area: "",
  pain_type: "pain",
  pain_level: 0,
  pain_quality: [],
  onset: "",
  frequency: "",
  triggers: "",
};

const painQualities = ["sharp", "dull", "throbbing", "burning", "aching", "stabbing", "cramping", "shooting"];

export default function NewComplaintModal({ isOpen, onClose, onSuccess, user }) {
  const [formData, setFormData] = useState(initialFormData);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [showPainAlert, setShowPainAlert] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    if (isOpen) {
      setError("");
      setShowPainAlert(false);
      setFormData(initialFormData);
    }
  }, [isOpen]);

  useEffect(() => {
    const threshold = user?.provider_id ? (user?.pain_threshold || 5) : 5;
    setShowPainAlert(formData.pain_level > threshold);
  }, [formData.pain_level, user]);

  const togglePainQuality = (quality) => {
    setFormData(prev => ({
      ...prev,
      pain_quality: prev.pain_quality.includes(quality)
        ? prev.pain_quality.filter(q => q !== quality)
        : [...prev.pain_quality, quality]
    }));
  };

  const logAudit = async (action, resource, payload, success, errorMessage = null) => {
    try {
      await AuditLog.create({
        user_id: user.id,
        action,
        resource,
        payload_summary: payload,
        success,
        error_message: errorMessage
      });
    } catch (err) {
      console.error("Failed to log audit:", err);
    }
  };
  
  const notifyProvider = async (complaint, painLevel) => {
    try {
      if (user.provider_id) {
        console.log(`Provider notification: Patient ${user.full_name} created a new complaint for ${complaint.body_area} with pain level ${painLevel}.`);
        await logAudit("notify_provider", "complaint", `New complaint created for ${complaint.body_area}`, true);
      }
    } catch (err) {
      console.error("Failed to notify provider:", err);
    }
  };

  const assignExercises = async (complaintId, bodyArea, painLevel) => {
    try {
      let providerExercises = [];
      if (user?.provider_id) {
        try {
          providerExercises = await Exercise.filter({ provider_id: user.provider_id });
        } catch (e) {
          console.warn("Could not fetch provider-specific exercises:", e);
          providerExercises = [];
        }
      }

      const allExercises = _.uniqBy([...SYSTEM_EXERCISE_LIBRARY, ...providerExercises], 'name');

      const allowedDifficulties = painLevel > 3 ? ['beginner'] : ['beginner', 'intermediate'];
      
      const relevantExercises = allExercises.filter(exercise =>
        exercise.body_areas.includes(bodyArea) &&
        allowedDifficulties.includes(exercise.difficulty)
      ).slice(0, 3);
      
      for (const exercise of relevantExercises) {
        const existing = await ExerciseAssigned.filter({ 
          complaint_id: complaintId, 
          exercise_id: exercise.id 
        });
        
        if (existing.length === 0) {
          await ExerciseAssigned.create({
            complaint_id: complaintId,
            exercise_id: exercise.id,
            source: exercise.provider_id === "system" ? "library" : "provider",
            level: exercise.difficulty.charAt(0).toUpperCase() + exercise.difficulty.slice(1),
            sets: exercise.sets || 2,
            reps_or_duration: exercise.repetitions ? `${exercise.repetitions} reps` : `${exercise.duration_minutes} min`,
            times_per_week: `${exercise.days_per_week || 3}x per week`
          });
        }
      }
      
      await logAudit("assign_exercises", "complaint", `Assigned ${relevantExercises.length} exercises for ${bodyArea} (pain level: ${painLevel})`, true);
    } catch (err) {
      console.error("Error assigning exercises:", err);
      await logAudit("assign_exercises", "complaint", `Failed to assign exercises for ${bodyArea}`, false, err.message);
    }
  };

  const handleSubmit = async () => {
    if (!user || user.account_type !== 'patient') {
      setError("This feature is for patient accounts only.");
      return;
    }
    if (!formData.body_area || formData.pain_level < 0) {
      setError("Please select a body area and provide a rating.");
      return;
    }

    setError("");
    setLoading(true);

    try {
      const existingComplaints = await Complaint.filter({ 
        patient_id: user.id, 
        body_area: formData.body_area, 
        status: 'Active' 
      });

      if (existingComplaints.length > 0) {
        toast({
          title: "Complaint Exists",
          description: `You already have an active complaint for this area. Please use the "Update Existing Complaint" option.`,
          variant: "destructive"
        });
        setLoading(false);
        return;
      }

      const complaint = await Complaint.create({
        patient_id: user.id,
        body_area: formData.body_area,
        status: "Active"
      });
      
      await logAudit("create", "complaint", `Created complaint for ${formData.body_area}`, true);
      await notifyProvider(complaint, formData.pain_level);

      const painLogDescription = `Initial report for ${formData.body_area.replace(/_/g, ' ')}. Type: ${formData.pain_type}. Quality: ${formData.pain_quality.join(', ') || 'Not specified'}.`;

      await PainLog.create({
        complaint_id: complaint.id,
        ...formData,
        description: painLogDescription,
      });
      
      await logAudit("create", "pain_log", `${formData.pain_type} level ${formData.pain_level} for ${formData.body_area}`, true);
      
      await assignExercises(complaint.id, formData.body_area, formData.pain_level);
      
      await Complaint.update(complaint.id, { updated_date: new Date().toISOString() });

      onSuccess();
      onClose();

    } catch (err) {
      console.error("Error saving complaint:", err);
      const errorMessage = err.message || "Failed to save complaint";
      setError(errorMessage);
      toast({
        title: "Error",
        description: errorMessage,
        variant: "destructive",
      });
      await logAudit("create", "complaint", `Failed to save complaint for ${formData.body_area}`, false, errorMessage);
    } finally {
      setLoading(false);
    }
  };

  const getRatingScaleInfo = () => {
    switch (formData.pain_type) {
      case "pain":
        return {
          name: "OPS (Optimized Pain Scale)",
          description: "0 = no pain, 10 = worst pain imaginable"
        };
      case "stiffness":
        return {
          name: "NRS (Numeric Rating Scale)",
          description: "0 = no stiffness, 10 = stiff as a board"
        };
      case "tightness":
        return {
          name: "NRS (Numeric Rating Scale)",
          description: "0 = no tightness, 10 = extremely tight"
        };
      default:
        return {
          name: "Rating Scale",
          description: "0 = none, 10 = severe"
        };
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Add New Complaint</DialogTitle>
        </DialogHeader>

        <div className="grid lg:grid-cols-2 gap-6 pt-2">
          <div className="space-y-4">
            <div>
              <Label className="text-sm font-medium mb-2 block">Where are you experiencing discomfort?</Label>
              <BodyMap
                selectedArea={formData.body_area}
                onAreaSelect={(area) => setFormData(prev => ({ ...prev, body_area: area }))}
              />
            </div>

            <div>
              <Label className="text-sm font-medium mb-2 block">Type of Sensation</Label>
              <div className="grid grid-cols-3 gap-2">
                {["pain", "stiffness", "tightness"].map((type) => (
                  <Button
                    key={type}
                    variant={formData.pain_type === type ? "default" : "outline"}
                    onClick={() => setFormData(prev => ({ ...prev, pain_type: type, pain_quality: [] }))}
                    className="capitalize text-sm h-10"
                    size="sm"
                  >
                    {type}
                  </Button>
                ))}
              </div>
            </div>

            <div>
              <Label className="text-sm font-medium mb-2 block text-center">
                {formData.pain_type.charAt(0).toUpperCase() + formData.pain_type.slice(1)} Level
              </Label>
              <div className="text-center mb-2">
                <p className="text-xs text-gray-600 font-medium">{getRatingScaleInfo().name}</p>
                <p className="text-xs text-gray-500">{getRatingScaleInfo().description}</p>
              </div>
              <div className="flex justify-center">
                <div className="flex gap-2 flex-wrap justify-center">
                  {[0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map((level) => (
                    <Button
                      key={level}
                      variant={formData.pain_level === level ? "default" : "outline"}
                      onClick={() => setFormData(prev => ({ ...prev, pain_level: level }))}
                      className="w-8 h-8 p-0 text-sm"
                      size="sm"
                    >
                      {level}
                    </Button>
                  ))}
                </div>
              </div>
            </div>

            {showPainAlert && (
              <div className="p-4 bg-red-50 border border-red-200 rounded-lg">
                <div className="flex items-start gap-3">
                  <AlertTriangle className="w-5 h-5 text-red-600 mt-0.5" />
                  <div>
                    <p className="font-medium text-red-900">High Pain Level Detected</p>
                    <p className="text-sm text-red-700 mb-3">
                      {user?.provider_id 
                        ? `Your pain level (${formData.pain_level}/10) exceeds your provider's threshold. Consider scheduling an appointment.`
                        : `Your pain level (${formData.pain_level}/10) is concerning. We recommend consulting with a healthcare provider.`
                      }
                    </p>
                    <div className="flex gap-2">
                      {user?.provider_id ? (
                        <Button size="sm" className="bg-red-600 hover:bg-red-700">
                          <Calendar className="w-4 h-4 mr-2" />
                          Book Appointment
                        </Button>
                      ) : (
                        <Link to={createPageUrl("FindProviders")}>
                          <Button size="sm" className="bg-red-600 hover:bg-red-700">
                            <Users className="w-4 h-4 mr-2" />
                            Find a Provider
                          </Button>
                        </Link>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>

          <div className="space-y-4">
            <ExerciseSuggestions 
              selectedBodyArea={formData.body_area} 
              painLevel={formData.pain_level}
              user={user} 
            />

            {formData.pain_type === "pain" && (
              <div>
                <Label className="text-sm font-medium mb-2 block">Pain Quality</Label>
                <div className="flex flex-wrap gap-1">
                  {painQualities.map((quality) => (
                    <Button
                      key={quality}
                      variant={formData.pain_quality.includes(quality) ? "default" : "outline"}
                      onClick={() => togglePainQuality(quality)}
                      className="capitalize text-xs h-7 px-2"
                      size="sm"
                    >
                      {quality}
                    </Button>
                  ))}
                </div>
              </div>
            )}

            <div className="grid grid-cols-3 gap-3">
              <div>
                <Label htmlFor="onset" className="text-sm">Onset</Label>
                <Select value={formData.onset} onValueChange={(value) => setFormData(prev => ({ ...prev, onset: value }))}>
                  <SelectTrigger className="h-9">
                    <SelectValue placeholder="How started?" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="sudden">Sudden</SelectItem>
                    <SelectItem value="gradual">Gradual</SelectItem>
                    <SelectItem value="chronic">Chronic</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="frequency" className="text-sm">Frequency</Label>
                <Select value={formData.frequency} onValueChange={(value) => setFormData(prev => ({ ...prev, frequency: value }))}>
                  <SelectTrigger className="h-9">
                    <SelectValue placeholder="How often?" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="constant">Constant</SelectItem>
                    <SelectItem value="intermittent">Intermittent</SelectItem>
                    <SelectItem value="occasional">Occasional</SelectItem>
                    <SelectItem value="rare">Rare</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="triggers" className="text-sm">Triggers</Label>
                <Textarea
                  id="triggers"
                  placeholder="What affects it?"
                  value={formData.triggers}
                  onChange={(e) => setFormData(prev => ({ ...prev, triggers: e.target.value }))}
                  className="h-9 text-sm"
                />
              </div>
            </div>

            {error && (
              <div className="flex items-center gap-2 text-red-600 bg-red-50 p-2 rounded text-sm">
                <AlertTriangle className="w-4 h-4" />
                <p>{error}</p>
              </div>
            )}
          </div>
        </div>

        <DialogFooter className="pt-4">
          <Button variant="outline" onClick={onClose} disabled={loading} size="sm">
            Cancel
          </Button>
          <Button onClick={handleSubmit} disabled={loading} size="sm">
            <Save className="w-4 h-4 mr-2" />
            {loading ? 'Saving...' : 'Save Complaint'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

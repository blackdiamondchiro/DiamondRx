import React, { useState, useEffect, useCallback } from "react";
import { PainLog } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { format } from "date-fns";

export default function ComplaintHistoryModal({ isOpen, onClose, user, complaint }) {
  const [logs, setLogs] = useState([]);
  const [loading, setLoading] = useState(false);

  const loadLogs = useCallback(async () => {
    if (!complaint || !user) return;
    setLoading(true);
    try {
      // Security: Ensure we only fetch logs for a complaint owned by the current user.
      if (complaint.patient_id !== user.id) {
        console.error("Access denied: User does not own this complaint.");
        setLogs([]);
        return;
      }
      const painLogs = await PainLog.filter({ complaint_id: complaint.id }, '-created_date');
      setLogs(painLogs);
    } catch (error) {
      console.error("Failed to load pain logs:", error);
    } finally {
      setLoading(false);
    }
  }, [complaint, user]);

  useEffect(() => {
    if (isOpen) {
      loadLogs();
    }
  }, [isOpen, loadLogs]);
  
  const getPainLevelColor = (level) => {
    if (level >= 7) return "bg-red-500";
    if (level >= 4) return "bg-yellow-500";
    return "bg-green-500";
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>
            Complaint History: <span className="capitalize text-blue-600">{complaint?.body_area.replace(/_/g, ' ')}</span>
          </DialogTitle>
        </DialogHeader>
        <div className="mt-4">
          {loading ? (
            <p>Loading history...</p>
          ) : logs.length > 0 ? (
            <div className="space-y-6 relative pl-6 border-l-2 border-gray-200">
              {logs.map(log => (
                <div key={log.id} className="relative">
                  <div className={`absolute -left-[33px] top-1 w-4 h-4 rounded-full ${getPainLevelColor(log.pain_level)} border-4 border-white`}></div>
                  <p className="text-sm text-gray-500 mb-1">{format(new Date(log.created_date), 'MMMM d, yyyy, h:mm a')}</p>
                  <div className="p-4 bg-gray-50 rounded-lg border">
                    <p className="font-semibold">Pain Level: <span className="font-bold">{log.pain_level}/10</span></p>
                    <p className="mt-2 text-gray-700">{log.description}</p>
                    {log.pain_quality && log.pain_quality.length > 0 && (
                      <div className="mt-2 flex flex-wrap gap-2">
                        {log.pain_quality.map(q => <Badge key={q} variant="secondary" className="capitalize">{q}</Badge>)}
                      </div>
                    )}
                    {log.triggers && <p className="mt-2 text-sm"><strong>Triggers:</strong> {log.triggers}</p>}
                    {log.frequency && <p className="mt-1 text-sm"><strong>Frequency:</strong> <span className="capitalize">{log.frequency}</span></p>}
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-center text-gray-500 py-8">No history found for this complaint.</p>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}

import React, { useState, useEffect } from "react";
import { PainLog } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Save, AlertTriangle, Calendar, Users } from "lucide-react";
import { Link } from "react-router-dom"; // Changed Link import
import { createPageUrl } from "@/utils"; // Added createPageUrl import

const painQualities = ["sharp", "dull", "throbbing", "burning", "aching", "stabbing", "cramping", "shooting"];

export default function UpdateComplaintModal({ 
  isOpen, 
  onClose, 
  onSuccess, 
  user, 
  complaints, 
  initialComplaint 
}) {
  const [selectedComplaint, setSelectedComplaint] = useState(initialComplaint || null);
  const [formData, setFormData] = useState({
    pain_type: "pain",
    pain_level: 0,
    pain_quality: [],
    frequency: "",
    triggers: "",
    description: ""
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [showPainAlert, setShowPainAlert] = useState(false); // New state for pain alert

  useEffect(() => {
    if (isOpen) {
      setError("");
      setShowPainAlert(false); // Reset pain alert on open
      setSelectedComplaint(initialComplaint || null);
      setFormData({
        pain_type: "pain",
        pain_level: 0,
        pain_quality: [],
        frequency: "",
        triggers: "",
        description: ""
      });
    }
  }, [isOpen, initialComplaint]);

  useEffect(() => {
    // Check if pain level exceeds threshold
    // Default threshold is 5 if no provider or pain_threshold is defined for the user
    const threshold = user?.provider_id ? (user?.pain_threshold || 5) : 5;
    setShowPainAlert(formData.pain_level > threshold);
  }, [formData.pain_level, user]); // Depend on pain_level and user object for threshold

  const togglePainQuality = (quality) => {
    setFormData(prev => ({
      ...prev,
      pain_quality: prev.pain_quality.includes(quality)
        ? prev.pain_quality.filter(q => q !== quality)
        : [...prev.pain_quality, quality]
    }));
  };

  const handleSubmit = async () => {
    if (!user || user.account_type !== 'patient') {
      setError("This feature is for patient accounts only.");
      return;
    }
    if (!selectedComplaint) {
      setError("Please select a complaint to update.");
      return;
    }
    if (!formData.description.trim()) {
      setError("Please provide a description of how you're feeling.");
      return;
    }

    setError("");
    setLoading(true);

    try {
      const painLogDescription = formData.description || 
        `Update for ${selectedComplaint.body_area.replace(/_/g, ' ')}. Type: ${formData.pain_type}. Quality: ${formData.pain_quality.join(', ') || 'Not specified'}.`;

      await PainLog.create({
        complaint_id: selectedComplaint.id,
        pain_type: formData.pain_type,
        pain_level: formData.pain_level,
        pain_quality: formData.pain_quality,
        frequency: formData.frequency,
        triggers: formData.triggers,
        description: painLogDescription,
      });

      onSuccess();
      onClose();

    } catch (err) {
      console.error("Error updating complaint:", err);
      const errorMessage = err.message || "Failed to update complaint";
      setError(errorMessage);
    } finally {
      setLoading(false);
    }
  };

  const getRatingScaleInfo = () => {
    switch (formData.pain_type) {
      case "pain":
        return {
          name: "OPS (Optimized Pain Scale)",
          description: "0 = no pain, 10 = worst pain imaginable"
        };
      case "stiffness":
        return {
          name: "NRS (Numeric Rating Scale)",
          description: "0 = no stiffness, 10 = stiff as a board"
        };
      case "tightness":
        return {
          name: "NRS (Numeric Rating Scale)",
          description: "0 = no tightness, 10 = extremely tight"
        };
      default:
        return {
          name: "Rating Scale",
          description: "0 = none, 10 = severe"
        };
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Update Complaint</DialogTitle>
        </DialogHeader>

        <div className="space-y-4 pt-2">
          {/* Complaint Selection */}
          {!initialComplaint && complaints.length > 1 && (
            <div>
              <Label className="text-sm font-medium mb-2 block">Select Complaint to Update</Label>
              <Select
                value={selectedComplaint?.id || ""}
                onValueChange={(value) => setSelectedComplaint(complaints.find(c => c.id === value))}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Choose a complaint..." />
                </SelectTrigger>
                <SelectContent>
                  {complaints.map((complaint) => (
                    <SelectItem key={complaint.id} value={complaint.id}>
                      <span className="capitalize">
                        {complaint.body_area.replace(/_/g, ' ')} - {complaint.status}
                      </span>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          )}

          {selectedComplaint && (
            <div className="p-3 bg-blue-50 border border-blue-200 rounded-lg">
              <p className="text-sm text-blue-800">
                <strong>Updating:</strong> <span className="capitalize">{selectedComplaint.body_area.replace(/_/g, ' ')}</span>
              </p>
            </div>
          )}

          {/* Pain Type Selection */}
          <div>
            <Label className="text-sm font-medium mb-2 block">Type of Sensation</Label>
            <div className="grid grid-cols-3 gap-2">
              {["pain", "stiffness", "tightness"].map((type) => (
                <Button
                  key={type}
                  variant={formData.pain_type === type ? "default" : "outline"}
                  onClick={() => setFormData(prev => ({ ...prev, pain_type: type, pain_quality: type === "pain" ? prev.pain_quality : [] }))}
                  className="capitalize text-sm h-10"
                  size="sm"
                >
                  {type}
                </Button>
              ))}
            </div>
          </div>

          {/* Rating Scale */}
          <div>
            <Label className="text-sm font-medium mb-2 block text-center">
              Current {formData.pain_type.charAt(0).toUpperCase() + formData.pain_type.slice(1)} Level
            </Label>
            <div className="text-center mb-2">
              <p className="text-xs text-gray-600 font-medium">{getRatingScaleInfo().name}</p>
              <p className="text-xs text-gray-500">{getRatingScaleInfo().description}</p>
            </div>
            <div className="flex justify-center">
              <div className="flex gap-2 flex-wrap justify-center">
                {[0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map((level) => (
                  <Button
                    key={level}
                    variant={formData.pain_level === level ? "default" : "outline"}
                    onClick={() => setFormData(prev => ({ ...prev, pain_level: level }))}
                    className="w-8 h-8 p-0 text-sm"
                    size="sm"
                  >
                    {level}
                  </Button>
                ))}
              </div>
            </div>
          </div>

          {/* High Pain Alert */}
          {showPainAlert && (
            <div className="p-4 bg-red-50 border border-red-200 rounded-lg">
              <div className="flex items-start gap-3">
                <AlertTriangle className="w-5 h-5 text-red-600 mt-0.5" />
                <div>
                  <p className="font-medium text-red-900">High Pain Level Detected</p>
                  <p className="text-sm text-red-700 mb-3">
                    {user?.provider_id 
                      ? `Your pain level (${formData.pain_level}/10) exceeds your provider's threshold. Consider scheduling an appointment.`
                      : `Your pain level (${formData.pain_level}/10) is concerning. We recommend consulting with a healthcare provider.`
                    }
                  </p>
                  <div className="flex gap-2">
                    {user?.provider_id ? (
                      // This button would ideally link to a provider booking page or trigger a specific action
                      // For now, it's a placeholder. Replace with actual booking logic.
                      <Button size="sm" className="bg-red-600 hover:bg-red-700" onClick={() => { /* Implement contact provider logic */ }}>
                        <Calendar className="w-4 h-4 mr-2" />
                        Contact Provider
                      </Button>
                    ) : (
                      <Link to={createPageUrl("FindProviders")}> {/* Changed to React Router Link */}
                        <Button size="sm" className="bg-red-600 hover:bg-red-700">
                          <Users className="w-4 h-4 mr-2" />
                          Find a Provider
                        </Button>
                      </Link>
                    )}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Pain Quality - Only show for pain type */}
          {formData.pain_type === "pain" && (
            <div>
              <Label className="text-sm font-medium mb-2 block">Pain Quality</Label>
              <div className="flex flex-wrap gap-1">
                {painQualities.map((quality) => (
                  <Button
                    key={quality}
                    variant={formData.pain_quality.includes(quality) ? "default" : "outline"}
                    onClick={() => togglePainQuality(quality)}
                    className="capitalize text-xs h-7 px-2"
                    size="sm"
                  >
                    {quality}
                  </Button>
                ))}
              </div>
            </div>
          )}

          {/* Additional Details */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <Label htmlFor="frequency" className="text-sm">Frequency</Label>
              <Select value={formData.frequency} onValueChange={(value) => setFormData(prev => ({ ...prev, frequency: value }))}>
                <SelectTrigger className="h-9">
                  <SelectValue placeholder="How often?" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="constant">Constant</SelectItem>
                  <SelectItem value="intermittent">Intermittent</SelectItem>
                  <SelectItem value="occasional">Occasional</SelectItem>
                  <SelectItem value="rare">Rare</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="triggers" className="text-sm">Triggers</Label>
              <Textarea
                id="triggers"
                placeholder="What affects it?"
                value={formData.triggers}
                onChange={(e) => setFormData(prev => ({ ...prev, triggers: e.target.value }))}
                className="h-9 text-sm"
              />
            </div>
          </div>

          {/* Description */}
          <div>
            <Label htmlFor="description" className="text-sm font-medium">How are you feeling today?</Label>
            <Textarea
              id="description"
              placeholder="Describe your current experience with this complaint..."
              value={formData.description}
              onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
              className="h-20"
            />
          </div>

          {error && (
            <div className="flex items-center gap-2 text-red-600 bg-red-50 p-2 rounded text-sm">
              <AlertTriangle className="w-4 h-4" />
              <p>{error}</p>
            </div>
          )}
        </div>

        <DialogFooter className="pt-4">
          <Button variant="outline" onClick={onClose} disabled={loading} size="sm">
            Cancel
          </Button>
          <Button onClick={handleSubmit} disabled={loading} size="sm">
            <Save className="w-4 h-4 mr-2" />
            {loading ? 'Saving...' : 'Log Update'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

import React, { useState, useEffect } from "react";
import { Complaint } from "@/api/entities";
import { PainEntry } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Save, AlertTriangle, X } from "lucide-react";
import BodyMap from "../BodyMap";
import PainScale from "../PainScale";

const initialFormData = {
  body_area: "",
  pain_level: 0,
  pain_quality: [],
  onset: "",
  duration: "",
  frequency: "",
  notes: "",
  triggers: ""
};

export default function NewPainEntryModal({ isOpen, onClose, onSuccess, user, complaint }) {
  const [formData, setFormData] = useState(initialFormData);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    if (isOpen) {
      setError("");
      if (complaint) {
        setFormData({ ...initialFormData, body_area: complaint.body_area });
      } else {
        setFormData(initialFormData);
      }
    }
  }, [isOpen, complaint]);

  const handleSubmit = async () => {
    if (!user || user.account_type !== 'patient') {
      setError("This feature is for patient accounts only.");
      return;
    }
    if (!formData.body_area || formData.pain_level === 0) {
      setError("Please select a body area and a pain level greater than 0.");
      return;
    }

    setError("");
    setLoading(true);

    try {
      let complaintId = complaint?.id;
      
      // If no complaint is passed, find an existing active one or create a new one
      if (!complaintId) {
        const result = await Complaint.filter({ 
          patient_id: user.id, 
          body_area: formData.body_area, 
          status: 'active' 
        });
        if (result.length > 0) {
          const existingComplaint = result[0];
          complaintId = existingComplaint.id;
          await Complaint.update(complaintId, { last_reported_date: new Date().toISOString() });
        } else {
          const now = new Date().toISOString();
          const newComplaint = await Complaint.create({
            patient_id: user.id,
            body_area: formData.body_area,
            status: "active",
            first_reported_date: now,
            last_reported_date: now,
            description: `Pain in ${formData.body_area.replace(/_/g, ' ')}`
          });
          complaintId = newComplaint.id;
        }
      }

      // Create the pain entry linked to the complaint
      await PainEntry.create({
        ...formData,
        complaint_id: complaintId,
        patient_id: user.id
      });

      alert("Your pain entry has been saved and exercises updated for this complaint.");
      onSuccess(); // Refresh the parent page's data
      onClose();   // Close the modal

    } catch (err) {
      console.error("Error saving pain entry:", err);
      setError("Failed to save pain entry. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  const togglePainQuality = (quality) => {
    setFormData(prev => ({
      ...prev,
      pain_quality: prev.pain_quality.includes(quality)
        ? prev.pain_quality.filter(q => q !== quality)
        : [...prev.pain_quality, quality]
    }));
  };

  const painQualities = ["sharp", "dull", "throbbing", "burning", "aching", "stabbing", "cramping", "shooting"];

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Log a New Pain Entry</DialogTitle>
          <DialogDescription>
            Your entry will be added to the relevant complaint, or a new one will be created.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6 pt-4">
          <div>
            <Label className="text-base font-medium mb-4 block">Where is your pain located?</Label>
            <BodyMap
              selectedArea={formData.body_area}
              onAreaSelect={(area) => setFormData(prev => ({ ...prev, body_area: area }))}
              disabled={!!complaint}
            />
            {complaint && <p className="text-sm text-gray-500 mt-2 text-center">Body area is pre-selected from your complaint.</p>}
          </div>

          <div>
            <Label className="text-base font-medium mb-4 block">Pain Level (0-10)</Label>
            <PainScale
              value={formData.pain_level}
              onChange={(level) => setFormData(prev => ({ ...prev, pain_level: level }))}
            />
          </div>

          <div>
            <Label className="text-base font-medium mb-3 block">How would you describe the pain?</Label>
            <div className="flex flex-wrap gap-2">
              {painQualities.map((quality) => (
                <Button key={quality} type="button" variant={formData.pain_quality.includes(quality) ? "default" : "outline"} size="sm" onClick={() => togglePainQuality(quality)} className="capitalize">
                  {quality}
                </Button>
              ))}
            </div>
          </div>

          <div className="grid md:grid-cols-3 gap-4">
            <div>
              <Label htmlFor="onset">Onset</Label>
              <Select value={formData.onset} onValueChange={(value) => setFormData(prev => ({ ...prev, onset: value }))}>
                <SelectTrigger><SelectValue placeholder="Select onset" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="sudden">Sudden</SelectItem>
                  <SelectItem value="gradual">Gradual</SelectItem>
                  <SelectItem value="chronic">Chronic</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="duration">Duration</Label>
              <Select value={formData.duration} onValueChange={(value) => setFormData(prev => ({ ...prev, duration: value }))}>
                <SelectTrigger><SelectValue placeholder="Select duration" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="minutes">Minutes</SelectItem>
                  <SelectItem value="hours">Hours</SelectItem>
                  <SelectItem value="days">Days</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="frequency">Frequency</Label>
              <Select value={formData.frequency} onValueChange={(value) => setFormData(prev => ({ ...prev, frequency: value }))}>
                <SelectTrigger><SelectValue placeholder="Select frequency" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="constant">Constant</SelectItem>
                  <SelectItem value="intermittent">Intermittent</SelectItem>
                  <SelectItem value="occasional">Occasional</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="grid md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="triggers">Pain Triggers</Label>
              <Textarea id="triggers" placeholder="E.g., Sitting, lifting..." value={formData.triggers} onChange={(e) => setFormData(prev => ({ ...prev, triggers: e.target.value }))} />
            </div>
            <div>
              <Label htmlFor="notes">Additional Notes</Label>
              <Textarea id="notes" placeholder="Any other details..." value={formData.notes} onChange={(e) => setFormData(prev => ({ ...prev, notes: e.target.value }))} />
            </div>
          </div>
              
          {error && (
            <div className="flex items-center gap-2 text-red-600 bg-red-50 p-3 rounded-lg">
              <AlertTriangle className="w-5 h-5"/>
              <p>{error}</p>
            </div>
          )}
        </div>

        <DialogFooter className="pt-6">
          <Button variant="outline" onClick={onClose} disabled={loading}>Cancel</Button>
          <Button onClick={handleSubmit} disabled={loading}>
            <Save className="w-4 h-4 mr-2" />
            {loading ? 'Saving...' : 'Save Pain Entry'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
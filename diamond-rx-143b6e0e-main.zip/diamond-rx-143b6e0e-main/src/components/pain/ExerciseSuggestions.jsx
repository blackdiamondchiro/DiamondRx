import React, { useState, useEffect } from "react";
import { Exercise } from "@/api/entities";
import { SYSTEM_EXERCISE_LIBRARY } from "../data/SystemExercises";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Heart, Clock, RotateCcw, ArrowRight, Loader2, AlertTriangle } from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import _ from 'lodash';

export default function ExerciseSuggestions({ selectedBodyArea, painLevel, user, className = "" }) {
  const [suggestions, setSuggestions] = useState([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    const fetchAndFilterExercises = async () => {
      if (!selectedBodyArea) {
        setSuggestions([]);
        return;
      }

      setLoading(true);
      try {
        let providerExercises = [];
        if (user?.provider_id) {
          try {
            providerExercises = await Exercise.filter({ provider_id: user.provider_id });
          } catch (e) {
             console.warn("Could not fetch provider-specific exercises. This may be expected if the patient is not linked to a provider with custom exercises.", e);
             providerExercises = [];
          }
        }

        // Combine system and provider exercises, then remove duplicates by name
        const allExercises = _.uniqBy([...SYSTEM_EXERCISE_LIBRARY, ...providerExercises], 'name');

        // Filter by difficulty based on pain level
        const allowedDifficulties = painLevel > 3 ? ['beginner'] : ['beginner', 'intermediate'];

        const relevantExercises = allExercises.filter(exercise =>
          exercise.body_areas.includes(selectedBodyArea) &&
          allowedDifficulties.includes(exercise.difficulty)
        ).slice(0, 3); // Show top 3 suggestions

        setSuggestions(relevantExercises);

      } catch (error) {
        console.error("Error fetching exercise suggestions:", error);
        // Fallback to just system exercises if fetch fails
        const allowedDifficulties = painLevel > 3 ? ['beginner'] : ['beginner', 'intermediate'];
        const relevantSystemExercises = SYSTEM_EXERCISE_LIBRARY.filter(exercise =>
          exercise.body_areas.includes(selectedBodyArea) &&
          allowedDifficulties.includes(exercise.difficulty)
        ).slice(0, 3);
        setSuggestions(relevantSystemExercises);
      } finally {
        setLoading(false);
      }
    };

    fetchAndFilterExercises();
  }, [selectedBodyArea, painLevel, user]);

  const difficultyColors = {
    beginner: "bg-green-100 text-green-800",
    intermediate: "bg-yellow-100 text-yellow-800",
    advanced: "bg-red-100 text-red-800"
  };
  
  if (!selectedBodyArea) {
    return null;
  }

  if (loading) {
    return (
        <Card className={`bg-blue-50 border-blue-200 ${className}`}>
            <CardHeader className="pb-3">
                <CardTitle className="text-lg flex items-center gap-2 text-blue-800">
                    <Heart className="w-5 h-5" />
                    Finding Suggested Exercises...
                </CardTitle>
            </CardHeader>
            <CardContent className="flex justify-center items-center h-48">
                <Loader2 className="w-8 h-8 text-blue-600 animate-spin" />
            </CardContent>
        </Card>
    );
  }

  return (
    <Card className={`bg-blue-50 border-blue-200 ${className}`}>
      <CardHeader className="pb-3">
        <CardTitle className="text-lg flex items-center gap-2 text-blue-800">
          <Heart className="w-5 h-5" />
          Suggested Exercises for {selectedBodyArea.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase())}
        </CardTitle>
        {painLevel > 3 && (
          <div className="flex items-center gap-2 mt-2 p-2 bg-orange-50 border border-orange-200 rounded-lg">
            <AlertTriangle className="w-4 h-4 text-orange-600" />
            <p className="text-sm text-orange-700">
              Showing gentle exercises only due to high pain level ({painLevel}/10)
            </p>
          </div>
        )}
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          {suggestions.length > 0 ? (
            <>
              {suggestions.map((exercise) => (
                <div key={exercise.id} className="bg-white rounded-lg p-3 border border-blue-100">
                  <div className="flex justify-between items-start mb-2">
                    <h4 className="font-medium text-gray-900 text-sm">{exercise.name}</h4>
                    <Badge className={difficultyColors[exercise.difficulty]} variant="outline">
                      {exercise.difficulty}
                    </Badge>
                  </div>
                  <p className="text-xs text-gray-600 mb-2">{exercise.description}</p>
                  <div className="flex gap-3 text-xs text-gray-500">
                    {exercise.duration_minutes && (
                      <div className="flex items-center gap-1">
                        <Clock className="w-3 h-3" />
                        <span>{exercise.duration_minutes}min</span>
                      </div>
                    )}
                    {exercise.repetitions && (
                      <div className="flex items-center gap-1">
                        <RotateCcw className="w-3 h-3" />
                        <span>{exercise.repetitions}x</span>
                      </div>
                    )}
                    {exercise.sets && (
                      <span>{exercise.sets} sets</span>
                    )}
                  </div>
                </div>
              ))}
              <div className="mt-4 pt-3 border-t border-blue-200">
                <p className="text-xs text-blue-700 mb-2 text-center">
                  ✓ These exercises will be automatically added to your complaint
                </p>
              </div>
            </>
          ) : (
            <p className="text-center text-gray-600 py-8">
              No exercises found for this area at your current pain level.
            </p>
          )}
        </div>
        <div className="mt-4 pt-3 border-t border-blue-200">
          <Link to={createPageUrl("Exercises")}>
            <Button variant="outline" size="sm" className="w-full bg-white hover:bg-blue-50">
              View All Exercises
              <ArrowRight className="w-4 h-4 ml-2" />
            </Button>
          </Link>
        </div>
      </CardContent>
    </Card>
  );
}
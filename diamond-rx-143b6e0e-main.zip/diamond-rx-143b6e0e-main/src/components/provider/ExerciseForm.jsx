
import React from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue
} from "@/components/ui/select";
import { Badge } from "@/components/ui/badge"; // Added Badge import
import { ICD10Code } from "@/api/entities";

const bodyAreas = [
  "head", "neck", "shoulder", "arm", "chest", "upper_back",
  "lower_back", "abdomen", "hip", "thigh", "knee",
  "calf", "foot"
];

export default function ExerciseForm({ exercise, onSubmit, onCancel }) {
  const [formData, setFormData] = React.useState({
    name: "",
    description: "",
    instructions: "",
    video_url: "",
    body_areas: [],
    difficulty: "beginner",
    duration_minutes: "", // Initialized as string
    repetitions: "",     // Initialized as string
    sets: "",            // Initialized as string
    days_per_week: 3,
    notes: "",
    icd10_codes: []
  });
  const [icd10Library, setIcd10Library] = React.useState([]);
  const [loading, setLoading] = React.useState(false);

  React.useEffect(() => {
    if (exercise) {
      setFormData({
        name: exercise.name || "",
        description: exercise.description || "",
        instructions: exercise.instructions || "",
        video_url: exercise.video_url || "",
        body_areas: exercise.body_areas || [],
        difficulty: exercise.difficulty || "beginner",
        // Ensure numbers are treated as strings if they are meant to be displayed as such in inputs
        duration_minutes: exercise.duration_minutes !== undefined && exercise.duration_minutes !== null ? String(exercise.duration_minutes) : "",
        repetitions: exercise.repetitions !== undefined && exercise.repetitions !== null ? String(exercise.repetitions) : "",
        sets: exercise.sets !== undefined && exercise.sets !== null ? String(exercise.sets) : "",
        days_per_week: exercise.days_per_week !== undefined && exercise.days_per_week !== null ? exercise.days_per_week : 3,
        notes: exercise.notes || "",
        icd10_codes: exercise.icd10_codes || []
      });
    }

    // Load ICD-10 codes
    loadICD10Codes();
  }, [exercise]);

  const loadICD10Codes = async () => {
    try {
      const codes = await ICD10Code.list();
      setIcd10Library(codes);
    } catch (error) {
      console.error("Error loading ICD-10 codes:", error);
    }
  };

  const toggleBodyArea = (area) => {
    setFormData(prev => ({
      ...prev,
      body_areas: prev.body_areas.includes(area)
        ? prev.body_areas.filter(a => a !== area)
        : [...prev.body_areas, area]
    }));
  };

  const toggleIcd10Code = (code) => {
    setFormData(prev => ({
      ...prev,
      icd10_codes: prev.icd10_codes.includes(code)
        ? prev.icd10_codes.filter(c => c !== code)
        : [...prev.icd10_codes, code]
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!formData.name || formData.body_areas.length === 0) {
      alert("Please provide exercise name and select at least one body area.");
      return;
    }

    // Convert string number inputs to actual numbers for submission if they are not empty
    const dataToSubmit = {
      ...formData,
      duration_minutes: formData.duration_minutes === "" ? null : parseInt(formData.duration_minutes, 10),
      repetitions: formData.repetitions === "" ? null : parseInt(formData.repetitions, 10),
      sets: formData.sets === "" ? null : parseInt(formData.sets, 10),
    };

    setLoading(true);
    await onSubmit(dataToSubmit);
    setLoading(false);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      {/* Basic Information */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div>
          <Label htmlFor="name">Exercise Name *</Label>
          <Input
            id="name"
            value={formData.name}
            onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
            placeholder="Enter exercise name"
            required
          />
        </div>

        <div>
          <Label htmlFor="difficulty">Difficulty Level</Label>
          <Select
            value={formData.difficulty}
            onValueChange={(value) => setFormData(prev => ({ ...prev, difficulty: value }))}
          >
            <SelectTrigger>
              <SelectValue placeholder="Select difficulty" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="beginner">Beginner</SelectItem>
              <SelectItem value="intermediate">Intermediate</SelectItem>
              <SelectItem value="advanced">Advanced</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* Description and Instructions */}
      <div className="space-y-4">
        <div>
          <Label htmlFor="description">Description</Label>
          <Textarea
            id="description"
            value={formData.description}
            onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
            placeholder="Brief description of the exercise"
            className="h-24"
          />
        </div>

        <div>
          <Label htmlFor="instructions">Step-by-Step Instructions</Label>
          <Textarea
            id="instructions"
            value={formData.instructions}
            onChange={(e) => setFormData(prev => ({ ...prev, instructions: e.target.value }))}
            placeholder="Detailed instructions on how to perform the exercise"
            className="h-32"
          />
        </div>

        <div>
          <Label htmlFor="video_url">Video URL (Optional)</Label>
          <Input
            id="video_url"
            type="url"
            value={formData.video_url}
            onChange={(e) => setFormData(prev => ({ ...prev, video_url: e.target.value }))}
            placeholder="https://youtube.com/watch?v=..."
          />
        </div>
      </div>

      {/* Body Areas */}
      <div>
        <Label className="text-base font-medium mb-3 block">Target Body Areas *</Label>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          {bodyAreas.map((area) => (
            <Button
              key={area}
              type="button"
              variant={formData.body_areas.includes(area) ? "default" : "outline"}
              size="sm"
              onClick={() => toggleBodyArea(area)}
              className="justify-start capitalize" // Changed from text-xs to capitalize
            >
              {area.replace('_', ' ')}
            </Button>
          ))}
        </div>
        {formData.body_areas.length === 0 && (
          <p className="text-sm text-red-500 mt-2">Please select at least one body area</p>
        )}
      </div>

      {/* ICD-10 Codes */}
      <div>
        <Label className="text-base font-medium mb-3 block">Associated ICD-10 Codes</Label>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3 max-h-48 overflow-y-auto border border-gray-200 rounded-lg p-3">
          {icd10Library.map((code) => (
            <Button
              key={code.id}
              type="button"
              variant={formData.icd10_codes.includes(code.code) ? "default" : "outline"}
              size="sm"
              onClick={() => toggleIcd10Code(code.code)}
              className="justify-start text-left h-auto p-3"
            >
              <div>
                <div className="font-mono text-xs">{code.code}</div>
                <div className="text-xs opacity-75">{code.description}</div>
              </div>
            </Button>
          ))}
        </div>
        {formData.icd10_codes.length > 0 && (
          <div className="flex flex-wrap gap-2 mt-2">
            {formData.icd10_codes.map(code => (
              <Badge key={code} variant="secondary">{code}</Badge>
            ))}
          </div>
        )}
      </div>

      {/* Exercise Parameters */}
      <div>
        <Label className="text-base font-medium mb-3 block">Exercise Parameters</Label>
        <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
          <div>
            <Label htmlFor="sets">Sets</Label>
            <Input
              id="sets"
              type="number"
              min="1"
              value={formData.sets}
              onChange={(e) => setFormData(prev => ({ ...prev, sets: e.target.value }))}
              placeholder="3"
            />
          </div>
          <div>
            <Label htmlFor="repetitions">Repetitions</Label>
            <Input
              id="repetitions"
              type="number"
              min="1"
              value={formData.repetitions}
              onChange={(e) => setFormData(prev => ({ ...prev, repetitions: e.target.value }))}
              placeholder="10"
            />
          </div>
          <div>
            <Label htmlFor="duration">Duration (min)</Label>
            <Input
              id="duration"
              type="number"
              min="1"
              value={formData.duration_minutes}
              onChange={(e) => setFormData(prev => ({ ...prev, duration_minutes: e.target.value }))}
              placeholder="5"
            />
          </div>
          <div>
            <Label htmlFor="frequency">Days/Week</Label>
            <Input
              id="frequency"
              type="number"
              min="1"
              max="7"
              value={formData.days_per_week}
              onChange={(e) => setFormData(prev => ({ ...prev, days_per_week: parseInt(e.target.value, 10) || 1 }))}
            />
          </div>
        </div>
      </div>

      {/* Notes */}
      <div>
        <Label htmlFor="notes">Additional Notes</Label>
        <Textarea
          id="notes"
          value={formData.notes}
          onChange={(e) => setFormData(prev => ({ ...prev, notes: e.target.value }))}
          placeholder="Any additional notes or precautions for patients"
          className="h-24"
        />
      </div>

      {/* Form Actions */}
      <div className="flex justify-end gap-3 pt-6 border-t">
        <Button type="button" variant="outline" onClick={onCancel}>
          Cancel
        </Button>
        <Button type="submit" disabled={loading} className="bg-green-600 hover:bg-green-700">
          {loading ? 'Saving...' : (exercise ? 'Update Exercise' : 'Create Exercise')}
        </Button>
      </div>
    </form>
  );
}


import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Edit, Trash2 } from "lucide-react";

export default function ExerciseCard({ exercise, onEdit, onDelete }) {
  const difficultyColors = {
    beginner: "bg-green-100 text-green-800 border-green-200",
    intermediate: "bg-yellow-100 text-yellow-800 border-yellow-200",
    advanced: "bg-red-100 text-red-800 border-red-200"
  };

  return (
    <Card className="shadow-lg hover:shadow-xl transition-shadow duration-300">
      <CardHeader className="pb-3">
        <div className="flex justify-between items-start">
          <CardTitle className="text-lg font-bold text-gray-900 line-clamp-2">
            {exercise.name}
          </CardTitle>
          <div className="flex gap-1">
            <Button variant="ghost" size="icon" onClick={() => onEdit(exercise)}>
              <Edit className="w-4 h-4" />
            </Button>
            <Button variant="ghost" size="icon" onClick={() => onDelete(exercise.id)}>
              <Trash2 className="w-4 h-4 text-red-500" />
            </Button>
          </div>
        </div>
        <div className="flex gap-2 mt-2">
          <Badge className={difficultyColors[exercise.difficulty]} variant="outline">
            {exercise.difficulty}
          </Badge>
          {exercise.video_url && (
            <Badge variant="outline" className="bg-purple-100 text-purple-800 border-purple-200">
              Video
            </Badge>
          )}
        </div>
      </CardHeader>

      <CardContent className="space-y-4">
        {exercise.description && (
          <p className="text-gray-600 text-sm line-clamp-3">
            {exercise.description}
          </p>
        )}

        <div>
          <p className="text-xs font-medium text-gray-500 mb-2">Target Areas:</p>
          <div className="flex flex-wrap gap-1">
            {exercise.body_areas?.slice(0, 4).map((area, index) => (
              <Badge key={index} variant="secondary" className="text-xs capitalize">
                {area.replace('_', ' ')}
              </Badge>
            ))}
            {exercise.body_areas?.length > 4 && (
              <Badge variant="secondary" className="text-xs">
                +{exercise.body_areas.length - 4} more
              </Badge>
            )}
          </div>
        </div>

        {/* ICD-10 Codes */}
        {exercise.icd10_codes && exercise.icd10_codes.length > 0 && (
          <div>
            <p className="text-xs font-medium text-gray-500 mb-2">ICD-10 Codes:</p>
            <div className="flex flex-wrap gap-1">
              {exercise.icd10_codes.slice(0, 3).map((code, index) => (
                <Badge key={index} variant="outline" className="text-xs bg-blue-50 text-blue-700 border-blue-200">
                  {code}
                </Badge>
              ))}
              {exercise.icd10_codes.length > 3 && (
                <Badge variant="outline" className="text-xs">
                  +{exercise.icd10_codes.length - 3} more
                </Badge>
              )}
            </div>
          </div>
        )}

        {/* Exercise Parameters */}
        {(exercise.sets || exercise.repetitions || exercise.duration_minutes || exercise.days_per_week) && (
          <div className="p-3 bg-gray-50 rounded-lg">
            <p className="text-xs font-medium text-gray-500 mb-2">Recommended:</p>
            <div className="text-sm text-gray-700 space-y-1">
              {exercise.sets && exercise.repetitions && (
                <p>{exercise.sets} sets × {exercise.repetitions} reps</p>
              )}
              {exercise.duration_minutes && (
                <p>{exercise.duration_minutes} minutes</p>
              )}
              {exercise.days_per_week && (
                <p>{exercise.days_per_week}x per week</p>
              )}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

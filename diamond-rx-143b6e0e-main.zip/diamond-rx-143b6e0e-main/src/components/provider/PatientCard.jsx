import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  Phone, 
  Mail, 
  Activity, 
  AlertTriangle, 
  TrendingUp, 
  Calendar,
  User
} from "lucide-react";
import { format } from "date-fns";
import PatientDetailModal from "./PatientDetailModal";

export default function PatientCard({ patient, onSelect }) {
  const [showDetailModal, setShowDetailModal] = React.useState(false);

  const getRiskLevel = () => {
    if (patient.last_pain_entry?.pain_level >= 7) return "high";
    if (patient.avg_pain >= 5) return "medium";
    return "low";
  };

  const getRiskColor = (risk) => {
    switch (risk) {
      case "high": return "text-red-600 bg-red-50 border-red-200";
      case "medium": return "text-yellow-600 bg-yellow-50 border-yellow-200";
      default: return "text-green-600 bg-green-50 border-green-200";
    }
  };

  const riskLevel = getRiskLevel();
  const isHighRisk = riskLevel === "high";

  return (
    <>
      <Card className={`shadow-lg hover:shadow-xl transition-shadow duration-300 ${
        isHighRisk ? 'ring-2 ring-red-200' : ''
      }`}>
        <CardHeader className="pb-3">
          <div className="flex justify-between items-start">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-gradient-to-r from-blue-500 to-purple-500 rounded-full flex items-center justify-center">
                <User className="w-5 h-5 text-white" />
              </div>
              <div>
                <CardTitle className="text-lg font-bold text-gray-900">
                  {patient.full_name}
                </CardTitle>
                <p className="text-sm text-gray-500">{patient.email}</p>
              </div>
            </div>
            
            <Badge className={`${getRiskColor(riskLevel)} border font-medium`}>
              {riskLevel} risk
            </Badge>
          </div>
        </CardHeader>
        
        <CardContent className="space-y-4">
          {/* Contact Info */}
          <div className="space-y-2">
            <div className="flex items-center gap-2 text-sm text-gray-600">
              <Phone className="w-4 h-4" />
              <span>{patient.phone || 'No phone number'}</span>
            </div>
            <div className="flex items-center gap-2 text-sm text-gray-600">
              <Calendar className="w-4 h-4" />
              <span>Patient since {format(new Date(patient.created_date), 'MMM yyyy')}</span>
            </div>
          </div>

          {/* Pain Stats */}
          <div className="grid grid-cols-2 gap-4 p-3 bg-gray-50 rounded-lg">
            <div className="text-center">
              <div className="text-xl font-bold text-gray-900">
                {patient.avg_pain?.toFixed(1) || '0'}/10
              </div>
              <div className="text-xs text-gray-500">Avg Pain</div>
            </div>
            <div className="text-center">
              <div className="text-xl font-bold text-gray-900">
                {patient.total_entries || 0}
              </div>
              <div className="text-xs text-gray-500">Entries</div>
            </div>
          </div>

          {/* Latest Pain Entry */}
          {patient.last_pain_entry && (
            <div className="p-3 border rounded-lg">
              <div className="flex justify-between items-center mb-2">
                <span className="text-sm font-medium">Latest Pain Report</span>
                <Badge variant={patient.last_pain_entry.pain_level >= 7 ? "destructive" : "secondary"}>
                  {patient.last_pain_entry.pain_level}/10
                </Badge>
              </div>
              <p className="text-sm text-gray-600 capitalize mb-1">
                {patient.last_pain_entry.body_area?.replace('_', ' ')} pain
              </p>
              <p className="text-xs text-gray-500">
                {format(new Date(patient.last_pain_entry.created_date), 'MMM d, h:mm a')}
              </p>
            </div>
          )}

          {/* High Risk Alert */}
          {isHighRisk && (
            <div className="flex items-center gap-2 p-2 bg-red-50 border border-red-200 rounded-lg">
              <AlertTriangle className="w-4 h-4 text-red-600" />
              <span className="text-sm text-red-700 font-medium">
                Requires immediate attention
              </span>
            </div>
          )}

          {/* Actions */}
          <div className="flex gap-2 pt-2">
            <Button 
              variant="outline" 
              size="sm" 
              className="flex-1"
              onClick={() => setShowDetailModal(true)}
            >
              <Activity className="w-4 h-4 mr-2" />
              View Details
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => window.location.href = `mailto:${patient.email}`}
            >
              <Mail className="w-4 h-4" />
            </Button>
            {patient.phone && (
              <Button
                variant="outline"
                size="sm"
                onClick={() => window.location.href = `tel:${patient.phone}`}
              >
                <Phone className="w-4 h-4" />
              </Button>
            )}
          </div>
        </CardContent>
      </Card>

      <PatientDetailModal 
        isOpen={showDetailModal}
        onClose={() => setShowDetailModal(false)}
        patient={patient}
      />
    </>
  );
}
import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Calendar, Heart, User, FileText, Edit } from "lucide-react";
import { format } from "date-fns";

export default function PrescriptionCard({ prescription, onEdit, onView }) {
  const getStatusColor = (status) => {
    switch (status) {
      case "active": return "bg-green-100 text-green-800";
      case "completed": return "bg-blue-100 text-blue-800";
      case "paused": return "bg-yellow-100 text-yellow-800";
      default: return "bg-gray-100 text-gray-800";
    }
  };

  return (
    <Card className="hover:shadow-lg transition-shadow">
      <CardHeader className="pb-4">
        <div className="flex justify-between items-start">
          <div>
            <CardTitle className="text-lg font-bold text-gray-900">
              {prescription.title}
            </CardTitle>
            <div className="flex items-center gap-2 mt-1">
              <User className="w-4 h-4 text-gray-500" />
              <span className="text-sm text-gray-600">{prescription.patient_name}</span>
            </div>
          </div>
          <Badge className={getStatusColor(prescription.status)}>
            {prescription.status}
          </Badge>
        </div>
      </CardHeader>
      
      <CardContent className="space-y-4">
        {/* ICD-10 Codes */}
        {prescription.icd10_codes && prescription.icd10_codes.length > 0 && (
          <div>
            <p className="text-sm font-medium text-gray-700 mb-2">Diagnostic Codes:</p>
            <div className="flex flex-wrap gap-1">
              {prescription.icd10_codes.map((code) => (
                <Badge key={code} variant="outline" className="text-xs">
                  {code}
                </Badge>
              ))}
            </div>
          </div>
        )}

        {/* Exercise Count */}
        <div className="flex items-center gap-2">
          <Heart className="w-4 h-4 text-blue-500" />
          <span className="text-sm text-gray-600">
            {prescription.prescribed_exercises?.length || 0} exercises prescribed
          </span>
        </div>

        {/* Dates */}
        <div className="flex items-center gap-4 text-sm text-gray-500">
          <div className="flex items-center gap-1">
            <Calendar className="w-4 h-4" />
            <span>Started: {format(new Date(prescription.start_date), 'MMM d, yyyy')}</span>
          </div>
          {prescription.end_date && (
            <div className="flex items-center gap-1">
              <Calendar className="w-4 h-4" />
              <span>Ends: {format(new Date(prescription.end_date), 'MMM d, yyyy')}</span>
            </div>
          )}
        </div>

        {/* Description */}
        {prescription.description && (
          <p className="text-sm text-gray-600 bg-gray-50 p-3 rounded-lg">
            {prescription.description}
          </p>
        )}

        {/* Actions */}
        <div className="flex gap-2 pt-2">
          <Button variant="outline" size="sm" onClick={() => onView(prescription)}>
            <FileText className="w-4 h-4 mr-1" />
            View Details
          </Button>
          <Button variant="outline" size="sm" onClick={() => onEdit(prescription)}>
            <Edit className="w-4 h-4 mr-1" />
            Edit
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
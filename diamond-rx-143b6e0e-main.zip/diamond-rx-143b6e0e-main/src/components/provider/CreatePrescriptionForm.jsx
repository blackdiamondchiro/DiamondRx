import React, { useState, useEffect } from "react";
import { Exercise } from "@/api/entities";
import { ICD10Code } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Plus, X, Search } from "lucide-react";
import { SYSTEM_EXERCISE_LIBRARY } from "../data/SystemExercises";
import _ from 'lodash';

export default function CreatePrescriptionForm({ onSubmit, onCancel, selectedPatient }) {
  const [formData, setFormData] = useState({
    patient_id: selectedPatient?.id || "",
    title: "",
    description: "",
    icd10_codes: [],
    prescribed_exercises: [],
    start_date: new Date().toISOString().split('T')[0],
    end_date: "",
    notes: ""
  });
  
  const [availableExercises, setAvailableExercises] = useState([]);
  const [icd10Codes, setIcd10Codes] = useState([]);
  const [exerciseSearch, setExerciseSearch] = useState("");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      // Load provider exercises + system library
      const providerExercises = await Exercise.list();
      const combinedExercises = _.uniqBy([...SYSTEM_EXERCISE_LIBRARY, ...providerExercises], 'name');
      setAvailableExercises(combinedExercises);

      // Load ICD-10 codes
      const codes = await ICD10Code.list();
      setIcd10Codes(codes);
    } catch (error) {
      console.error("Error loading data:", error);
    } finally {
      setLoading(false);
    }
  };

  const addIcd10Code = (codeId) => {
    const code = icd10Codes.find(c => c.id === codeId);
    if (code && !formData.icd10_codes.includes(code.code)) {
      setFormData(prev => ({
        ...prev,
        icd10_codes: [...prev.icd10_codes, code.code]
      }));
    }
  };

  const removeIcd10Code = (codeToRemove) => {
    setFormData(prev => ({
      ...prev,
      icd10_codes: prev.icd10_codes.filter(code => code !== codeToRemove)
    }));
  };

  const addExercise = (exercise) => {
    if (!formData.prescribed_exercises.find(ex => ex.exercise_id === exercise.id)) {
      setFormData(prev => ({
        ...prev,
        prescribed_exercises: [...prev.prescribed_exercises, {
          exercise_id: exercise.id,
          exercise_name: exercise.name,
          sets: exercise.sets || 2,
          repetitions: exercise.repetitions || null,
          duration_minutes: exercise.duration_minutes || null,
          frequency_per_week: exercise.days_per_week || 3,
          special_instructions: ""
        }]
      }));
    }
  };

  const removeExercise = (exerciseId) => {
    setFormData(prev => ({
      ...prev,
      prescribed_exercises: prev.prescribed_exercises.filter(ex => ex.exercise_id !== exerciseId)
    }));
  };

  const updateExercise = (exerciseId, field, value) => {
    setFormData(prev => ({
      ...prev,
      prescribed_exercises: prev.prescribed_exercises.map(ex =>
        ex.exercise_id === exerciseId ? { ...ex, [field]: value } : ex
      )
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!formData.title || !formData.patient_id || formData.prescribed_exercises.length === 0) {
      alert("Please fill in all required fields and add at least one exercise.");
      return;
    }
    onSubmit(formData);
  };

  const filteredExercises = availableExercises.filter(exercise =>
    exercise.name.toLowerCase().includes(exerciseSearch.toLowerCase()) ||
    exercise.description?.toLowerCase().includes(exerciseSearch.toLowerCase())
  );

  if (loading) {
    return <div className="text-center py-8">Loading...</div>;
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-6 max-w-4xl">
      {/* Basic Information */}
      <Card>
        <CardHeader>
          <CardTitle>Prescription Details</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="title">Diagnosis/Title *</Label>
              <Input
                id="title"
                placeholder="e.g., Chronic Lower Back Pain"
                value={formData.title}
                onChange={(e) => setFormData(prev => ({ ...prev, title: e.target.value }))}
                required
              />
            </div>
            <div>
              <Label htmlFor="start_date">Start Date</Label>
              <Input
                id="start_date"
                type="date"
                value={formData.start_date}
                onChange={(e) => setFormData(prev => ({ ...prev, start_date: e.target.value }))}
              />
            </div>
          </div>
          
          <div>
            <Label htmlFor="description">Description & Goals</Label>
            <Textarea
              id="description"
              placeholder="Describe the condition and treatment goals..."
              value={formData.description}
              onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
              rows={3}
            />
          </div>
        </CardContent>
      </Card>

      {/* ICD-10 Codes */}
      <Card>
        <CardHeader>
          <CardTitle>Associated ICD-10 Codes</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <Select onValueChange={addIcd10Code}>
              <SelectTrigger>
                <SelectValue placeholder="Search and add ICD-10 codes..." />
              </SelectTrigger>
              <SelectContent>
                {icd10Codes.map((code) => (
                  <SelectItem key={code.id} value={code.id}>
                    {code.code} - {code.description}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            
            <div className="flex flex-wrap gap-2">
              {formData.icd10_codes.map((code) => {
                const codeInfo = icd10Codes.find(c => c.code === code);
                return (
                  <Badge key={code} variant="outline" className="flex items-center gap-1">
                    {code} - {codeInfo?.description}
                    <Button
                      type="button"
                      variant="ghost"
                      size="sm"
                      className="h-4 w-4 p-0 hover:bg-red-100"
                      onClick={() => removeIcd10Code(code)}
                    >
                      <X className="w-3 h-3" />
                    </Button>
                  </Badge>
                );
              })}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Exercise Selection */}
      <Card>
        <CardHeader>
          <CardTitle>Select Exercises</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              <Input
                placeholder="Search exercises..."
                value={exerciseSearch}
                onChange={(e) => setExerciseSearch(e.target.value)}
                className="pl-10"
              />
            </div>
            
            <div className="max-h-64 overflow-y-auto border rounded-lg">
              {filteredExercises.map((exercise) => (
                <div key={exercise.id} className="p-3 border-b hover:bg-gray-50 flex items-center justify-between">
                  <div>
                    <h4 className="font-medium">{exercise.name}</h4>
                    <p className="text-sm text-gray-600">{exercise.description}</p>
                    <div className="flex gap-1 mt-1">
                      <Badge variant="outline" className="text-xs">
                        {exercise.difficulty}
                      </Badge>
                      {exercise.body_areas?.map(area => (
                        <Badge key={area} variant="secondary" className="text-xs capitalize">
                          {area.replace('_', ' ')}
                        </Badge>
                      ))}
                    </div>
                  </div>
                  <Button
                    type="button"
                    size="sm"
                    onClick={() => addExercise(exercise)}
                    disabled={formData.prescribed_exercises.find(ex => ex.exercise_id === exercise.id)}
                  >
                    <Plus className="w-4 h-4" />
                  </Button>
                </div>
              ))}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Selected Exercises */}
      {formData.prescribed_exercises.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>Prescribed Exercises ({formData.prescribed_exercises.length})</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {formData.prescribed_exercises.map((exercise) => (
                <div key={exercise.exercise_id} className="p-4 border rounded-lg">
                  <div className="flex items-center justify-between mb-3">
                    <h4 className="font-medium">{exercise.exercise_name}</h4>
                    <Button
                      type="button"
                      variant="ghost"
                      size="sm"
                      onClick={() => removeExercise(exercise.exercise_id)}
                      className="text-red-600 hover:bg-red-50"
                    >
                      <X className="w-4 h-4" />
                    </Button>
                  </div>
                  
                  <div className="grid md:grid-cols-4 gap-3">
                    <div>
                      <Label className="text-xs">Sets</Label>
                      <Input
                        type="number"
                        value={exercise.sets || ""}
                        onChange={(e) => updateExercise(exercise.exercise_id, 'sets', parseInt(e.target.value))}
                        className="h-8"
                      />
                    </div>
                    <div>
                      <Label className="text-xs">Repetitions</Label>
                      <Input
                        type="number"
                        value={exercise.repetitions || ""}
                        onChange={(e) => updateExercise(exercise.exercise_id, 'repetitions', parseInt(e.target.value))}
                        className="h-8"
                      />
                    </div>
                    <div>
                      <Label className="text-xs">Duration (min)</Label>
                      <Input
                        type="number"
                        value={exercise.duration_minutes || ""}
                        onChange={(e) => updateExercise(exercise.exercise_id, 'duration_minutes', parseInt(e.target.value))}
                        className="h-8"
                      />
                    </div>
                    <div>
                      <Label className="text-xs">Per Week</Label>
                      <Input
                        type="number"
                        value={exercise.frequency_per_week || ""}
                        onChange={(e) => updateExercise(exercise.exercise_id, 'frequency_per_week', parseInt(e.target.value))}
                        className="h-8"
                      />
                    </div>
                  </div>
                  
                  <div className="mt-3">
                    <Label className="text-xs">Special Instructions</Label>
                    <Textarea
                      value={exercise.special_instructions}
                      onChange={(e) => updateExercise(exercise.exercise_id, 'special_instructions', e.target.value)}
                      placeholder="Any specific instructions for this patient..."
                      rows={2}
                      className="text-sm"
                    />
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Additional Notes */}
      <Card>
        <CardHeader>
          <CardTitle>Additional Notes</CardTitle>
        </CardHeader>
        <CardContent>
          <Textarea
            placeholder="Any additional notes or instructions for the patient..."
            value={formData.notes}
            onChange={(e) => setFormData(prev => ({ ...prev, notes: e.target.value }))}
            rows={3}
          />
        </CardContent>
      </Card>

      {/* Form Actions */}
      <div className="flex justify-end gap-3">
        <Button type="button" variant="outline" onClick={onCancel}>
          Cancel
        </Button>
        <Button type="submit" className="bg-green-600 hover:bg-green-700">
          Create Prescription
        </Button>
      </div>
    </form>
  );
}
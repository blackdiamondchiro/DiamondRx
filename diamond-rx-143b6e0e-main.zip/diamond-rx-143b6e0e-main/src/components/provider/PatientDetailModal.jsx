import React, { useState, useEffect, useCallback } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { 
  TrendingDown, 
  TrendingUp, 
  Minus, 
  Calendar, 
  Activity, 
  Heart,
  Phone,
  Mail,
  CheckCircle,
  Clock
} from "lucide-react";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { format, subDays } from "date-fns";

export default function PatientDetailModal({ isOpen, onClose, patient }) {
  const [painHistory, setPainHistory] = useState([]);
  const [complaints, setComplaints] = useState([]);
  const [exerciseCompletions, setExerciseCompletions] = useState([]);
  const [loading, setLoading] = useState(false);

  const loadPatientData = useCallback(async () => {
    setLoading(true);
    try {
      // Mock comprehensive patient data for demonstration
      const mockComplaints = [
        {
          id: "comp_1",
          patient_id: patient?.id,
          body_area: "lower_back",
          status: "Active",
          created_date: subDays(new Date(), 30).toISOString()
        },
        {
          id: "comp_2", 
          patient_id: patient?.id,
          body_area: "neck",
          status: "Resolved",
          created_date: subDays(new Date(), 45).toISOString()
        }
      ];

      // Mock pain history with trends
      const mockPainHistory = Array.from({ length: 14 }, (_, i) => {
        const date = subDays(new Date(), 13 - i);
        const hasEntry = Math.random() > 0.3;
        
        if (!hasEntry) return null;
        
        return {
          date: format(date, 'MMM d'),
          fullDate: date.toISOString(),
          lower_back: Math.max(1, Math.floor(Math.random() * 8) + 2 - (i * 0.1)),
          neck: i < 7 ? Math.max(1, Math.floor(Math.random() * 6) + 2) : null
        };
      }).filter(Boolean);

      // Mock exercise completions
      const mockExerciseCompletions = [
        {
          id: "ex_1",
          exercise_name: "Lower Back Stretches",
          completed_date: new Date().toISOString(),
          pain_before: 7,
          pain_after: 4,
          helpful_rating: 5
        },
        {
          id: "ex_2", 
          exercise_name: "Neck Rolls",
          completed_date: subDays(new Date(), 1).toISOString(),
          pain_before: 5,
          pain_after: 3,
          helpful_rating: 4
        },
        {
          id: "ex_3",
          exercise_name: "Back Strengthening",
          completed_date: subDays(new Date(), 2).toISOString(),
          pain_before: 6,
          pain_after: 3,
          helpful_rating: 5
        }
      ];

      setComplaints(mockComplaints);
      setPainHistory(mockPainHistory);
      setExerciseCompletions(mockExerciseCompletions);
    } catch (error) {
      console.error("Error loading patient data:", error);
    } finally {
      setLoading(false);
    }
  }, [patient?.id]);

  useEffect(() => {
    if (isOpen && patient) {
      loadPatientData();
    }
  }, [isOpen, patient, loadPatientData]);

  const getOverallTrend = () => {
    if (painHistory.length < 2) return "stable";
    
    const recentEntries = painHistory.slice(-5);
    const olderEntries = painHistory.slice(0, 5);
    
    const calculateAvg = (entries) => {
      const total = entries.reduce((sum, entry) => {
        const painLevels = Object.values(entry).filter(val => typeof val === 'number');
        return sum + (painLevels.length > 0 ? painLevels.reduce((a, b) => a + b, 0) / painLevels.length : 0);
      }, 0);
      return total / entries.length;
    };

    const recentAvg = calculateAvg(recentEntries);
    const olderAvg = calculateAvg(olderEntries);

    if (recentAvg < olderAvg - 0.5) return "improving";
    if (recentAvg > olderAvg + 0.5) return "worsening";
    return "stable";
  };

  const getCurrentPainLevel = () => {
    if (painHistory.length === 0) return 0;
    const latestEntry = painHistory[painHistory.length - 1];
    const activeComplaintAreas = complaints
      .filter(c => c.status === 'Active')
      .map(c => c.body_area);

    const painValues = activeComplaintAreas
      .map(area => latestEntry[area])
      .filter(val => typeof val === 'number');

    if (painValues.length === 0) {
      const allPainValues = Object.values(latestEntry).filter(val => typeof val === 'number');
      return allPainValues.length > 0 ? (allPainValues.reduce((a, b) => a + b, 0) / allPainValues.length).toFixed(0) : 0;
    }
    
    return (painValues.reduce((a, b) => a + b, 0) / painValues.length).toFixed(0);
  };

  const getExerciseCompletionRate = () => {
    const expectedExercises = 5;
    if (exerciseCompletions.length === 0) return 0;
    const rate = (exerciseCompletions.length / expectedExercises) * 100;
    return Math.min(100, rate).toFixed(0);
  };

  const getTrendIcon = (trend) => {
    switch (trend) {
      case "improving": return <TrendingDown className="w-5 h-5 text-green-600" />;
      case "worsening": return <TrendingUp className="w-5 h-5 text-red-600" />;
      default: return <Minus className="w-5 h-5 text-yellow-600" />;
    }
  };

  const getTrendColor = (trend) => {
    switch (trend) {
      case "improving": return "text-green-600";
      case "worsening": return "text-red-600";
      default: return "text-yellow-600";
    }
  };

  const getComplaintColors = () => {
    const colors = {
      lower_back: "#ef4444",
      neck: "#3b82f6",
      shoulder: "#8b5cf6",
      knee: "#10b981",
    };
    return complaints.filter(c => c.status === 'Active').map(c => colors[c.body_area] || "#6b7280");
  };

  if (!patient) return null;

  const trend = getOverallTrend();
  const currentPainLevel = getCurrentPainLevel();
  const activeComplaints = complaints.filter(c => c.status === 'Active');
  const completionRate = getExerciseCompletionRate();

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-6xl max-h-[95vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex flex-col sm:flex-row sm:items-center sm:justify-between space-y-2 sm:space-y-0">
            <div className="flex items-baseline flex-wrap">
              <span className="text-xl font-bold">{patient.full_name}</span>
              <span className="text-sm text-gray-500 ml-0 sm:ml-3 break-all">{patient.email}</span>
            </div>
            <Badge variant={currentPainLevel >= 7 ? "destructive" : currentPainLevel >= 4 ? "secondary" : "default"}>
              Current Pain: {currentPainLevel}/10
            </Badge>
          </DialogTitle>
        </DialogHeader>

        {/* Quick Action Toolbar */}
        <Card className="mb-6 border-blue-200 bg-blue-50">
          <CardContent className="p-4">
            <div className="flex flex-wrap gap-3">
              <Button 
                size="sm" 
                className="bg-blue-600 hover:bg-blue-700"
                onClick={() => window.location.href = `mailto:${patient.email}?subject=Follow-up on your treatment progress&body=Hi ${patient.full_name.split(' ')[0]}, I wanted to check in on your progress...`}
              >
                <Mail className="w-4 h-4 mr-2" />
                Send Email
              </Button>
              <Button 
                size="sm" 
                variant="outline"
                onClick={() => window.location.href = `tel:${patient.phone || patient.email}`}
              >
                <Phone className="w-4 h-4 mr-2" />
                Call Patient
              </Button>
              <Button 
                size="sm" 
                variant="outline"
                className="bg-green-50 border-green-200 text-green-700 hover:bg-green-100"
              >
                <Heart className="w-4 h-4 mr-2" />
                Create Prescription
              </Button>
              <Button 
                size="sm" 
                variant="outline"
                className="bg-purple-50 border-purple-200 text-purple-700 hover:bg-purple-100"
              >
                <Calendar className="w-4 h-4 mr-2" />
                Schedule Appointment
              </Button>
              <Button 
                size="sm" 
                variant="outline"
              >
                <Activity className="w-4 h-4 mr-2" />
                Add Note
              </Button>
            </div>
          </CardContent>
        </Card>

        {loading ? (
          <div className="flex items-center justify-center py-12">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-green-600"></div>
            <span className="ml-3 text-gray-600">Loading patient data...</span>
          </div>
        ) : (
          <div className="space-y-6">
            {/* Patient Overview Cards */}
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
              <Card>
                <CardContent className="p-4 text-center">
                  <div className="text-2xl font-bold text-gray-900">{currentPainLevel}/10</div>
                  <p className="text-sm text-gray-600">Current Pain</p>
                  <div className="flex items-center justify-center mt-2">
                    {getTrendIcon(trend)}
                    <span className={`text-sm ml-1 ${getTrendColor(trend)}`}>
                      {trend}
                    </span>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-4 text-center">
                  <div className="text-2xl font-bold text-gray-900">{activeComplaints.length}</div>
                  <p className="text-sm text-gray-600">Active Complaints</p>
                  <div className="mt-2">
                    {activeComplaints.length > 0 ? (
                      <Badge variant="destructive" className="text-xs">Needs Attention</Badge>
                    ) : (
                      <Badge variant="default" className="text-xs">All Clear</Badge>
                    )}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-4 text-center">
                  <div className="text-2xl font-bold text-gray-900">{exerciseCompletions.length}</div>
                  <p className="text-sm text-gray-600">Exercises Done</p>
                  <div className="mt-2">
                    <Badge variant="default" className="text-xs">Last 14 Days</Badge>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-4 text-center">
                  <div className="text-2xl font-bold text-gray-900">{completionRate}%</div>
                  <p className="text-sm text-gray-600">Compliance Rate</p>
                  <div className="mt-2">
                    <Badge variant={completionRate >= 80 ? "default" : completionRate >= 60 ? "secondary" : "destructive"} className="text-xs">
                      {completionRate >= 80 ? "Excellent" : completionRate >= 60 ? "Good" : "Needs Improvement"}
                    </Badge>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Pain Tracking Chart */}
            <Card>
              <CardHeader>
                <CardTitle>Pain Levels Over Time (Last 14 Days)</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-64">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={painHistory}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="date" />
                      <YAxis domain={[0, 10]} />
                      <Tooltip 
                        formatter={(value, name) => [
                          `${value}/10`, 
                          name.replace('_', ' ').replace(/\b\w/g, l => l.toUpperCase())
                        ]}
                      />
                      {activeComplaints.length > 0 && activeComplaints.map((complaint, index) => (
                        <Line
                          key={complaint.body_area}
                          type="monotone"
                          dataKey={complaint.body_area}
                          stroke={getComplaintColors()[index]}
                          strokeWidth={2}
                          connectNulls={false}
                          dot={{ fill: getComplaintColors()[index], strokeWidth: 2, r: 4 }}
                          name={complaint.body_area.replace('_', ' ').replace(/\b\w/g, l => l.toUpperCase())}
                        />
                      ))}
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>

            {/* Two Column Layout */}
            <div className="grid lg:grid-cols-2 gap-6">
              {/* Active Complaints */}
              <Card>
                <CardHeader>
                  <CardTitle>Active Complaints</CardTitle>
                </CardHeader>
                <CardContent>
                  {activeComplaints.length > 0 ? (
                    <div className="space-y-3">
                      {activeComplaints.map(complaint => (
                        <div key={complaint.id} className="p-3 bg-gray-50 rounded-lg">
                          <div className="flex justify-between items-center">
                            <span className="font-medium capitalize">
                              {complaint.body_area.replace('_', ' ')}
                            </span>
                            <Badge variant="destructive">Active</Badge>
                          </div>
                          <p className="text-sm text-gray-600 mt-1">
                            Started: {format(new Date(complaint.created_date), 'MMM d, yyyy')}
                          </p>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-8">
                      <CheckCircle className="w-12 h-12 text-green-600 mx-auto mb-3" />
                      <p className="text-green-700 font-medium">No Active Complaints</p>
                      <p className="text-sm text-green-600">Patient is doing well!</p>
                    </div>
                  )}
                </CardContent>
              </Card>

              {/* Recent Exercise Activity */}
              <Card>
                <CardHeader>
                  <CardTitle>Recent Exercise Activity</CardTitle>
                </CardHeader>
                <CardContent>
                  {exerciseCompletions.length > 0 ? (
                    <div className="space-y-3">
                      {exerciseCompletions.slice(0, 5).map(completion => (
                        <div key={completion.id} className="p-3 bg-gray-50 rounded-lg">
                          <div className="flex justify-between items-start">
                            <div>
                              <p className="font-medium">{completion.exercise_name}</p>
                              <p className="text-sm text-gray-600">
                                {format(new Date(completion.completed_date), 'MMM d, h:mm a')}
                              </p>
                            </div>
                            <div className="text-right">
                              <div className="text-sm">
                                <span className="text-red-600">{completion.pain_before}</span>
                                <span className="text-gray-400 mx-1">→</span>
                                <span className="text-green-600">{completion.pain_after}</span>
                              </div>
                              <div className="flex items-center mt-1">
                                {Array.from({ length: completion.helpful_rating }).map((_, i) => (
                                  <span key={i} className="text-yellow-400">★</span>
                                ))}
                              </div>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-8">
                      <Clock className="w-12 h-12 text-gray-300 mx-auto mb-3" />
                      <p className="text-gray-500">No recent exercise activity</p>
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}
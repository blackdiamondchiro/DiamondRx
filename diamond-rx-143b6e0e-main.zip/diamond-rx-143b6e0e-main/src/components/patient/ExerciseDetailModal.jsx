
import React from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { 
  Play, 
  Clock, 
  RotateCcw, 
  Hash,
  Calendar,
  Star, 
  CheckCircle,
  X
} from "lucide-react";

const difficultyColors = {
  beginner: "bg-green-100 text-green-800 border-green-200",
  intermediate: "bg-yellow-100 text-yellow-800 border-yellow-200",
  advanced: "bg-red-100 text-red-800 border-red-200"
};

export default function ExerciseDetailModal({ exercise, isOpen, onClose, onComplete, completions }) {
  const [showCompletionForm, setShowCompletionForm] = React.useState(false);
  const [completionData, setCompletionData] = React.useState({
    helpful_rating: 5,
    pain_before: 0,
    pain_after: 0,
    notes: ""
  });

  const handleComplete = async () => {
    await onComplete(exercise.id, completionData);
    setShowCompletionForm(false);
    setCompletionData({
      helpful_rating: 5,
      pain_before: 0,
      pain_after: 0,
      notes: ""
    });
    onClose();
  };

  if (!exercise) return null;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <div className="flex justify-between items-start">
            <div>
              <DialogTitle className="text-2xl font-bold text-gray-900 mb-2">
                {exercise.name}
              </DialogTitle>
              <div className="flex gap-2">
                <Badge className={difficultyColors[exercise.difficulty]} variant="outline">
                  {exercise.difficulty}
                </Badge>
                {exercise.video_url && (
                  <Badge variant="outline" className="bg-purple-100 text-purple-800 border-purple-200">
                    <Play className="w-3 h-3 mr-1" />
                    Video Available
                  </Badge>
                )}
                {completions.length > 0 && (
                  <Badge className="bg-green-100 text-green-800 border-green-200">
                    <CheckCircle className="w-3 h-3 mr-1" />
                    Completed {completions.length} time{completions.length > 1 ? 's' : ''}
                  </Badge>
                )}
              </div>
            </div>
          </div>
        </DialogHeader>

        <div className="space-y-6">
          {/* Exercise Overview */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 p-4 bg-gray-50 rounded-lg">
            <div className="text-center">
              <Clock className="w-6 h-6 text-blue-600 mx-auto mb-2" />
              <div className="font-semibold">{exercise.duration_minutes || 'N/A'}</div>
              <div className="text-sm text-gray-600">Minutes</div>
            </div>
            <div className="text-center">
              <RotateCcw className="w-6 h-6 text-green-600 mx-auto mb-2" />
              <div className="font-semibold">{exercise.repetitions || 'N/A'}</div>
              <div className="text-sm text-gray-600">Repetitions</div>
            </div>
            <div className="text-center">
              <Hash className="w-6 h-6 text-purple-600 mx-auto mb-2" />
              <div className="font-semibold">{exercise.sets || 'N/A'}</div>
              <div className="text-sm text-gray-600">Sets</div>
            </div>
            <div className="text-center">
              <Calendar className="w-6 h-6 text-orange-600 mx-auto mb-2" />
              <div className="font-semibold">{exercise.days_per_week || 'N/A'}x</div>
              <div className="text-sm text-gray-600">Per Week</div>
            </div>
          </div>

          {/* Rating Display */}
          <div className="text-center p-4 bg-yellow-50 rounded-lg">
            <Star className="w-6 h-6 text-yellow-500 mx-auto mb-2" />
            <div className="font-semibold">
              {completions.length > 0 
                ? (completions.reduce((sum, c) => sum + (c.helpful_rating || 0), 0) / completions.length).toFixed(1)
                : 'Not Rated Yet'
              }
            </div>
            <div className="text-sm text-gray-600">Your Average Rating</div>
          </div>

          {/* Description */}
          {exercise.description && (
            <div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">Description</h3>
              <p className="text-gray-700">{exercise.description}</p>
            </div>
          )}

          {/* Instructions */}
          {exercise.instructions && (
            <div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">Instructions</h3>
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                <pre className="whitespace-pre-wrap text-gray-800 font-medium">
                  {exercise.instructions}
                </pre>
              </div>
            </div>
          )}

          {/* Target Areas */}
          <div>
            <h3 className="text-lg font-semibold text-gray-900 mb-2">Target Body Areas</h3>
            <div className="flex flex-wrap gap-2">
              {exercise.body_areas?.map((area, index) => (
                <Badge key={index} variant="secondary">
                  {area.replace('_', ' ').replace(/\b\w/g, l => l.toUpperCase())}
                </Badge>
              ))}
            </div>
          </div>

          {/* Notes */}
          {exercise.notes && (
            <div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">Important Notes</h3>
              <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
                <p className="text-yellow-800">{exercise.notes}</p>
              </div>
            </div>
          )}

          {/* Video */}
          {exercise.video_url && (
            <div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">Video Demonstration</h3>
              <Button
                className="w-full bg-purple-600 hover:bg-purple-700"
                onClick={() => window.open(exercise.video_url, '_blank')}
              >
                <Play className="w-4 h-4 mr-2" />
                Watch Demonstration Video
              </Button>
            </div>
          )}

          {/* Recent Completions */}
          {completions.length > 0 && (
            <div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">Your Recent Activity</h3>
              <div className="space-y-2 max-h-32 overflow-y-auto">
                {completions.slice(0, 3).map((completion, index) => (
                  <div key={index} className="flex justify-between items-center p-2 bg-green-50 border border-green-200 rounded">
                    <span className="text-sm text-green-800">
                      Completed on {new Date(completion.created_date).toLocaleDateString()}
                    </span>
                    {completion.helpful_rating && (
                      <div className="flex items-center gap-1">
                        <Star className="w-3 h-3 text-yellow-500" />
                        <span className="text-sm">{completion.helpful_rating}/5</span>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Completion Form */}
          {showCompletionForm && (
            <div className="border-t pt-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Record Completion</h3>
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="pain_before">Pain Before (0-10)</Label>
                    <Input
                      id="pain_before"
                      type="number"
                      min="0"
                      max="10"
                      value={completionData.pain_before}
                      onChange={(e) => setCompletionData(prev => ({ ...prev, pain_before: parseInt(e.target.value) || 0 }))}
                    />
                  </div>
                  <div>
                    <Label htmlFor="pain_after">Pain After (0-10)</Label>
                    <Input
                      id="pain_after"
                      type="number"
                      min="0"
                      max="10"
                      value={completionData.pain_after}
                      onChange={(e) => setCompletionData(prev => ({ ...prev, pain_after: parseInt(e.target.value) || 0 }))}
                    />
                  </div>
                </div>
                
                <div>
                  <Label htmlFor="helpful_rating">How helpful was this exercise? (1-5)</Label>
                  <div className="flex gap-2 mt-2">
                    {[1, 2, 3, 4, 5].map(rating => (
                      <Button
                        key={rating}
                        type="button"
                        variant={completionData.helpful_rating === rating ? "default" : "outline"}
                        size="sm"
                        onClick={() => setCompletionData(prev => ({ ...prev, helpful_rating: rating }))}
                        className="w-12 h-12"
                      >
                        <Star className="w-4 h-4" />
                        <span className="ml-1">{rating}</span>
                      </Button>
                    ))}
                  </div>
                </div>

                <div>
                  <Label htmlFor="notes">Notes (optional)</Label>
                  <Textarea
                    id="notes"
                    value={completionData.notes}
                    onChange={(e) => setCompletionData(prev => ({ ...prev, notes: e.target.value }))}
                    placeholder="How did this exercise feel? Any difficulties or improvements?"
                    className="h-20"
                  />
                </div>
              </div>
            </div>
          )}

          {/* Action Buttons */}
          <div className="flex justify-end gap-3 pt-6 border-t">
            <Button variant="outline" onClick={onClose}>
              Close
            </Button>
            {!showCompletionForm ? (
              <Button 
                className="bg-green-600 hover:bg-green-700"
                onClick={() => setShowCompletionForm(true)}
              >
                <CheckCircle className="w-4 h-4 mr-2" />
                Mark as Complete
              </Button>
            ) : (
              <div className="flex gap-2">
                <Button 
                  variant="outline" 
                  onClick={() => setShowCompletionForm(false)}
                >
                  Cancel
                </Button>
                <Button 
                  className="bg-green-600 hover:bg-green-700"
                  onClick={handleComplete}
                >
                  Save Completion
                </Button>
              </div>
            )}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}

import React, { useState } from "react";
import { User } from "@/api/entities";
import { Complaint } from "@/api/entities";
import { PainLog } from "@/api/entities";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Bug, User as UserIcon, Database, TestTube } from "lucide-react";

export default function DebugPanel({ user }) {
  const [debugData, setDebugData] = useState(null);
  const [loading, setLoading] = useState(false);

  const runDebugQueries = async () => {
    if (!user) return;
    
    setLoading(true);
    try {
      const complaints = await Complaint.filter({ patient_id: user.id });
      const allPainLogs = [];
      
      for (const complaint of complaints) {
        const logs = await PainLog.filter({ complaint_id: complaint.id });
        allPainLogs.push(...logs);
      }

      setDebugData({
        complaints,
        painLogs: allPainLogs,
        timestamp: new Date().toISOString()
      });
    } catch (error) {
      console.error("Debug query failed:", error);
      setDebugData({ error: error.message });
    } finally {
      setLoading(false);
    }
  };

  const testCreateComplaint = async () => {
    if (!user || user.account_type !== 'patient') return;
    
    setLoading(true);
    try {
      const testComplaint = await Complaint.create({
        patient_id: user.id,
        body_area: "neck",
        status: "Active"
      });
      
      await PainLog.create({
        complaint_id: testComplaint.id,
        pain_level: 5,
        description: "Test pain entry from debug panel",
        frequency: "occasional"
      });
      
      alert(`Test complaint created: ${testComplaint.id}`);
      runDebugQueries();
    } catch (error) {
      alert(`Test failed: ${error.message}`);
    } finally {
      setLoading(false);
    }
  };

  if (!user) {
    return null;
  }

  // Only show in development
  if (window.location.hostname !== 'localhost' && !window.location.hostname.includes('dev')) {
    return null;
  }

  return (
    <Card className="fixed bottom-4 right-4 w-80 z-50 bg-yellow-50 border-yellow-200">
      <CardHeader className="pb-2">
        <CardTitle className="flex items-center gap-2 text-sm">
          <Bug className="w-4 h-4" />
          Debug Panel
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        <div className="text-xs space-y-1">
          <div className="flex items-center gap-2">
            <UserIcon className="w-3 h-3" />
            <span>User: {user.id}</span>
          </div>
          <div className="flex items-center gap-2">
            <Badge variant="outline" className="text-xs">
              {user.account_type}
            </Badge>
          </div>
        </div>
        
        <div className="flex gap-2">
          <Button
            size="sm"
            variant="outline"
            onClick={runDebugQueries}
            disabled={loading}
            className="text-xs"
          >
            <Database className="w-3 h-3 mr-1" />
            Query Data
          </Button>
          {user.account_type === 'patient' && (
            <Button
              size="sm"
              variant="outline"
              onClick={testCreateComplaint}
              disabled={loading}
              className="text-xs"
            >
              <TestTube className="w-3 h-3 mr-1" />
              Test Create
            </Button>
          )}
        </div>

        {debugData && (
          <div className="text-xs bg-white p-2 rounded border max-h-32 overflow-y-auto">
            {debugData.error ? (
              <p className="text-red-600">{debugData.error}</p>
            ) : (
              <div>
                <p><strong>Complaints:</strong> {debugData.complaints?.length || 0}</p>
                <p><strong>Pain Logs:</strong> {debugData.painLogs?.length || 0}</p>
                <p><strong>Queried:</strong> {debugData.timestamp}</p>
              </div>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
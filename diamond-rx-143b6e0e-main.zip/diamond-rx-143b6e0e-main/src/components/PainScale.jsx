import React from "react";
import { Button } from "@/components/ui/button";

const painDescriptions = {
  0: { text: "No Pain", color: "bg-green-500" },
  1: { text: "Very Mild", color: "bg-green-400" },
  2: { text: "Mild", color: "bg-yellow-400" },
  3: { text: "Moderate", color: "bg-yellow-500" },
  4: { text: "Moderate", color: "bg-yellow-600" },
  5: { text: "Moderate", color: "bg-orange-400" },
  6: { text: "Moderately Severe", color: "bg-orange-500" },
  7: { text: "Severe", color: "bg-red-400" },
  8: { text: "Very Severe", color: "bg-red-500" },
  9: { text: "Extremely Severe", color: "bg-red-600" },
  10: { text: "Worst Possible", color: "bg-red-700" }
};

export default function PainScale({ value, onChange }) {
  return (
    <div className="space-y-4">
      {/* Visual Scale */}
      <div className="flex items-center gap-1 p-4 bg-gray-50 rounded-lg">
        {Array.from({ length: 11 }, (_, i) => (
          <div
            key={i}
            className="flex-1 flex flex-col items-center cursor-pointer"
            onClick={() => onChange(i)}
          >
            <div
              className={`w-8 h-8 rounded-full border-2 transition-all duration-200 ${
                value === i
                  ? `${painDescriptions[i].color} border-gray-800 scale-110`
                  : 'bg-gray-200 border-gray-300 hover:scale-105'
              }`}
            />
            <span className={`text-sm font-medium mt-1 ${value === i ? 'text-gray-900' : 'text-gray-600'}`}>
              {i}
            </span>
          </div>
        ))}
      </div>

      {/* Current Selection Display */}
      <div className="text-center">
        <div className={`inline-flex items-center gap-3 px-6 py-3 rounded-lg ${
          value > 0 ? painDescriptions[value].color : 'bg-gray-200'
        }`}>
          <span className="text-2xl font-bold text-white">
            {value}
          </span>
          <div className="text-white">
            <p className="font-semibold">{painDescriptions[value].text}</p>
            <p className="text-sm opacity-90">
              {value === 0 && "No discomfort"}
              {value >= 1 && value <= 3 && "Doesn't interfere with activities"}
              {value >= 4 && value <= 6 && "Interferes with activities"}
              {value >= 7 && value <= 10 && "Disabling pain"}
            </p>
          </div>
        </div>
      </div>

      {/* Quick Selection Buttons */}
      <div className="grid grid-cols-6 gap-2">
        {[0, 2, 4, 6, 8, 10].map(level => (
          <Button
            key={level}
            variant={value === level ? "default" : "outline"}
            size="sm"
            onClick={() => onChange(level)}
            className="flex flex-col h-auto py-2"
          >
            <span className="font-bold">{level}</span>
            <span className="text-xs">{painDescriptions[level].text}</span>
          </Button>
        ))}
      </div>
    </div>
  );
}
import React from "react";
import { Button } from "@/components/ui/button";
import { Card, CardDescription } from "@/components/ui/card";
import { format } from "date-fns";
import { User } from "@/api/entities";

export default function AccountSecurity({ user }) {

  const handleDeleteAccount = () => {
    if(window.confirm("Are you sure you want to delete your account? This action is irreversible.")) {
       if(window.confirm("Please confirm again. This will permanently delete all your data.")) {
            alert("Account deletion is a placeholder action in this demo.");
            // In a real app, you would call a backend function to handle this.
            // Example: await User.deleteMyAccount();
       }
    }
  }

  return (
    <div className="space-y-6">
       <div>
        <h3 className="font-medium text-gray-800">Account Details</h3>
        <p className="text-sm text-gray-600">
          Account Type: <span className="font-semibold capitalize">{user.account_type}</span>
        </p>
         <p className="text-sm text-gray-600">
          Member since: <span className="font-semibold">{format(new Date(user.created_date), "MMMM d, yyyy")}</span>
        </p>
      </div>
       <Card className="border-red-200 bg-red-50 p-6">
        <h3 className="font-semibold text-red-900">Delete Account</h3>
        <CardDescription className="text-red-700 mb-4">
          Permanently delete your account and all associated data. This action is irreversible.
        </CardDescription>
        <Button variant="destructive" onClick={handleDeleteAccount}>
          Delete My Account
        </Button>
      </Card>
    </div>
  );
}
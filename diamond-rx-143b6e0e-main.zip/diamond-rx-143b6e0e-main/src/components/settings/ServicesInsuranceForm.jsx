import React from "react";
import { User } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Save, AlertTriangle, CheckCircle } from "lucide-react";

export default function ServicesInsuranceForm({ user, onUpdate }) {
  const [formData, setFormData] = React.useState({
    services: user?.services?.join('\n') || "",
    insurance_acceptance: user?.insurance_acceptance || "no",
    accepted_insurance_providers: user?.accepted_insurance_providers?.join('\n') || "",
  });
  const [loading, setLoading] = React.useState(false);
  const [error, setError] = React.useState("");
  const [success, setSuccess] = React.useState("");

  React.useEffect(() => {
    if (user) {
      setFormData({
        services: user.services?.join('\n') || "",
        insurance_acceptance: user.insurance_acceptance || "no",
        accepted_insurance_providers: user.accepted_insurance_providers?.join('\n') || "",
      });
    }
  }, [user]);

  const handleSave = async (e) => {
    e.preventDefault();
    setError("");
    setSuccess("");
    setLoading(true);

    try {
      const servicesArray = formData.services.split('\n').map(s => s.trim()).filter(Boolean);
      const insuranceProvidersArray = formData.accepted_insurance_providers.split('\n').map(s => s.trim()).filter(Boolean);

      await User.updateMyUserData({
        services: servicesArray,
        insurance_acceptance: formData.insurance_acceptance,
        accepted_insurance_providers: formData.insurance_acceptance === 'yes' ? insuranceProvidersArray : [],
      });
      setSuccess("Services and insurance information updated successfully!");
      onUpdate();
    } catch (err) {
      setError("Failed to update information. Please try again.");
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <form onSubmit={handleSave} className="space-y-6">
      <div className="space-y-4">
        <div>
          <Label htmlFor="services">Services Offered</Label>
          <Textarea
            id="services"
            value={formData.services}
            onChange={(e) => setFormData({ ...formData, services: e.target.value })}
            placeholder="e.g., Manual Adjustments&#10;Active Release Technique&#10;Spinal Decompression"
            className="h-32"
          />
          <p className="text-xs text-gray-500 mt-1">Enter one service per line.</p>
        </div>

        <div>
          <Label>Do you accept insurance?</Label>
          <RadioGroup
            value={formData.insurance_acceptance}
            onValueChange={(value) => setFormData({ ...formData, insurance_acceptance: value })}
            className="mt-2"
          >
            <div className="flex items-center space-x-2">
              <RadioGroupItem value="yes" id="ins-yes" />
              <Label htmlFor="ins-yes">Yes, I am in-network with some providers</Label>
            </div>
            <div className="flex items-center space-x-2">
              <RadioGroupItem value="out_of_network" id="ins-out" />
              <Label htmlFor="ins-out">I am an out-of-network provider</Label>
            </div>
             <div className="flex items-center space-x-2">
              <RadioGroupItem value="no" id="ins-no" />
              <Label htmlFor="ins-no">No, I do not accept insurance (self-pay only)</Label>
            </div>
          </RadioGroup>
        </div>

        {formData.insurance_acceptance === 'yes' && (
          <div>
            <Label htmlFor="accepted_insurance_providers">Accepted Insurance Providers</Label>
            <Textarea
              id="accepted_insurance_providers"
              value={formData.accepted_insurance_providers}
              onChange={(e) => setFormData({ ...formData, accepted_insurance_providers: e.target.value })}
              placeholder="e.g., Blue Cross Blue Shield&#10;Aetna&#10;Cigna"
              className="h-32"
            />
            <p className="text-xs text-gray-500 mt-1">Enter one provider per line.</p>
          </div>
        )}
      </div>

      {error && (
        <div className="p-3 bg-red-50 border border-red-200 rounded-lg flex items-center gap-2">
          <AlertTriangle className="w-5 h-5 text-red-600" />
          <p className="text-red-700 text-sm">{error}</p>
        </div>
      )}

      {success && (
        <div className="p-3 bg-green-50 border-green-200 rounded-lg flex items-center gap-2">
          <CheckCircle className="w-5 h-5 text-green-600" />
          <p className="text-green-700 text-sm">{success}</p>
        </div>
      )}

      <div className="flex justify-end">
        <Button type="submit" disabled={loading} className="bg-blue-600 hover:bg-blue-700">
          <Save className="w-4 h-4 mr-2" />
          {loading ? "Saving..." : "Save Services & Insurance"}
        </Button>
      </div>
    </form>
  );
}
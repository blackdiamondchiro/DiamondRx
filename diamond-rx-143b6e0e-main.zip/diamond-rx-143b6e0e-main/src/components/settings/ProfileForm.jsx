
import React from "react";
import { User } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Save, AlertTriangle, CheckCircle } from "lucide-react";

export default function ProfileForm({ user, onUpdate }) {
  const [formData, setFormData] = React.useState({
    full_name: user?.full_name || "",
    email: user?.email || "",
    phone: user?.phone || "",
  });
  const [loading, setLoading] = React.useState(false);
  const [error, setError] = React.useState("");
  const [success, setSuccess] = React.useState("");

  const validateEmail = (email) => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  }

  const validatePhone = (phone) => {
    if (!phone) return true; // Phone is optional
    const phoneRegex = /^\(?([0-9]{3})\)?[-. ]?([0-9]{3})\s*[-. ]?([0-9]{4})$/;
    return phoneRegex.test(phone);
  };

  const validateFullName = (name) => {
    // Full name should be at least 2 characters and contain letters
    return name && name.trim().length >= 2 && /^[a-zA-Z\s.,-]+$/.test(name.trim());
  };

  const handleSave = async (e) => {
    e.preventDefault();
    setError("");
    setSuccess("");

    if (!validateFullName(formData.full_name)) {
      setError("Please enter a valid full name (letters, spaces, and common punctuation only).");
      return;
    }

    if (!validateEmail(formData.email)) {
      setError("Please enter a valid email address.");
      return;
    }

    if (!validatePhone(formData.phone)) {
      setError("Please enter a valid phone number format (e.g., (123) 456-7890).");
      return;
    }

    setLoading(true);
    try {
      await User.updateMyUserData({
        full_name: formData.full_name.trim(),
        email: formData.email,
        phone: formData.phone
      });
      setSuccess("Profile updated successfully!");
      onUpdate(); // Notify parent to refresh user data
    } catch (err) {
      if (err.message && err.message.includes('already in use')) {
        setError("This email address is already in use by another account.");
      } else {
        setError("Failed to update profile. Please try again.");
      }
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <form onSubmit={handleSave} className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div>
          <Label htmlFor="full_name">Full Name *</Label>
          <Input
            id="full_name"
            value={formData.full_name}
            onChange={(e) => setFormData({ ...formData, full_name: e.target.value })}
            placeholder="Your full name"
            required
          />
        </div>
        <div>
          <Label htmlFor="email">Email Address *</Label>
          <Input
            id="email"
            type="email"
            value={formData.email}
            onChange={(e) => setFormData({ ...formData, email: e.target.value })}
            placeholder="your.email@example.com"
            required
          />
           <p className="text-xs text-gray-500 mt-1">This is the email you use to log in.</p>
        </div>
        <div>
          <Label htmlFor="phone">Phone Number (Optional)</Label>
          <Input
            id="phone"
            value={formData.phone}
            onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
            placeholder="(123) 456-7890"
          />
        </div>
      </div>

      {error && (
        <div className="p-3 bg-red-50 border border-red-200 rounded-lg flex items-center gap-2">
          <AlertTriangle className="w-5 h-5 text-red-600" />
          <p className="text-red-700 text-sm">{error}</p>
        </div>
      )}

      {success && (
        <div className="p-3 bg-green-50 border border-green-200 rounded-lg flex items-center gap-2">
          <CheckCircle className="w-5 h-5 text-green-600" />
          <p className="text-green-700 text-sm">{success}</p>
        </div>
      )}

      <div className="flex justify-end">
        <Button type="submit" disabled={loading} className="bg-blue-600 hover:bg-blue-700">
          <Save className="w-4 h-4 mr-2" />
          {loading ? "Saving..." : "Save Changes"}
        </Button>
      </div>
    </form>
  );
}

import React from "react";
import { User } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Save, AlertTriangle, CheckCircle } from "lucide-react";

export default function WorkLocationForm({ user, onUpdate }) {
  const [formData, setFormData] = React.useState({
    practice_name: user?.practice_name || "",
    address: user?.work_location?.address || "",
    city: user?.work_location?.city || "",
    state: user?.work_location?.state || "",
    zip: user?.work_location?.zip || "",
    phone: user?.work_location?.phone || "",
    email: user?.work_location?.email || "",
    website: user?.work_location?.website || "",
    hours: user?.work_location?.hours || "",
  });
  const [loading, setLoading] = React.useState(false);
  const [error, setError] = React.useState("");
  const [success, setSuccess] = React.useState("");

  const handleSave = async (e) => {
    e.preventDefault();
    setError("");
    setSuccess("");

    setLoading(true);
    try {
      await User.updateMyUserData({
        practice_name: formData.practice_name,
        work_location: {
          address: formData.address,
          city: formData.city,
          state: formData.state,
          zip: formData.zip,
          phone: formData.phone,
          email: formData.email,
          website: formData.website,
          hours: formData.hours,
        },
      });
      setSuccess("Your provider profile has been updated successfully.");
      onUpdate();
    } catch (err) {
      setError("Failed to update work location. Please try again.");
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <form onSubmit={handleSave} className="space-y-6">
      <div className="space-y-4">
        <div>
          <Label htmlFor="practice_name">Practice/Clinic Name</Label>
          <Input
            id="practice_name"
            value={formData.practice_name}
            onChange={(e) => setFormData({ ...formData, practice_name: e.target.value })}
            placeholder="e.g., Smith Physical Therapy"
          />
        </div>
        
        <div>
          <Label htmlFor="work_address">Office Street Address</Label>
          <Input
            id="work_address"
            value={formData.address}
            onChange={(e) => setFormData({ ...formData, address: e.target.value })}
            placeholder="123 Wellness Ave"
          />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div>
            <Label htmlFor="work_city">City</Label>
            <Input
              id="work_city"
              value={formData.city}
              onChange={(e) => setFormData({ ...formData, city: e.target.value })}
              placeholder="Healthville"
            />
          </div>
          <div>
            <Label htmlFor="work_state">State</Label>
            <Input
              id="work_state"
              value={formData.state}
              onChange={(e) => setFormData({ ...formData, state: e.target.value })}
              placeholder="CA"
            />
          </div>
          <div>
            <Label htmlFor="work_zip">Zip Code</Label>
            <Input
              id="work_zip"
              value={formData.zip}
              onChange={(e) => setFormData({ ...formData, zip: e.target.value })}
              placeholder="90210"
            />
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <Label htmlFor="work_phone">Office Phone</Label>
            <Input
              id="work_phone"
              type="tel"
              value={formData.phone}
              onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
              placeholder="(555) 123-4567"
            />
          </div>
          <div>
            <Label htmlFor="work_email">Office Email</Label>
            <Input
              id="work_email"
              type="email"
              value={formData.email}
              onChange={(e) => setFormData({ ...formData, email: e.target.value })}
              placeholder="contact@smithpt.com"
            />
          </div>
        </div>

        <div>
          <Label htmlFor="website">Website (Optional)</Label>
          <Input
            id="website"
            value={formData.website}
            onChange={(e) => setFormData({ ...formData, website: e.target.value })}
            placeholder="https://www.smithpt.com"
          />
        </div>

        <div>
          <Label htmlFor="hours">Hours of Operation (Optional)</Label>
          <Textarea
            id="hours"
            value={formData.hours}
            onChange={(e) => setFormData({ ...formData, hours: e.target.value })}
            placeholder="e.g., Mon-Fri: 9am - 5pm"
            className="h-24"
          />
        </div>
      </div>
      
      {error && (
        <div className="p-3 bg-red-50 border border-red-200 rounded-lg flex items-center gap-2">
          <AlertTriangle className="w-5 h-5 text-red-600" />
          <p className="text-red-700 text-sm">{error}</p>
        </div>
      )}

      {success && (
        <div className="p-3 bg-green-50 border border-green-200 rounded-lg flex items-center gap-2">
          <CheckCircle className="w-5 h-5 text-green-600" />
          <p className="text-green-700 text-sm">{success}</p>
        </div>
      )}

      <div className="flex justify-end">
        <Button type="submit" disabled={loading} className="bg-green-600 hover:bg-green-700">
          <Save className="w-4 h-4 mr-2" />
          {loading ? "Saving..." : "Save Work Location"}
        </Button>
      </div>
    </form>
  );
}

import React from "react";
import { User } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Link, UserCheck, UserX, Building, Mail, Phone, Globe, Stethoscope } from "lucide-react";
import { createPageUrl } from "@/utils";
import { useNavigate } from "react-router-dom";

export default function ProviderLink({ user, onUpdate }) {
  const navigate = useNavigate();
  const [provider, setProvider] = React.useState(null);

  React.useEffect(() => {
    const fetchProvider = async () => {
      if (user?.provider_id) {
        // In a real app: const providerData = await User.get(user.provider_id);
        // Using mock data for demonstration
        const mockProvider = {
          id: "provider1",
          full_name: "Dr. Emily Carter",
          credentials: "DPT",
          specialization: "Physical Therapy",
          practice_name: "HealWell Physical Therapy",
          work_location: {
            address: "123 Wellness Ave, Healthville, CA 90210",
            phone: "(555) 123-4567",
            email: "contact@healwellpt.com",
            website: "https://www.healwellpt.com"
          }
        };
        if (mockProvider.id === user.provider_id) {
           setProvider(mockProvider);
        }
      }
    };
    fetchProvider();
  }, [user]);

  const handleUnlink = async () => {
    if (window.confirm("Are you sure you want to unlink from your provider? This will remove their access to your pain data.")) {
      try {
        await User.updateMyUserData({ provider_id: null });
        alert("Successfully unlinked from provider.");
        onUpdate();
      } catch (error) {
        console.error("Failed to unlink from provider:", error);
        alert("An error occurred. Please try again.");
      }
    }
  };

  return (
    <Card className="shadow-lg">
      <CardHeader>
        <CardTitle className="flex items-center gap-3">
          <UserCheck className="w-5 h-5 text-purple-600" />
          <span>Linked Healthcare Provider</span>
        </CardTitle>
      </CardHeader>
      <CardContent>
        {provider ? (
          <div className="space-y-4">
            <h3 className="text-xl font-bold">
              {provider.full_name}{provider.credentials ? `, ${provider.credentials}` : ''}
            </h3>
            <p className="font-medium text-purple-700 flex items-center gap-2">
              <Stethoscope className="w-4 h-4"/>
              {provider.specialization}
            </p>
            
            <div className="p-4 bg-gray-50 rounded-lg space-y-2">
              <div className="flex items-center gap-3"><Building className="w-4 h-4 text-gray-500" /><span>{provider.practice_name}</span></div>
              <div className="flex items-center gap-3"><Mail className="w-4 h-4 text-gray-500" /><span>{provider.work_location.email}</span></div>
              <div className="flex items-center gap-3"><Phone className="w-4 h-4 text-gray-500" /><span>{provider.work_location.phone}</span></div>
              {provider.work_location.website && (
                 <div className="flex items-center gap-3"><Globe className="w-4 h-4 text-gray-500" />
                    <a href={provider.work_location.website} target="_blank" rel="noopener noreferrer" className="text-blue-600 hover:underline">
                      Visit Website
                    </a>
                 </div>
              )}
            </div>

            <Button onClick={handleUnlink} variant="destructive" className="w-full">
              <UserX className="w-4 h-4 mr-2" />
              Unlink from Provider
            </Button>
          </div>
        ) : (
          <div>
            <CardDescription className="mb-4">
              You are not linked to a healthcare provider. Linking allows your provider to see your pain entries and recommend exercises.
            </CardDescription>
            <Button onClick={() => navigate(createPageUrl("FindProviders"))} className="w-full bg-purple-600 hover:bg-purple-700">
              <Link className="w-4 h-4 mr-2" />
              Find and Link to a Provider
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

import React from "react";
import { User } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Save, AlertTriangle, CheckCircle } from "lucide-react";

export default function AddressForm({ user, onUpdate }) {
  const [formData, setFormData] = React.useState({
    address: user?.location?.address || "",
    city: user?.location?.city || "",
    state: user?.location?.state || "",
  });
  const [loading, setLoading] = React.useState(false);
  const [error, setError] = React.useState("");
  const [success, setSuccess] = React.useState("");

  const handleSave = async (e) => {
    e.preventDefault();
    setError("");
    setSuccess("");

    setLoading(true);
    try {
      await User.updateMyUserData({
        location: {
          address: formData.address,
          city: formData.city,
          state: formData.state,
        }
      });
      setSuccess("Address updated successfully!");
      onUpdate(); // Notify parent to refresh user data
    } catch (err) {
      setError("Failed to update address. Please try again.");
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <form onSubmit={handleSave} className="space-y-6">
      <div className="space-y-4">
        <div>
          <Label htmlFor="address">Street Address</Label>
          <Input
            id="address"
            value={formData.address}
            onChange={(e) => setFormData({ ...formData, address: e.target.value })}
            placeholder="123 Main St"
          />
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <Label htmlFor="city">City</Label>
            <Input
              id="city"
              value={formData.city}
              onChange={(e) => setFormData({ ...formData, city: e.target.value })}
              placeholder="Anytown"
            />
          </div>
          <div>
            <Label htmlFor="state">State / Province</Label>
            <Input
              id="state"
              value={formData.state}
              onChange={(e) => setFormData({ ...formData, state: e.target.value })}
              placeholder="CA"
            />
          </div>
        </div>
      </div>
      
      {error && (
        <div className="p-3 bg-red-50 border border-red-200 rounded-lg flex items-center gap-2">
          <AlertTriangle className="w-5 h-5 text-red-600" />
          <p className="text-red-700 text-sm">{error}</p>
        </div>
      )}

      {success && (
        <div className="p-3 bg-green-50 border border-green-200 rounded-lg flex items-center gap-2">
          <CheckCircle className="w-5 h-5 text-green-600" />
          <p className="text-green-700 text-sm">{success}</p>
        </div>
      )}

      <div className="flex justify-end">
        <Button type="submit" disabled={loading} className="bg-green-600 hover:bg-green-700">
          <Save className="w-4 h-4 mr-2" />
          {loading ? "Saving..." : "Save Address"}
        </Button>
      </div>
    </form>
  );
}
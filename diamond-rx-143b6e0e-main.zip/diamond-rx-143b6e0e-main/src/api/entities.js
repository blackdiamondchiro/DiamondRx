import { base44 } from './base44Client';


export const PainEntry = base44.entities.PainEntry;

export const Exercise = base44.entities.Exercise;

export const ExerciseCompletion = base44.entities.ExerciseCompletion;

export const Complaint = base44.entities.Complaint;

export const PainLog = base44.entities.PainLog;

export const ExerciseAssigned = base44.entities.ExerciseAssigned;

export const AuditLog = base44.entities.AuditLog;

export const ICD10Code = base44.entities.ICD10Code;

export const ExercisePrescription = base44.entities.ExercisePrescription;



// auth sdk:
export const User = base44.auth;